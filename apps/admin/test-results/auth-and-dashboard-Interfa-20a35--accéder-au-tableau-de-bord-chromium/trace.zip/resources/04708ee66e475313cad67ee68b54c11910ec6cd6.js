(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1mojsay._.js","static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_1w7iicu._.js","static/chunks/0s5z_next_dist_compiled_next-devtools_index_1j8gejr.js","static/chunks/0s5z_next_dist_compiled_react-dom_04uubl0._.js","static/chunks/0s5z_next_dist_compiled_react-server-dom-turbopack_144zo3u._.js","static/chunks/0s5z_next_dist_compiled_10reo6c._.js","static/chunks/0s5z_next_dist_client_1h7jtrr._.js","static/chunks/0s5z_next_dist_1jwompd._.js","static/chunks/0zix_@swc_helpers_cjs_0hi-e47._.js"],
    source: "entry"
});
