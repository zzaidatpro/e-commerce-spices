(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__13h3den._.css","static/chunks/0_f__@base-ui_utils_182bis1._.js","static/chunks/0u8u_@base-ui_react_internals_03rymas._.js","static/chunks/0u8u_@base-ui_react_utils_05w0m_j._.js","static/chunks/0u8u_@base-ui_react_field_0-ptq_i._.js","static/chunks/0u8u_@base-ui_react_dialog_15aucfi._.js","static/chunks/0u8u_@base-ui_react_floating-ui-react_0glq2am._.js","static/chunks/0u8u_@base-ui_react_menu_0slutv9._.js","static/chunks/0u8u_@base-ui_react_06dyq7b._.js","static/chunks/node_modules__pnpm_1iltc5t._.js","static/chunks/packages_ui_src_1fvcqr1._.js","static/chunks/_1tgo0pj._.js"],
    source: "entry"
});
