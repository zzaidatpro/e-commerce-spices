(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/arrow/MenuArrow.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuArrow",
    ()=>MenuArrow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popupStateMapping.mjs [app-client] (ecmascript) <locals>");
'use client';
;
;
;
;
;
const MenuArrow = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuArrow(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const { arrowRef, side, align, arrowUncentered, arrowStyles } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuPositionerContext"])();
    const open = store.useState('open');
    const state = {
        open,
        side,
        align,
        uncentered: arrowUncentered
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: [
            arrowRef,
            forwardedRef
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["popupStateMapping"],
        state,
        props: {
            style: arrowStyles,
            'aria-hidden': true,
            ...elementProps
        }
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuArrow.displayName = "MenuArrow";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/backdrop/MenuBackdrop.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuBackdrop",
    ()=>MenuBackdrop
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popupStateMapping.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
'use client';
;
;
;
;
;
;
const MenuBackdrop = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuBackdrop(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const open = store.useState('open');
    const mounted = store.useState('mounted');
    const transitionStatus = store.useState('transitionStatus');
    const lastOpenChangeReason = store.useState('lastOpenChangeReason');
    const contextMenuContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContextMenuRootContext"])();
    const state = {
        open,
        transitionStatus
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: contextMenuContext?.backdropRef ? [
            forwardedRef,
            contextMenuContext.backdropRef
        ] : forwardedRef,
        state,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["popupTransitionStateMapping"],
        props: [
            {
                role: 'presentation',
                hidden: !mounted,
                style: {
                    pointerEvents: lastOpenChangeReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover ? 'none' : undefined,
                    userSelect: 'none',
                    WebkitUserSelect: 'none'
                }
            },
            elementProps
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuBackdrop.displayName = "MenuBackdrop";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item-indicator/MenuCheckboxItemIndicator.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuCheckboxItemIndicator",
    ()=>MenuCheckboxItemIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTransitionStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useTransitionStatus.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useOpenChangeComplete.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const MenuCheckboxItemIndicator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuCheckboxItemIndicator(componentProps, forwardedRef) {
    const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
    const item = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuCheckboxItemContext"])();
    const indicatorRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const { transitionStatus, mounted, setMounted } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTransitionStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"])(item.checked);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeComplete"])({
        batch: true,
        enabled: !item.checked,
        open: item.checked,
        ref: indicatorRef,
        onComplete () {
            if (!item.checked) {
                setMounted(false);
            }
        }
    });
    const state = {
        checked: item.checked,
        disabled: item.disabled,
        highlighted: item.highlighted,
        transitionStatus
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('span', componentProps, {
        state,
        ref: [
            forwardedRef,
            indicatorRef
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["itemMapping"],
        props: {
            'aria-hidden': true,
            ...elementProps
        },
        enabled: keepMounted || mounted
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) MenuCheckboxItemIndicator.displayName = "MenuCheckboxItemIndicator";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuCheckboxItem",
    ()=>MenuCheckboxItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useControlled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuCheckboxItemPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuCheckboxItemPlain(componentProps, forwardedRef) {
    const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = false, checked = false, onCheckedChange, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const listItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])({
        guess: true,
        label
    });
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const rootDisabled = store.useState('disabled');
    const highlighted = store.useState('isActive', listItem.index);
    const nodeId = store.useState('floatingNodeId');
    const itemProps = store.useState('itemProps');
    const disabled = disabledProp || rootDisabled;
    const { getItemProps, itemRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuItem"])({
        closeOnClick,
        disabled,
        highlighted,
        id,
        store,
        nativeButton,
        nodeId,
        itemMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REGULAR_ITEM"]
    });
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuCheckboxItemPlain.MenuCheckboxItemPlain.useMemo[state]": ()=>({
                disabled,
                highlighted,
                checked
            })
    }["MenuCheckboxItemPlain.MenuCheckboxItemPlain.useMemo[state]"], [
        disabled,
        highlighted,
        checked
    ]);
    function handleClick(event) {
        const details = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].itemPress, event.nativeEvent, undefined, {
            preventUnmountOnClose: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"]
        });
        onCheckedChange?.(!checked, details);
    }
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["itemMapping"],
        props: [
            itemProps,
            {
                role: 'menuitemcheckbox',
                'aria-checked': checked,
                onClick: handleClick
            },
            elementProps,
            getItemProps
        ],
        ref: [
            itemRef,
            forwardedRef,
            listItem.ref
        ]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuCheckboxItemContext"].Provider, {
        value: state,
        children: element
    });
});
/**
 * A menu item that toggles a setting on or off.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuCheckboxItemPlain.displayName = "MenuCheckboxItemPlain";
const MenuCheckboxItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuCheckboxItem(props, forwardedRef) {
    const { checked: checkedProp, defaultChecked, onCheckedChange, ...plainProps } = props;
    // Owned above the element so an uncontrolled item keeps its state while a filter hides it.
    const [checked, setChecked] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: checkedProp,
        default: defaultChecked ?? false,
        name: 'MenuCheckboxItem',
        state: 'checked'
    });
    const filterItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterItem"])(props, forwardedRef);
    function handleCheckedChange(nextChecked, eventDetails) {
        onCheckedChange?.(nextChecked, eventDetails);
        if (!eventDetails.isCanceled) {
            setChecked(nextChecked);
        }
    }
    if (!filterItem.visible) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuCheckboxItemPlain, {
        ...plainProps,
        checked: checked,
        onCheckedChange: handleCheckedChange,
        ref: filterItem.ref
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuCheckboxItem.displayName = "MenuCheckboxItem";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuCheckboxItemContext",
    ()=>MenuCheckboxItemContext,
    "useMenuCheckboxItemContext",
    ()=>useMenuCheckboxItemContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuCheckboxItemContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuCheckboxItemContext.displayName = "MenuCheckboxItemContext";
function useMenuCheckboxItemContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuCheckboxItemContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenuCheckboxItemContext is missing. MenuCheckboxItem parts must be placed within <Menu.CheckboxItem>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemDataAttributes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Present when the menu checkbox item is checked.
 */ __turbopack_context__.s([
    "checked",
    ()=>checked,
    "disabled",
    ()=>disabled,
    "highlighted",
    ()=>highlighted,
    "unchecked",
    ()=>unchecked
]);
const checked = 'data-checked';
const unchecked = 'data-unchecked';
const disabled = 'data-disabled';
const highlighted = 'data-highlighted';
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/clear/MenuClear.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuClear",
    ()=>MenuClear
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$clear$2f$FilterDropdownClear$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/clear/FilterDropdownClear.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
/**
 * A button that clears the input text.
 * Requires the menu to be wrapped in `Menu.FilterProvider`.
 * Renders a `<button>` element when the input has text.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
const MenuClear = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuClear(props, forwardedRef) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterPart"])('Clear');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$clear$2f$FilterDropdownClear$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownClear"], {
        ...props,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuClear.displayName = "MenuClear";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/empty/MenuEmpty.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuEmpty",
    ()=>MenuEmpty
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$empty$2f$FilterDropdownEmpty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/empty/FilterDropdownEmpty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
/**
 * A message shown when the menu has no matching items.
 * Requires the menu to be wrapped in `Menu.FilterProvider`.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
const MenuEmpty = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuEmpty(props, forwardedRef) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterPart"])('Empty');
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$empty$2f$FilterDropdownEmpty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownEmpty"], {
        ...props,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuEmpty.displayName = "MenuEmpty";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-provider/MenuFilterProvider.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterProvider",
    ()=>MenuFilterProvider
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$submenu$2d$root$2f$MenuFilterSubmenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-submenu-root/MenuFilterSubmenuRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-provider/MenuFilterProviderContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
function MenuFilterProvider(props) {
    const { children, filter, value, defaultValue, onValueChange, autoHighlight, locale } = props;
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuFilterProvider.useMemo[contextValue]": ()=>({
                Root: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterRoot"],
                SubmenuRoot: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$submenu$2d$root$2f$MenuFilterSubmenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterSubmenuRoot"],
                options: {
                    filter,
                    value,
                    defaultValue,
                    onValueChange,
                    autoHighlight,
                    locale
                }
            })
    }["MenuFilterProvider.useMemo[contextValue]"], [
        filter,
        value,
        defaultValue,
        onValueChange,
        autoHighlight,
        locale
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterProviderContext"].Provider, {
        value: contextValue,
        children: children
    });
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-provider/MenuFilterProviderContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterProviderContext",
    ()=>MenuFilterProviderContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const MenuFilterProviderContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
if ("TURBOPACK compile-time truthy", 1) MenuFilterProviderContext.displayName = "MenuFilterProviderContext";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterImplContext",
    ()=>MenuFilterImplContext,
    "useMenuFilterImpl",
    ()=>useMenuFilterImpl,
    "useMenuFilterItem",
    ()=>useMenuFilterItem,
    "useMenuFilterPart",
    ()=>useMenuFilterPart
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useMergedRefs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
const MenuFilterImplContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
if ("TURBOPACK compile-time truthy", 1) MenuFilterImplContext.displayName = "MenuFilterImplContext";
function useMenuFilterImpl(scope = 'root') {
    const impl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuFilterImplContext);
    const root = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRootContext"]);
    if (impl === null || root === undefined) {
        return null;
    }
    const filterable = scope === 'submenu-trigger' ? root.virtualFocus || root.parentVirtualFocus : root.virtualFocus;
    return filterable ? impl : null;
}
function useMenuFilterPart(part) {
    if (useMenuFilterImpl() === null) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? `Base UI: <Menu.${part}> must be placed in a menu wrapped in <Menu.FilterProvider>. ` + 'It reads the filter query and the matching items from the provider, which a plain menu ' + 'does not have. Wrap the <Menu.Root> or <Menu.SubmenuRoot> it belongs to in ' + '<Menu.FilterProvider>. See https://base-ui.com/react/components/menu#filtering' : "TURBOPACK unreachable");
    }
}
const UNFILTERED = {
    visible: true,
    ref: null
};
function useUnfilteredItem() {
    return UNFILTERED;
}
function useMenuFilterItem(props, forwardedRef, scope = 'root') {
    const impl = useMenuFilterImpl(scope);
    const useItem = (scope === 'submenu-trigger' ? impl?.useSubmenuTrigger : impl?.useItem) ?? useUnfilteredItem;
    const item = useItem({
        label: props.label,
        children: props.children,
        render: props.render
    });
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(forwardedRef, item.ref);
    return {
        visible: item.visible,
        ref,
        props: item.props
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterDropdown.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterDropdown",
    ()=>MenuFilterDropdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useControlled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useRefWithInit.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menubar$2f$MenubarContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menubar/MenubarContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/event.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$useFilterDropdownCloseQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/useFilterDropdownCloseQuery.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterImpl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterImpl.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterKeyDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterKeyDown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function MenuFilterDropdown(props) {
    const { value: valueProp, defaultValue = '', onValueChange, ...dropdownProps } = props;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const open = store.useState('open');
    const mounted = store.useState('mounted');
    const keyboardOpen = store.useState('keyboardOpen');
    const activeTriggerId = store.useState('activeTriggerId');
    const activeTriggerElement = store.useState('activeTriggerElement');
    const disabled = store.useState('disabled');
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: valueProp,
        default: defaultValue,
        name: 'MenuFilterProvider',
        state: 'value'
    });
    const handleValueChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterDropdown.useStableCallback[handleValueChange]": (nextValue, eventDetails)=>{
            onValueChange?.(nextValue, eventDetails);
            if (!eventDetails.isCanceled) {
                setValue(nextValue);
            }
        }
    }["MenuFilterDropdown.useStableCallback[handleValueChange]"]);
    const getActiveIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterDropdown.useStableCallback[getActiveIndex]": ()=>store.state.activeIndex
    }["MenuFilterDropdown.useStableCallback[getActiveIndex]"]);
    const setActiveIndex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterDropdown.useStableCallback[setActiveIndex]": (index)=>{
            store.setActiveIndex(index, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none);
        }
    }["MenuFilterDropdown.useStableCallback[setActiveIndex]"]);
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$useFilterDropdownCloseQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownCloseQuery"])({
        open,
        mounted,
        value,
        onValueChange: handleValueChange
    });
    const filterTriggerProps = useFilterTriggerProps(value !== '');
    // Seeded before the triggers below render, like the root's inactive trigger props, so the sync
    // effect doesn't render every trigger twice in the first commit.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "MenuFilterDropdown.useRefWithInit": ()=>{
            store.set('filterTriggerProps', filterTriggerProps);
            return null;
        }
    }["MenuFilterDropdown.useRefWithInit"]);
    store.useSyncedValue('filterTriggerProps', filterTriggerProps);
    // Only `setOpen` records a keyboard open, so a controlled close that bypasses it must not leave
    // the next programmatic open looking like one.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuFilterDropdown.useIsoLayoutEffect": ()=>{
            if (!open) {
                store.set('keyboardOpen', false);
            }
        }
    }["MenuFilterDropdown.useIsoLayoutEffect"], [
        open,
        store
    ]);
    // Trust the rendered element's id once it exists: an explicitly empty id must not fall back to a
    // registered id that no element carries.
    const triggerId = activeTriggerElement ? activeTriggerElement.id || null : activeTriggerId;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterImplContext"].Provider, {
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterImpl$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MENU_FILTER_IMPL"],
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownRoot"], {
            ...dropdownProps,
            open: open,
            openedByKeyboard: keyboardOpen,
            disabled: disabled,
            value: value,
            query: query,
            onValueChange: handleValueChange,
            triggerId: triggerId,
            listRef: store.context.itemDomElements,
            getActiveIndex: getActiveIndex,
            setActiveIndex: setActiveIndex,
            focusOwnerRef: store.context.virtualFocusRef
        })
    });
}
/**
 * The props a filterable menu adds to its triggers: dialog semantics, screen reader press
 * tracking, and a relay of list navigation typed on the trigger to the input, since the input
 * holds real focus while the popup is open.
 */ function useFilterTriggerProps(hasValue) {
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const isInMenubar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menubar$2f$MenubarContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenubarContext"])(true) != null;
    const handleInputKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterKeyDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterKeyDown"])(hasValue);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFilterTriggerProps.useMemo": ()=>({
                'aria-haspopup': 'dialog',
                onPointerDown (event) {
                    store.context.virtualPress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isVirtualPointerEvent"])(event.nativeEvent);
                },
                onKeyDown (event) {
                    const focusOwner = store.context.virtualFocusRef?.current;
                    if (!store.select('open') || !focusOwner || isInMenubar) {
                        return;
                    }
                    if (event.key === 'ArrowUp' || event.key === 'ArrowDown') {
                        focusOwner.focus({
                            preventScroll: true
                        });
                        handleInputKeyDown(event);
                        event.preventDefault();
                        event.preventBaseUIHandler();
                    } else if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
                        // Cross-axis keys drive submenu open/close, which the trigger must not relay.
                        event.preventBaseUIHandler();
                    } else if (isTypeaheadKey(event)) {
                        focusOwner.focus({
                            preventScroll: true
                        });
                    }
                }
            })
    }["useFilterTriggerProps.useMemo"], [
        store,
        isInMenubar,
        handleInputKeyDown
    ]);
}
function isTypeaheadKey(event) {
    return event.key.length === 1 && event.key !== ' ' && !event.ctrlKey && !event.metaKey && !event.altKey;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterGroup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterGroup",
    ()=>MenuFilterGroup,
    "MenuFilterRadioGroup",
    ()=>MenuFilterRadioGroup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$useFilterDropdownGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/useFilterDropdownGroup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/FilterDropdownGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const MenuFilterGroup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuFilterGroup(props, forwardedRef) {
    const { hidden, context } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$useFilterDropdownGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownGroup"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownGroupContext"].Provider, {
        value: context,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuGroupPlain"], {
            ...props,
            hidden: hidden || props.hidden || undefined,
            ref: forwardedRef
        })
    });
});
/**
 * `Menu.RadioGroup` in a filterable menu, hidden like `MenuFilterGroup`.
 *
 * @internal
 */ if ("TURBOPACK compile-time truthy", 1) MenuFilterGroup.displayName = "MenuFilterGroup";
const MenuFilterRadioGroup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuFilterRadioGroup(props, forwardedRef) {
    const { hidden, context } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$useFilterDropdownGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownGroup"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownGroupContext"].Provider, {
        value: context,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRadioGroupPlain"], {
            ...props,
            hidden: hidden || props.hidden || undefined,
            ref: forwardedRef
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuFilterRadioGroup.displayName = "MenuFilterRadioGroup";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterImpl.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MENU_FILTER_IMPL",
    ()=>MENU_FILTER_IMPL
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterPopup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterList.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterGroup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$item$2f$useFilterDropdownItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/item/useFilterDropdownItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterSubmenuTrigger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterSubmenuTrigger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useVirtualFocusParentHandoff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useVirtualFocusParentHandoff.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
const MENU_FILTER_IMPL = {
    Popup: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterPopup"],
    List: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterList"],
    Group: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterGroup"],
    RadioGroup: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterRadioGroup"],
    useItem: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$item$2f$useFilterDropdownItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItem"],
    useSubmenuTrigger: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterSubmenuTrigger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterSubmenuTrigger"],
    useParentHandoff: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useVirtualFocusParentHandoff$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useVirtualFocusParentHandoff"]
};
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterList.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterList",
    ()=>MenuFilterList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$list$2f$FilterDropdownList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/list/FilterDropdownList.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterKeyDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterKeyDown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeListContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/CompositeListContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolvePopupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/resolvePopupLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$moveHighlightFrom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/moveHighlightFrom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/utils/refocusOwner.mjs [app-client] (ecmascript)");
/**
 * The list of a filterable menu: it takes the `menu` role while the popup is a dialog holding
 * the input, and it forwards keys that land on it to the input.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuFilterList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuFilterList(componentProps, forwardedRef) {
    const { store, orientation, loopFocus, allowEscape } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    const { onItemsChange, focusOwnerRef, triggerId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownRootContext"])();
    const { listRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItemContext"])();
    const { subscribeMapChange } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeListContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListContext"])();
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownValueContext"])();
    const handleInputKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterKeyDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterKeyDown"])(value !== '');
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterList.MenuFilterList.useStableCallback[handleKeyDown]": (event)=>{
            const owner = focusOwnerRef.current;
            const target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent);
            const ownerFocused = owner != null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(owner)) === owner;
            const fromNestedPopup = !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(event.currentTarget, target);
            // Keys the input forwards to its highlighted item arrive here while the input still holds
            // focus, and a nested popup's keys bubble through this React tree from outside the list.
            if (owner == null || ownerFocused || fromNestedPopup) {
                if (event.which !== 229 && !event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMainOrientationKey"])(event.key, orientation)) {
                    // Keep main-axis keys from reaching this popup's own list navigation, which lost its
                    // place while the nested popup held focus. A plain submenu that closes on the key hands
                    // focus back and lets it through, so move on from its trigger as a plain parent would.
                    event.stopPropagation();
                    const trigger = fromNestedPopup && ownerFocused ? getNestedPopupTrigger(target) : undefined;
                    if (trigger) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$moveHighlightFrom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["moveHighlightFrom"])(store, trigger, event, {
                            orientation,
                            rtl: direction === 'rtl',
                            loopFocus,
                            allowEscape
                        });
                    }
                }
                return;
            }
            // An item that already acted on the key (Enter and Space activate it) keeps it.
            if (event.defaultPrevented) {
                return;
            }
            // Real focus can land inside the list while the input still owns the keyboard: a scrollbar
            // press focuses the list itself, and a screen reader following `aria-activedescendant`
            // focuses the highlighted item. Hand focus back and route the key as the input would; a
            // typing key's default action follows the moved focus into the input.
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["refocusOwner"])(owner);
            handleInputKeyDown(event);
        }
    }["MenuFilterList.MenuFilterList.useStableCallback[handleKeyDown]"]);
    // The item whose `aria-controls` popup holds `target`. The popup shares the target's root,
    // which is a shadow root when it's portaled into one.
    function getNestedPopupTrigger(target) {
        const root = target.getRootNode();
        return listRef.current.find((item)=>{
            const popupId = item?.getAttribute('aria-controls');
            return popupId != null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(item) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(root.getElementById(popupId), target);
        });
    }
    // `null` distinguishes the initial registration from a list emptied by filtering.
    const previousItemsRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    // CompositeList notifies subscribers before its `onMapChange`, so the positioner reports the
    // highlight against the settled registry only after the items change has been resolved here.
    const handleItemMapChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterList.MenuFilterList.useStableCallback[handleItemMapChange]": ()=>{
            const items = [
                ...listRef.current
            ];
            const previousItems = previousItemsRef.current;
            const changed = previousItems === null || previousItems.length !== items.length || items.some({
                "MenuFilterList.MenuFilterList.useStableCallback[handleItemMapChange]": (item, index)=>item !== previousItems[index]
            }["MenuFilterList.MenuFilterList.useStableCallback[handleItemMapChange]"]);
            if (changed && previousItems !== null) {
                onItemsChange(previousItems);
            }
            previousItemsRef.current = items;
        }
    }["MenuFilterList.MenuFilterList.useStableCallback[handleItemMapChange]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuFilterList.MenuFilterList.useIsoLayoutEffect": ()=>{
            return subscribeMapChange(handleItemMapChange);
        }
    }["MenuFilterList.MenuFilterList.useIsoLayoutEffect"], [
        subscribeMapChange,
        handleItemMapChange
    ]);
    const ariaLabelledBy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolvePopupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolvePopupLabel"])(componentProps, null, triggerId ?? null);
    const listProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])({
        role: 'menu',
        'aria-labelledby': ariaLabelledBy,
        'aria-orientation': orientation === 'horizontal' ? 'horizontal' : undefined,
        onKeyDown: handleKeyDown
    }, componentProps);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$list$2f$FilterDropdownList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownList"], {
        ...listProps,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuFilterList.displayName = "MenuFilterList";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterPopup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterPopup",
    ()=>MenuFilterPopup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterPopup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$popup$2f$MenuPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/popup/MenuPopup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
/**
 * A container for the filter input and item list.
 * Renders a `<div>` element with a `dialog` role.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const MenuFilterPopup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuFilterPopup(props, forwardedRef) {
    const { store, orientation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const open = store.useState('open');
    const parent = store.useState('parent');
    const openMethod = store.useState('openMethod');
    const lastOpenChangeReason = store.useState('lastOpenChangeReason');
    const interactionProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterPopup"])(orientation);
    const openedByHover = open && lastOpenChangeReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover;
    const mayFocusInput = parent.type !== 'menu' || open && (openMethod === 'keyboard' || lastOpenChangeReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation || lastOpenChangeReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover || lastOpenChangeReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerPress);
    // The input holds real focus; the popup is never the focus target.
    let initialFocus = false;
    if (mayFocusInput) {
        initialFocus = ()=>{
            // A tap would raise the on-screen keyboard, but a screen reader press (such as an iOS
            // VoiceOver double-tap) still reports a touch and needs the input focused.
            const touchOpen = (openMethod === 'touch' || openMethod === 'pen') && !store.context.virtualPress;
            if (openedByHover || touchOpen) {
                return false;
            }
            return store.context.virtualFocusRef?.current ?? false;
        };
    }
    const popupProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(interactionProps, props);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$popup$2f$MenuPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuPopupPlain"], {
        ...popupProps,
        role: "dialog",
        initialFocus: initialFocus,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuFilterPopup.displayName = "MenuFilterPopup";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterRoot",
    ()=>MenuFilterRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterDropdown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterDropdown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterRoot.mjs [app-client] (ecmascript)");
/**
 * The filterable implementation of `Menu.Root`, rendered in its place when the root sits inside
 * `Menu.FilterProvider`. Reached through the provider only, so a plain menu never bundles it.
 *
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
function MenuFilterRoot(props) {
    const { children, rootProps, dropdownProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterRoot"])(props);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRootInternal"], {
        ...rootProps,
        children: (payload)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterDropdown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterDropdown"], {
                ...dropdownProps,
                children: typeof children === 'function' ? children(payload) : children
            })
    });
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/moveHighlightFrom.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "moveHighlightFrom",
    ()=>moveHighlightFrom
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/composite.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
;
;
;
;
function moveHighlightFrom(store, item, event, options) {
    const { orientation, rtl, loopFocus, allowEscape } = options;
    const listRef = store.context.itemDomElements;
    const items = listRef.current;
    const { index } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getNextListIndex"])(items, items.indexOf(item), {
        decrement: !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMainOrientationToEndKey"])(event.key, orientation, rtl),
        loopFocus,
        allowEscape,
        // Match the menu's list navigation: `aria-disabled` items stay reachable.
        disabledIndices: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"],
        minIndex: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMinListIndex"])(listRef, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"]),
        maxIndex: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMaxListIndex"])(listRef, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"])
    });
    const next = items[index];
    if (next) {
        store.setActiveIndex(index, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].keyboard, event.nativeEvent);
        next.scrollIntoView?.({
            block: 'nearest',
            inline: 'nearest'
        });
    }
    return next ?? undefined;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterKeyDown.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getMenuFilterKeyAction",
    ()=>getMenuFilterKeyAction,
    "useMenuFilterKeyDown",
    ()=>useMenuFilterKeyDown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript) <export getWindow as ownerWindow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/event.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/composite.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$dispatchClickWithModifiers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/dispatchClickWithModifiers.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
function getMenuFilterKeyAction(event, context) {
    const { orientation, rtl, hasActiveItem, activeItemOpensSubmenu, hasValue } = context;
    const { key } = event;
    // Enter that commits an IME composition belongs to the input, not the list.
    if (event.which === 229) {
        return 'ignore';
    }
    if (key === 'Tab') {
        return event.shiftKey ? 'close' : 'ignore';
    }
    if (key === 'Enter') {
        return hasActiveItem ? 'activate' : 'navigate';
    }
    const isArrow = key.startsWith('Arrow');
    const isBoundary = key === 'Home' || key === 'End';
    // Modified arrows and boundary keys are text-editing commands (extend the selection, move by
    // word or to a text boundary), like a modified character.
    if (event.shiftKey || event.ctrlKey || event.altKey || event.metaKey) {
        return isArrow || isBoundary || key.length === 1 ? 'edit' : 'navigate';
    }
    // Characters stay out of parent handlers such as typeahead.
    if (key.length === 1) {
        return 'edit';
    }
    // Home and End move the caret while the input has text, and jump to the ends of the list
    // otherwise once an item is highlighted.
    if (isBoundary) {
        return hasActiveItem && !hasValue ? 'navigate' : 'edit';
    }
    if (!isArrow) {
        return 'navigate';
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMainOrientationKey"])(key, orientation)) {
        // Left and Right move the caret of a non-empty input while nothing is highlighted.
        return orientation === 'horizontal' && !hasActiveItem && hasValue ? 'edit' : 'navigate';
    }
    // A highlighted submenu trigger takes the cross-axis keys to open or close its submenu.
    if (activeItemOpensSubmenu && ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOrientationOpenKey"])(key, orientation, rtl) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOrientationCloseKey"])(key, orientation, rtl, false))) {
        return 'submenu';
    }
    if (orientation === 'horizontal' && !hasActiveItem) {
        return 'enter-list';
    }
    // Otherwise the cross-axis keys move the caret. On an empty input they fall through so they
    // can still close a submenu.
    return hasValue ? 'edit' : 'navigate';
}
function useMenuFilterKeyDown(hasValue) {
    const { orientation, store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const submenuContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuSubmenuRootContext"])();
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useMenuFilterKeyDown.useStableCallback": (event)=>{
            // Like a plain menu, ignore keys while the popup animates out with the input still focused.
            if (!store.select('open')) {
                return;
            }
            const activeItem = store.state.highlightedItem;
            const action = getMenuFilterKeyAction(event, {
                orientation,
                rtl: direction === 'rtl',
                hasActiveItem: activeItem != null,
                activeItemOpensSubmenu: activeItem?.hasAttribute('aria-haspopup') ?? false,
                hasValue
            });
            switch(action){
                case 'edit':
                    event.stopPropagation();
                    // Typing ends pointer modality, as it does in a combobox, so a result change that moves
                    // the highlighted item out from under a resting pointer doesn't clear the highlight.
                    if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) {
                        store.state.inputProps.onKeyDown?.(event);
                    }
                    break;
                case 'navigate':
                    {
                        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMainOrientationKey"])(event.key, orientation)) {
                            // Keep the same event from reaching the popup's list navigation and moving the virtual
                            // cursor a second time.
                            event.stopPropagation();
                        }
                        store.state.inputProps.onKeyDown?.(event);
                        break;
                    }
                case 'enter-list':
                    {
                        event.stopPropagation();
                        const listRef = store.context.itemDomElements;
                        const index = event.key === 'ArrowDown' ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMinListIndex"])(listRef, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"]) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMaxListIndex"])(listRef, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"]);
                        if (listRef.current[index]) {
                            event.preventDefault();
                            store.setActiveIndex(index, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].keyboard, event.nativeEvent);
                        }
                        break;
                    }
                case 'submenu':
                    {
                        // The highlighted item's own handlers decide, since opening depends on the item and on
                        // both menus' orientations, and they read `currentTarget`, so the key is dispatched on
                        // it. Its propagation reaches the popup, which closes a submenu.
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stopEvent"])(event);
                        const KeyboardEventConstructor = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__["ownerWindow"])(activeItem).KeyboardEvent;
                        activeItem.dispatchEvent(new KeyboardEventConstructor(event.type, event.nativeEvent));
                        break;
                    }
                case 'activate':
                    event.preventDefault();
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$dispatchClickWithModifiers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchClickWithModifiers"])(activeItem, event);
                    break;
                case 'close':
                    {
                        // Mirror the plain menu: Shift+Tab closes the popup and returns focus. A submenu returns
                        // to the element that held focus in its parent, which is the parent's input rather than
                        // its untabbable trigger when the parent is filterable too.
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stopEvent"])(event);
                        const returnElement = store.state.parent.type === 'menu' && submenuContext?.getReturnElement?.() || store.state.activeTriggerElement;
                        const details = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].focusOut, event.nativeEvent);
                        store.setOpen(false, details);
                        if (!details.isCanceled && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(returnElement)) {
                            returnElement.focus();
                        }
                        break;
                    }
                default:
                    break;
            }
        }
    }["useMenuFilterKeyDown.useStableCallback"]);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterPopup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMenuFilterPopup",
    ()=>useMenuFilterPopup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/warn.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/element.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/utils/refocusOwner.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
function useMenuFilterPopup(orientation) {
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownRootContext"])();
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    const { focusOwnerRef } = context;
    // Focus that entered a nested popup by keyboard or click stays there while the
    // pointer crosses the parent popup. Returning to a submenu trigger restores focus to the
    // parent input. Focus that merely followed the pointer in follows it back out.
    const nestedFocusRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    // A tap fires compatibility mouse events, which must not focus the input and raise the
    // on-screen keyboard.
    const pointerTypeRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]('mouse');
    function trackPointerType(event) {
        pointerTypeRef.current = event.pointerType || 'mouse';
    }
    /* istanbul ignore else -- `process.env.NODE_ENV` is a build-time constant under test */ if ("TURBOPACK compile-time truthy", 1) {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "useMenuFilterPopup.useEffect": ()=>{
                if (context.open && focusOwnerRef.current === null) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["warn"])('A filterable menu opened without a <Menu.Input>. Render the input inside ' + '<Menu.Popup>, or drop <Menu.FilterProvider> for a menu that does not filter.');
                }
            }
        }["useMenuFilterPopup.useEffect"], [
            context.open,
            focusOwnerRef
        ]);
    }
    function restoreInputFocus(event, enteredTrigger) {
        const focusOwner = focusOwnerRef.current;
        if (!context.open || !focusOwner) {
            return;
        }
        const activeEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(event.currentTarget));
        if (activeEl === focusOwner || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(event.currentTarget, activeEl)) {
            return;
        }
        // Nested popups are portalled, so their events still bubble through this React tree.
        // The composed path only contains this popup when the pointer is really over it, and a
        // closing popup must not re-capture focus during its exit transition.
        let submenuTrigger = null;
        const nearestPopup = event.nativeEvent.composedPath().find((node)=>{
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(node)) {
                return false;
            }
            if (node.getAttribute('role') === 'dialog' || node.hasAttribute('data-rootownerid')) {
                return true;
            }
            if (node.hasAttribute('aria-haspopup')) {
                submenuTrigger = node;
            }
            return false;
        });
        if (nearestPopup !== event.currentTarget) {
            return;
        }
        // A nested popup that took focus keeps it while the pointer moves over the parent popup.
        // Entering a submenu trigger returns focus to the parent's input.
        if (nestedFocusRef.current && !(enteredTrigger && submenuTrigger)) {
            return;
        }
        if (enteredTrigger && submenuTrigger && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElement"])(event.relatedTarget) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(submenuTrigger, event.relatedTarget)) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["refocusOwner"])(focusOwner);
    }
    return {
        // The input owns virtual focus.
        'aria-activedescendant': undefined,
        // Not valid on a dialog; the list's implicit orientation is already vertical.
        'aria-orientation': undefined,
        onMouseDown (event) {
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent) === event.currentTarget) {
                // Keep focus on the virtual focus owner when the popup's own background is pressed.
                event.preventDefault();
            }
        },
        onPointerDown: trackPointerType,
        // `pointerover` precedes the compatibility `mouseover`, so a mouse entering right after a tap
        // is recognized before the handoff below.
        onPointerOver: trackPointerType,
        onPointerMove: trackPointerType,
        onMouseMove (event) {
            if (pointerTypeRef.current === 'mouse') {
                restoreInputFocus(event, false);
            }
        },
        onMouseOver (event) {
            if (pointerTypeRef.current === 'mouse' && nestedFocusRef.current) {
                restoreInputFocus(event, true);
            }
        },
        onFocus (event) {
            // `focusin` bubbles, so this also sees the owner itself being focused.
            const target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent);
            // Nested popups are portalled, so their focus events bubble through this React tree
            // while their elements sit outside this one in the DOM.
            if (target === focusOwnerRef.current) {
                nestedFocusRef.current = null;
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(target) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(event.currentTarget, target) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRefocusingOwner"])()) {
                nestedFocusRef.current = target;
            }
            // Focus that lands on the popup itself, the focus manager's fallback target, moves on to
            // the input, which owns focus while the menu filters.
            if (context.open && target === event.currentTarget) {
                focusOwnerRef.current?.focus({
                    preventScroll: true
                });
            }
        },
        onKeyDown (event) {
            const target = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent);
            if (target === focusOwnerRef.current || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$element$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isTypeableElement"])(target)) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOrientationCloseKey"])(event.key, orientation, direction === 'rtl', false)) {
                focusOwnerRef.current?.focus({
                    preventScroll: true
                });
                // Nested popups bubble through this React tree, so keep the key from the parent.
                event.stopPropagation();
            }
        }
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMenuFilterRoot",
    ()=>useMenuFilterRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
function useMenuFilterRoot(props) {
    const { children, value, defaultValue, onValueChange, filter, autoHighlight = false, locale, ...otherProps } = props;
    const virtualFocusRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    return {
        children,
        rootProps: {
            ...otherProps,
            virtualFocus: true,
            virtualFocusRef,
            allowEscape: !autoHighlight,
            resetOnPointerLeave: autoHighlight !== 'always'
        },
        dropdownProps: {
            value,
            defaultValue,
            onValueChange,
            filter,
            autoHighlight,
            locale
        }
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterSubmenuTrigger.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMenuFilterSubmenuTrigger",
    ()=>useMenuFilterSubmenuTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useEnhancedClickHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useEnhancedClickHandler.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/event.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$item$2f$useFilterDropdownItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/item/useFilterDropdownItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function useMenuFilterSubmenuTrigger(params) {
    // `virtualFocus` is set only by a filterable submenu root, so it tells this trigger whether the
    // submenu it opens renders a `role="dialog"` popup or a plain `role="menu"` one. The documented
    // plain-submenu recipe relies on the latter.
    const { store, virtualFocus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const open = store.useState('open');
    const mounted = store.useState('mounted');
    const parent = store.useState('parent');
    // The submenu root's provider shadows the enclosing one, but the trigger belongs to the list
    // it opens from, which is the parent menu's.
    const parentListRef = parent.type === 'menu' ? parent.store.context.itemDomElements : null;
    const parentContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterContextForList"])(parentListRef);
    const { visible, ref } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$item$2f$useFilterDropdownItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItem"])({
        ...params,
        context: parentContext,
        retainGroup: mounted
    });
    // Filtering the trigger out unmounts it, leaving its submenu open with no anchor.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useMenuFilterSubmenuTrigger.useIsoLayoutEffect": ()=>{
            if (visible || !open) {
                return;
            }
            store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none));
        }
    }["useMenuFilterSubmenuTrigger.useIsoLayoutEffect"], [
        visible,
        open,
        store
    ]);
    const clickProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useEnhancedClickHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEnhancedClickHandler"])({
        "useMenuFilterSubmenuTrigger.useEnhancedClickHandler[clickProps]": (event, interactionType)=>{
            if (event.type === 'click' && store.select('open') && (interactionType === 'keyboard' || interactionType === 'mouse' && store.select('lastOpenChangeReason') === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerPress)) {
                store.context.virtualFocusRef?.current?.focus({
                    preventScroll: true
                });
            }
        }
    }["useMenuFilterSubmenuTrigger.useEnhancedClickHandler[clickProps]"]);
    const props = {
        // Omitted rather than `undefined`, which would clear the `'menu'` the root puts on every
        // trigger.
        ...virtualFocus ? {
            'aria-haspopup': 'dialog'
        } : undefined,
        ...clickProps,
        onPointerDown (event) {
            clickProps.onPointerDown(event);
            store.context.virtualPress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isVirtualPointerEvent"])(event.nativeEvent);
        },
        onFocus (event) {
            // A plain parent menu moves DOM focus to whichever item the pointer crosses. While this
            // trigger's submenu is open and its input held focus, hand focus straight back so crossing
            // the trigger doesn't interrupt typing.
            const focusOwner = store.context.virtualFocusRef?.current;
            if (focusOwner && store.select('open') && event.relatedTarget === focusOwner) {
                event.preventBaseUIHandler();
                focusOwner.focus({
                    preventScroll: true
                });
            }
        }
    };
    if (parentContext === null) {
        // A plain parent menu roves DOM focus across its items and never filters them.
        return {
            visible: true,
            ref: null,
            props
        };
    }
    return {
        visible: visible || mounted,
        ref,
        props
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useVirtualFocusParentHandoff.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useVirtualFocusParentHandoff",
    ()=>useVirtualFocusParentHandoff
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
'use client';
;
;
;
;
;
function useVirtualFocusParentHandoff(store, parent, open, virtualFocus) {
    const parentStore = parent.type === 'menu' ? parent.store : null;
    const parentVirtualFocusRef = parentStore?.context.virtualFocusRef;
    const returnToParent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useVirtualFocusParentHandoff.useStableCallback[returnToParent]": (trigger, reason)=>{
            const focusOwner = parentVirtualFocusRef?.current;
            if (virtualFocus || store.select('open') || !parentStore?.select('open') || !focusOwner) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(store.context.popupRef.current, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(focusOwner)))) {
                focusOwner.focus({
                    preventScroll: true
                });
            }
            if ((reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation || reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].escapeKey) && parentStore.state.activeIndex == null) {
                // The closing key is gone by this microtask, so there is no event to report it with.
                parentStore.highlightItem(trigger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none);
            }
        }
    }["useVirtualFocusParentHandoff.useStableCallback[returnToParent]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useVirtualFocusParentHandoff.useIsoLayoutEffect": ()=>{
            if (!open) {
                // A parent closing in the same commit, such as on an item press, syncs its controlled `open`
                // in its own layout effect, which runs after this one. An unmount can clear the trigger by
                // then, so read it now.
                const trigger = store.state.activeTriggerElement;
                const reason = store.select('lastOpenChangeReason');
                queueMicrotask({
                    "useVirtualFocusParentHandoff.useIsoLayoutEffect": ()=>returnToParent(trigger, reason)
                }["useVirtualFocusParentHandoff.useIsoLayoutEffect"]);
            }
        }
    }["useVirtualFocusParentHandoff.useIsoLayoutEffect"], [
        open,
        store,
        returnToParent
    ]);
    // Real focus entering this submenu is when a plain parent's trigger would blur: the parent has
    // no active item until a keyboard close hands the cursor back to the trigger.
    function handleFocus() {
        if (!virtualFocus && parentVirtualFocusRef && parentStore?.state.activeIndex != null) {
            parentStore.setActiveIndex(null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none);
        }
    }
    return {
        parentVirtualFocusRef,
        handleFocus
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-submenu-root/MenuFilterSubmenuRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuFilterSubmenuRoot",
    ()=>MenuFilterSubmenuRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterDropdown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterDropdown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$isKeyboardOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/isKeyboardOpen.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/utils/event.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$moveHighlightFrom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/moveHighlightFrom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function MenuFilterSubmenuRoot(props) {
    const parent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const parentStore = parent.store;
    const parentDisabled = parentStore.useState('disabled');
    const { rootProps, dropdownProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterRoot"])(props);
    const parentReferenceRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    function handleSubmenuEnter(trigger, event) {
        const focusedElement = parent.virtualFocus ? parentStore.context.virtualFocusRef?.current : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(trigger));
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(focusedElement)) {
            parentReferenceRef.current = {
                reference: focusedElement,
                trigger
            };
            parentStore.setActiveIndex(null, event ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].keyboard : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none, event);
        }
    }
    function highlightTrigger(trigger, event) {
        parentStore.highlightItem(trigger, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].keyboard, event);
    }
    function handleSubmenuExit(event) {
        const parentReference = parentReferenceRef.current;
        if (!parentReference) {
            return;
        }
        parentReference.reference.focus({
            preventScroll: true
        });
        highlightTrigger(parentReference.trigger, event);
    }
    function handleOpenChange(nextOpen, details) {
        rootProps.onOpenChange?.(nextOpen, details);
        if (details.isCanceled) {
            return;
        }
        if (!nextOpen) {
            if (details.reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].escapeKey && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(details.trigger)) {
                highlightTrigger(details.trigger, details.event);
                // `MenuPopup` returns focus through `getReturnElement`, so point it at the element that
                // can hold real focus: the parent's input, not its untabbable trigger.
                parentReferenceRef.current = {
                    reference: parent.virtualFocus ? parentStore.context.virtualFocusRef?.current ?? details.trigger : details.trigger,
                    trigger: details.trigger
                };
            }
            return;
        }
        parentReferenceRef.current = null;
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(details.trigger) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$isKeyboardOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isKeyboardOpen"])(details.reason, details.event)) {
            // A keyboard click reports its click, which isn't the key that opened the submenu.
            handleSubmenuEnter(details.trigger, details.reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation ? details.event : undefined);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRootInternal"], {
        ...rootProps,
        isSubmenu: true,
        disabled: parentDisabled || props.disabled,
        onOpenChange: handleOpenChange,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuFilterSubmenuNavigation, {
            parentStore: parentStore,
            parentVirtualFocus: parent.virtualFocus,
            parentAllowEscape: parent.virtualFocus && parent.allowEscape,
            parentOrientation: parent.orientation,
            parentLoopFocus: parent.loopFocus,
            getReturnElement: ()=>parentReferenceRef.current?.reference ?? (parent.virtualFocus ? parentStore.context.virtualFocusRef?.current : null) ?? null,
            onSubmenuEnter: handleSubmenuEnter,
            onSubmenuExit: handleSubmenuExit,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterDropdown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterDropdown"], {
                ...dropdownProps,
                children: props.children
            })
        })
    });
}
function MenuFilterSubmenuNavigation(props) {
    const { children, parentStore, parentVirtualFocus, parentAllowEscape, parentOrientation, parentLoopFocus, onSubmenuEnter, onSubmenuExit, getReturnElement } = props;
    const { store, orientation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    const mounted = store.useState('mounted');
    const wasMountedRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const handleReturnFocus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterSubmenuNavigation.useStableCallback[handleReturnFocus]": ()=>{
            // A plain parent has no input to return to. Focus the trigger this submenu opened from, as a
            // plain submenu does, so a hover close doesn't strand focus on the body.
            const [ownTrigger] = store.context.triggerElements.elements();
            return getReturnElement() ?? ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(ownTrigger) ? ownTrigger : null);
        }
    }["MenuFilterSubmenuNavigation.useStableCallback[handleReturnFocus]"]);
    // A hover close makes the focus manager skip its return focus, which would strand the
    // submenu input's focus on the body once the popup unmounts. This runs in the effect body
    // rather than a cleanup: React drops the focus event when it fires during the mutation phase,
    // so the input would never learn it holds focus.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuFilterSubmenuNavigation.useIsoLayoutEffect": ()=>{
            const wasMounted = wasMountedRef.current;
            wasMountedRef.current = mounted;
            if (mounted || !wasMounted) {
                return;
            }
            const returnElement = handleReturnFocus();
            if (!returnElement || !parentStore.select('open')) {
                return;
            }
            const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(returnElement);
            const activeEl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])(doc);
            if (activeEl === doc.body || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(store.select('popupElement'), activeEl)) {
                returnElement.focus({
                    preventScroll: true
                });
            }
        }
    }["MenuFilterSubmenuNavigation.useIsoLayoutEffect"], [
        mounted,
        store,
        parentStore,
        handleReturnFocus
    ]);
    function moveInParent(from, event) {
        const item = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$moveHighlightFrom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["moveHighlightFrom"])(parentStore, from, event, {
            orientation: parentOrientation,
            rtl: direction === 'rtl',
            loopFocus: parentLoopFocus,
            allowEscape: parentAllowEscape
        });
        if (!parentVirtualFocus) {
            item?.focus({
                preventScroll: true
            });
        }
    }
    function close(event) {
        if (!store.select('open')) {
            return;
        }
        // The key can reach this popup re-dispatched on its highlighted item, so it can't be left to
        // bubble to the parent. A close key that also navigates the parent moves it from here.
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stopEvent"])(event);
        const trigger = store.select('activeTriggerElement');
        const eventDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation, event.nativeEvent);
        store.setOpen(false, eventDetails);
        if (!eventDetails.isCanceled) {
            onSubmenuExit(event.nativeEvent);
        }
        // `onSubmenuExit` bails when the submenu was opened by pointer, so return focus here.
        const returnElement = getReturnElement() ?? store.select('activeTriggerElement');
        if (!store.select('open') && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(returnElement) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(returnElement)) !== returnElement) {
            returnElement.focus();
        }
        if (!store.select('open') && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(trigger) && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMainOrientationKey"])(event.key, parentOrientation)) {
            moveInParent(trigger, event);
        }
    }
    const handleTriggerKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterSubmenuNavigation.useStableCallback[handleTriggerKeyDown]": (event)=>{
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMainOrientationKey"])(event.key, parentOrientation)) {
                moveInParent(event.currentTarget, event);
                event.preventBaseUIHandler();
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stopEvent"])(event);
                return;
            }
            const open = store.select('open');
            const isRtl = direction === 'rtl';
            const isCloseKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOrientationCloseKey"])(event.key, orientation, isRtl, false);
            if (open && isCloseKey) {
                close(event);
                return;
            }
            const isOpenKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOrientationOpenKey"])(event.key, parentOrientation, isRtl);
            if (!isOpenKey) {
                return;
            }
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$utils$2f$event$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["stopEvent"])(event);
            if (open) {
                // Re-entering an already-open submenu hands the cursor to its own focus owner. The submenu
                // is always virtually focused, so there is no roving-focus branch here. The highlight is
                // kept, so an automatic highlight or an earlier keyboard position survives re-entry.
                onSubmenuEnter(event.currentTarget, event.nativeEvent);
                store.context.virtualFocusRef?.current?.focus({
                    preventScroll: true
                });
                return;
            }
            store.setOpen(true, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation, event.nativeEvent, event.currentTarget));
        }
    }["MenuFilterSubmenuNavigation.useStableCallback[handleTriggerKeyDown]"]);
    const handlePopupKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuFilterSubmenuNavigation.useStableCallback[handlePopupKeyDown]": (event)=>{
            // A key that composes text in the input must not close the submenu.
            if (event.which === 229) {
                return;
            }
            const isCloseKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCrossOrientationCloseKey"])(event.key, orientation, direction === 'rtl', false);
            if (isCloseKey) {
                close(event);
            }
        }
    }["MenuFilterSubmenuNavigation.useStableCallback[handlePopupKeyDown]"]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuFilterSubmenuNavigation.useMemo[contextValue]": ()=>({
                getReturnElement: handleReturnFocus,
                onTriggerKeyDown: handleTriggerKeyDown,
                onPopupKeyDown: handlePopupKeyDown
            })
    }["MenuFilterSubmenuNavigation.useMemo[contextValue]"], [
        handleReturnFocus,
        handleTriggerKeyDown,
        handlePopupKeyDown
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuSubmenuRootContext"].Provider, {
        value: contextValue,
        children: children
    });
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group-label/MenuGroupLabel.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuGroupLabel",
    ()=>MenuGroupLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroupContext.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const MenuGroupLabel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuGroupLabel(componentProps, forwardedRef) {
    const { render, className, style, id: idProp, ...elementProps } = componentProps;
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const setLabelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuGroupRootContext"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuGroupLabel.MenuGroupLabel.useIsoLayoutEffect": ()=>{
            setLabelId(id);
            return ({
                "MenuGroupLabel.MenuGroupLabel.useIsoLayoutEffect": ()=>{
                    setLabelId({
                        "MenuGroupLabel.MenuGroupLabel.useIsoLayoutEffect": (currentId)=>currentId === id ? undefined : currentId
                    }["MenuGroupLabel.MenuGroupLabel.useIsoLayoutEffect"]);
                }
            })["MenuGroupLabel.MenuGroupLabel.useIsoLayoutEffect"];
        }
    }["MenuGroupLabel.MenuGroupLabel.useIsoLayoutEffect"], [
        setLabelId,
        id
    ]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: forwardedRef,
        props: {
            id,
            'aria-hidden': true,
            ...elementProps
        }
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuGroupLabel.displayName = "MenuGroupLabel";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuGroup",
    ()=>MenuGroup,
    "MenuGroupPlain",
    ()=>MenuGroupPlain
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroupContext.mjs [app-client] (ecmascript)");
/**
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const MenuGroupPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuGroupPlain(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    const [labelId, setLabelId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](undefined);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: forwardedRef,
        props: {
            role: 'group',
            'aria-labelledby': labelId,
            ...elementProps
        }
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuGroupContext"].Provider, {
        value: setLabelId,
        children: element
    });
});
/**
 * Groups related menu items with the corresponding label.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuGroupPlain.displayName = "MenuGroupPlain";
const MenuGroup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuGroup(props, forwardedRef) {
    const Group = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterImpl"])()?.Group ?? MenuGroupPlain;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Group, {
        ...props,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuGroup.displayName = "MenuGroup";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroupContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuGroupContext",
    ()=>MenuGroupContext,
    "useMenuGroupRootContext",
    ()=>useMenuGroupRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuGroupContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuGroupContext.displayName = "MenuGroupContext";
function useMenuGroupRootContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuGroupContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenuGroupContext is missing. Menu group parts must be used within <Menu.Group> or <Menu.RadioGroup>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/index.parts.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Arrow",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$arrow$2f$MenuArrow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuArrow"],
    "Backdrop",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$backdrop$2f$MenuBackdrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuBackdrop"],
    "CheckboxItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuCheckboxItem"],
    "CheckboxItemIndicator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2d$indicator$2f$MenuCheckboxItemIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuCheckboxItemIndicator"],
    "Clear",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$clear$2f$MenuClear$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuClear"],
    "Empty",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$empty$2f$MenuEmpty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuEmpty"],
    "FilterProvider",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterProvider"],
    "Group",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuGroup"],
    "GroupLabel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2d$label$2f$MenuGroupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuGroupLabel"],
    "Handle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuHandle"],
    "Input",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$input$2f$MenuInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuInput"],
    "Item",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$MenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuItem"],
    "LinkItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$link$2d$item$2f$MenuLinkItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuLinkItem"],
    "List",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$list$2f$MenuList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuList"],
    "Popup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$popup$2f$MenuPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuPopup"],
    "Portal",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$portal$2f$MenuPortal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuPortal"],
    "Positioner",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositioner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuPositioner"],
    "RadioGroup",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRadioGroup"],
    "RadioItem",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2f$MenuRadioItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRadioItem"],
    "RadioItemIndicator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2d$indicator$2f$MenuRadioItemIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRadioItemIndicator"],
    "Root",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRoot"],
    "Separator",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$separator$2f$Separator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Separator"],
    "SubmenuRoot",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MenuSubmenuRoot"],
    "SubmenuTrigger",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$trigger$2f$MenuSubmenuTrigger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuSubmenuTrigger"],
    "Trigger",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$trigger$2f$MenuTrigger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuTrigger"],
    "Viewport",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$viewport$2f$MenuViewport$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuViewport"],
    "createHandle",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createMenuHandle"],
    "useFilter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$filter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilter"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/index.parts.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$arrow$2f$MenuArrow$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/arrow/MenuArrow.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$backdrop$2f$MenuBackdrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/backdrop/MenuBackdrop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2d$indicator$2f$MenuCheckboxItemIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item-indicator/MenuCheckboxItemIndicator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2d$label$2f$MenuGroupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group-label/MenuGroupLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$MenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/MenuItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$link$2d$item$2f$MenuLinkItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/link-item/MenuLinkItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$popup$2f$MenuPopup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/popup/MenuPopup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$portal$2f$MenuPortal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/portal/MenuPortal.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositioner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositioner.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroup$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroup.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2f$MenuRadioItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item/MenuRadioItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2d$indicator$2f$MenuRadioItemIndicator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item-indicator/MenuRadioItemIndicator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRoot.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$trigger$2f$MenuTrigger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/trigger/MenuTrigger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$viewport$2f$MenuViewport$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/viewport/MenuViewport.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$separator$2f$Separator$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/separator/Separator.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$trigger$2f$MenuSubmenuTrigger$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-trigger/MenuSubmenuTrigger.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/store/MenuHandle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-provider/MenuFilterProvider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$input$2f$MenuInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/input/MenuInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$list$2f$MenuList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/list/MenuList.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$clear$2f$MenuClear$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/clear/MenuClear.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$empty$2f$MenuEmpty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/empty/MenuEmpty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$filter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/filter.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/index.parts.mjs [app-client] (ecmascript) <export * as Menu>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Menu",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/index.parts.mjs [app-client] (ecmascript)");
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/index.parts.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/input/MenuInput.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuInput",
    ()=>MenuInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useMergedRefs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$input$2f$FilterDropdownInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/input/FilterDropdownInput.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterKeyDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/useMenuFilterKeyDown.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
/**
 * A search field that filters the menu items.
 * Requires the menu to be wrapped in `Menu.FilterProvider`.
 * Renders an `<input>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
const MenuInput = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuInput(componentProps, forwardedRef) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterPart"])('Input');
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownValueContext"])();
    const { onKeyDown, ...navigationProps } = store.useState('inputProps');
    const activeItemId = store.useState('highlightedItemId');
    const handleKeyDown = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$useMenuFilterKeyDown$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterKeyDown"])(value !== '');
    const handleInputRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "MenuInput.MenuInput.useCallback[handleInputRef]": (input)=>{
            // Ref changes cover input removal without blur and restore focus after Strict Mode replay.
            store.set('inputFocused', input !== null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["activeElement"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(input)) === input);
        }
    }["MenuInput.MenuInput.useCallback[handleInputRef]"], [
        store
    ]);
    const mergedRefs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(forwardedRef, handleInputRef);
    const inputProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])({
        onKeyDown: handleKeyDown,
        onFocus () {
            store.set('inputFocused', true);
        },
        onBlur () {
            store.set('inputFocused', false);
        }
    }, componentProps);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$input$2f$FilterDropdownInput$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownInput"], {
        ...inputProps,
        activeItemId: activeItemId,
        navigationProps: navigationProps,
        ref: mergedRefs
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuInput.displayName = "MenuInput";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/MenuItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuItem",
    ()=>MenuItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const MenuItemPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuItemPlain(componentProps, forwardedRef) {
    const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = true, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const listItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])({
        guess: true,
        label
    });
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const rootDisabled = store.useState('disabled');
    const highlighted = store.useState('isActive', listItem.index);
    const nodeId = store.useState('floatingNodeId');
    const itemProps = store.useState('itemProps');
    const disabled = disabledProp || rootDisabled;
    const { getItemProps, itemRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuItem"])({
        closeOnClick,
        disabled,
        highlighted,
        id,
        store,
        nativeButton,
        nodeId,
        itemMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REGULAR_ITEM"]
    });
    const state = {
        disabled,
        highlighted
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        props: [
            itemProps,
            elementProps,
            getItemProps
        ],
        ref: [
            itemRef,
            forwardedRef,
            listItem.ref
        ]
    });
});
/**
 * An individual interactive item in the menu.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuItemPlain.displayName = "MenuItemPlain";
const MenuItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuItem(props, forwardedRef) {
    const filterItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterItem"])(props, forwardedRef);
    if (!filterItem.visible) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuItemPlain, {
        ...props,
        ref: filterItem.ref
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuItem.displayName = "MenuItem";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "REGULAR_ITEM",
    ()=>REGULAR_ITEM,
    "useMenuItem",
    ()=>useMenuItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useMergedRefs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/use-button/useButton.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItemCommonProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItemCommonProps.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const REGULAR_ITEM = {
    type: 'regular-item'
};
function useMenuItem(params) {
    const { closeOnClick, disabled, highlighted, id, store, typingRef = store.context.typingRef, nativeButton, itemMetadata, nodeId } = params;
    const itemRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const { getButtonProps, buttonRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        disabled,
        focusableWhenDisabled: true,
        native: nativeButton,
        composite: true
    });
    const commonProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItemCommonProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuItemCommonProps"])({
        closeOnClick,
        highlighted,
        id,
        nodeId,
        store,
        typingRef,
        itemRef,
        itemMetadata
    });
    const getItemProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useMenuItem.useCallback[getItemProps]": (externalProps)=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(commonProps, {
                onMouseEnter (event) {
                    if (itemMetadata.type !== 'submenu-trigger') {
                        return;
                    }
                    itemMetadata.setActive(event.nativeEvent);
                }
            }, externalProps, getButtonProps);
        }
    }["useMenuItem.useCallback[getItemProps]"], [
        commonProps,
        getButtonProps,
        itemMetadata
    ]);
    const mergedRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(itemRef, buttonRef);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useMenuItem.useMemo": ()=>({
                getItemProps,
                itemRef: mergedRef
            })
    }["useMenuItem.useMemo"], [
        getItemProps,
        mergedRef
    ]);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItemCommonProps.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useMenuItemCommonProps",
    ()=>useMenuItemCommonProps
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/platform/parts.mjs [app-client] (ecmascript) <export * as platform>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$dispatchClickWithModifiers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/dispatchClickWithModifiers.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
function preventMouseDownDefault(event) {
    event.preventDefault();
}
function useMenuItemCommonProps(params) {
    const { closeOnClick, highlighted, id, nodeId, store, typingRef, itemRef, itemMetadata } = params;
    const rootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const contextMenuContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContextMenuRootContext"])(true);
    // A submenu trigger is an item of the parent menu's list, so it follows that list's focus model.
    const isSubmenuTrigger = itemMetadata.type === 'submenu-trigger';
    const virtualFocus = isSubmenuTrigger ? rootContext.parentVirtualFocus : rootContext.virtualFocus;
    const selectionStore = isSubmenuTrigger && rootContext.parent.type === 'menu' ? rootContext.parent.store : rootContext.store;
    const ariaSelected = selectionStore.useState('webkitAriaSelected', highlighted);
    const { events: menuEvents } = store.useState('floatingTreeRoot');
    const open = store.useState('open');
    const isContextMenu = contextMenuContext !== undefined;
    // `-1` rather than omitting it, which leaves links and buttons in the tab order.
    const tabIndex = !virtualFocus && open && highlighted ? 0 : -1;
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useMenuItemCommonProps.useMemo": ()=>({
                id,
                role: 'menuitem',
                tabIndex,
                'aria-selected': ariaSelected,
                // Real focus stays on the input or list that owns virtual navigation.
                onMouseDown: virtualFocus ? preventMouseDownDefault : undefined,
                onKeyDown (event) {
                    if (event.key === ' ' && typingRef?.current) {
                        event.preventDefault();
                    }
                },
                onMouseMove (event) {
                    if (!nodeId) {
                        return;
                    }
                    // Inform the floating tree that a menu item within this menu was hovered/moved over
                    // so unrelated descendant submenus can be closed.
                    menuEvents.emit('itemhover', {
                        nodeId,
                        target: event.currentTarget
                    });
                },
                onClick (event) {
                    if (closeOnClick) {
                        menuEvents.emit('close', {
                            domEvent: event.nativeEvent,
                            reason: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].itemPress
                        });
                    }
                },
                onMouseUp (event) {
                    if (contextMenuContext) {
                        const initialCursorPoint = contextMenuContext.initialCursorPointRef.current;
                        contextMenuContext.initialCursorPointRef.current = null;
                        if (isContextMenu && initialCursorPoint && Math.abs(event.clientX - initialCursorPoint.x) <= 1 && Math.abs(event.clientY - initialCursorPoint.y) <= 1) {
                            return;
                        }
                        // On non-macOS platforms, this mouseup belongs to the right-click gesture
                        // that opened the context menu, so it must not activate an item.
                        if (isContextMenu && !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__["platform"].os.mac && event.button === 2) {
                            return;
                        }
                    }
                    if (itemRef.current && store.context.allowMouseUpTriggerRef.current && (!isContextMenu || event.button === 2)) {
                        // This fires whenever the user clicks on the trigger, moves the cursor, and releases it over the item.
                        // We trigger the click and override the `closeOnClick` preference to always close the menu.
                        if (itemMetadata.type === 'regular-item') {
                            // `detail: 1` and `pointerType: 'mouse'` mark this as a mouse-gesture click so
                            // MenuRoot and FloatingFocusManager don't treat it as a keyboard activation.
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$dispatchClickWithModifiers$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["dispatchClickWithModifiers"])(itemRef.current, event, {
                                detail: 1,
                                pointerType: 'mouse'
                            });
                        }
                    }
                }
            })
    }["useMenuItemCommonProps.useMemo"], [
        closeOnClick,
        tabIndex,
        id,
        menuEvents,
        nodeId,
        store.context.allowMouseUpTriggerRef,
        typingRef,
        itemRef,
        contextMenuContext,
        isContextMenu,
        itemMetadata.type,
        ariaSelected,
        virtualFocus
    ]);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/link-item/MenuLinkItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuLinkItem",
    ()=>MenuLinkItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItemCommonProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItemCommonProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/use-button/useButton.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
const MenuLinkItemPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuLinkItemPlain(componentProps, forwardedRef) {
    const { render, className, id: idProp, label, closeOnClick = false, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const linkRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const listItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])({
        guess: true,
        label
    });
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const highlighted = store.useState('isActive', listItem.index);
    const nodeId = store.useState('floatingNodeId');
    const itemProps = store.useState('itemProps');
    const typingRef = store.context.typingRef;
    const { getButtonProps, buttonRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        native: false,
        composite: true
    });
    const commonProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItemCommonProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuItemCommonProps"])({
        closeOnClick,
        highlighted,
        id,
        nodeId,
        store,
        typingRef,
        itemRef: linkRef,
        itemMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REGULAR_ITEM"]
    });
    function getItemProps(externalProps) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(commonProps, externalProps, getButtonProps);
    }
    const state = {
        highlighted
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('a', componentProps, {
        state,
        props: [
            itemProps,
            elementProps,
            getItemProps
        ],
        ref: [
            linkRef,
            buttonRef,
            forwardedRef,
            listItem.ref
        ]
    });
});
/**
 * A link in the menu that can be used to navigate to a different page or section.
 * Renders an `<a>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuLinkItemPlain.displayName = "MenuLinkItemPlain";
const MenuLinkItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuLinkItem(props, forwardedRef) {
    // The public ref type stays `Element` as before; the rendered `<a>` is always an `HTMLElement`.
    const filterItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterItem"])(props, forwardedRef);
    if (!filterItem.visible) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuLinkItemPlain, {
        ...props,
        ref: filterItem.ref
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuLinkItem.displayName = "MenuLinkItem";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/list/MenuList.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuList",
    ()=>MenuList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolvePopupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/resolvePopupLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const MenuListPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuListPlain(componentProps, forwardedRef) {
    const { render, className, style, id: idProp, ...elementProps } = componentProps;
    const { store, orientation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const activeTriggerId = store.useState('activeTriggerId');
    const activeTriggerElement = store.useState('activeTriggerElement');
    const setListElement = store.useStateSetter('listElement');
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    // The trigger reads `aria-controls` off the stored element, which an id change alone leaves in
    // place, so subscribers are told to read it again. Mounting publishes the element itself.
    const renderedIdRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](id);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuListPlain.MenuListPlain.useIsoLayoutEffect": ()=>{
            if (renderedIdRef.current !== id) {
                renderedIdRef.current = id;
                store.notifyAll();
            }
        }
    }["MenuListPlain.MenuListPlain.useIsoLayoutEffect"], [
        id,
        store
    ]);
    const ariaLabelledBy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolvePopupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolvePopupLabel"])(componentProps, activeTriggerElement, activeTriggerId);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: [
            forwardedRef,
            setListElement
        ],
        props: [
            {
                id,
                role: 'menu',
                // The popup focuses the list on a pointer open in place of itself.
                tabIndex: -1,
                // `menu` is implicitly vertical, so only the non-default value needs to be rendered.
                'aria-orientation': orientation === 'horizontal' ? 'horizontal' : undefined,
                'aria-labelledby': ariaLabelledBy
            },
            elementProps
        ]
    });
});
/**
 * Groups menu items so other content, such as a filter input, can share the popup.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuListPlain.displayName = "MenuListPlain";
const MenuList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuList(props, forwardedRef) {
    const List = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterImpl"])()?.List ?? MenuListPlain;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(List, {
        ...props,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuList.displayName = "MenuList";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/popup/MenuPopup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuPopup",
    ()=>MenuPopup,
    "MenuPopupPlain",
    ()=>MenuPopupPlain
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingFocusManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingFocusManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useHoverFloatingInteraction$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useHoverFloatingInteraction.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popupStateMapping.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useOpenChangeComplete.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$toolbar$2f$root$2f$ToolbarRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/toolbar/root/ToolbarRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/composite.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$getDisabledMountTransitionStyles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/getDisabledMountTransitionStyles.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolveRenderedId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/resolveRenderedId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolvePopupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/resolvePopupLabel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuPopupPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuPopupPlain(componentProps, forwardedRef) {
    const { render, className, style, finalFocus, id: idProp, initialFocus: initialFocusProp, ...elementProps } = componentProps;
    const { store, defaultFloatingId, setRenderedFloatingId, virtualFocus, orientation } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const inheritedSubmenuRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuSubmenuRootContext"])();
    const { side, align } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuPositionerContext"])();
    const insideToolbar = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$toolbar$2f$root$2f$ToolbarRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToolbarRootContext"])(true) != null;
    const open = store.useState('open');
    const transitionStatus = store.useState('transitionStatus');
    const popupProps = store.useState('popupProps');
    const mounted = store.useState('mounted');
    const instantType = store.useState('instantType');
    const activeTriggerElement = store.useState('activeTriggerElement');
    const parent = store.useState('parent');
    const lastOpenChangeReason = store.useState('lastOpenChangeReason');
    const rootId = store.useState('rootId');
    const floatingContext = store.useState('floatingRootContext');
    const floatingTreeRoot = store.useState('floatingTreeRoot');
    const closeDelay = store.useState('closeDelay');
    const hoverEnabled = store.useState('hoverEnabled');
    const disabled = store.useState('disabled');
    const openMethod = store.useState('openMethod');
    const activeTriggerId = store.useState('activeTriggerId');
    const listElement = store.useState('listElement');
    const [id, registerIdRef] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolveRenderedId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderedId"])(componentProps, defaultFloatingId, setRenderedFloatingId);
    const ariaLabelledBy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolvePopupLabel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolvePopupLabel"])(componentProps, activeTriggerElement, activeTriggerId);
    // A dialog's menu can render under a submenu provider; only the actual submenu inherits it.
    const submenuRootContext = parent.type === 'menu' ? inheritedSubmenuRootContext : undefined;
    const isContextMenu = parent.type === 'context-menu';
    let initialFocus = initialFocusProp ?? parent.type !== 'menu';
    if (initialFocusProp === undefined && listElement && parent.type !== 'menu') {
        initialFocus = ()=>{
            // A keyboard or screen reader open highlights an item, which list navigation focuses.
            if (store.state.activeIndex !== null) {
                return false;
            }
            // The list holds the `menu` role, so a pointer open lands focus on it rather than on the
            // presentational popup.
            return listElement;
        };
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeComplete"])({
        open,
        ref: store.context.popupRef,
        onComplete () {
            if (open) {
                store.context.onOpenChangeComplete?.(true);
            }
        }
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuPopupPlain.MenuPopupPlain.useEffect": ()=>{
            function handleClose(event) {
                store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(event.reason, event.domEvent));
            }
            floatingTreeRoot.events.on('close', handleClose);
            return ({
                "MenuPopupPlain.MenuPopupPlain.useEffect": ()=>{
                    floatingTreeRoot.events.off('close', handleClose);
                }
            })["MenuPopupPlain.MenuPopupPlain.useEffect"];
        }
    }["MenuPopupPlain.MenuPopupPlain.useEffect"], [
        floatingTreeRoot.events,
        store
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useHoverFloatingInteraction$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHoverFloatingInteraction"])(floatingContext, {
        enabled: hoverEnabled && !disabled && !isContextMenu && parent.type !== 'menubar',
        closeDelay
    });
    const setPopupElement = store.useStateSetter('popupElement');
    // Only a menu under a filter root bundles the handoff to a filterable parent. Whether one is
    // above is fixed for a mounted popup, so the hook doesn't change between renders.
    const useParentHandoff = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterImplContext"])?.useParentHandoff ?? useNoParentHandoff;
    const { parentVirtualFocusRef, handleFocus } = useParentHandoff(store, parent, open, virtualFocus);
    const state = {
        transitionStatus,
        side,
        align,
        open,
        nested: parent.type === 'menu',
        instant: instantType
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: [
            forwardedRef,
            store.context.popupRef,
            setPopupElement,
            registerIdRef
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["popupTransitionStateMapping"],
        props: [
            popupProps,
            {
                id,
                // A rendered `Menu.List` carries the `menu` semantics instead.
                ...listElement ? {
                    role: 'presentation'
                } : {
                    role: 'menu',
                    // `menu` is implicitly vertical, so only the non-default value needs to be
                    // rendered.
                    'aria-orientation': orientation === 'horizontal' ? 'horizontal' : undefined,
                    'aria-labelledby': ariaLabelledBy
                },
                onKeyDown (event) {
                    submenuRootContext?.onPopupKeyDown?.(event);
                    if (insideToolbar && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$composite$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["COMPOSITE_KEYS"].has(event.key)) {
                        event.stopPropagation();
                    }
                },
                onFocus: handleFocus
            },
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$getDisabledMountTransitionStyles$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisabledMountTransitionStyles"])(transitionStatus),
            elementProps,
            {
                'data-rootownerid': rootId
            }
        ]
    });
    let returnFocus = parent.type === undefined || isContextMenu;
    if (activeTriggerElement || parent.type === 'menubar' && lastOpenChangeReason !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].outsidePress) {
        returnFocus = true;
    }
    // Internal defaults rather than consumer targets, so focus that already moved is respected.
    const dynamicReturnFocus = submenuRootContext?.getReturnElement ?? parentVirtualFocusRef;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingFocusManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingFocusManager"], {
        context: floatingContext,
        openInteractionType: openMethod,
        modal: isContextMenu,
        disabled: !mounted,
        returnFocus: finalFocus ?? dynamicReturnFocus ?? returnFocus,
        explicitReturnFocus: finalFocus === undefined && dynamicReturnFocus ? false : undefined,
        initialFocus: initialFocus,
        restoreFocus: true,
        getInsideElements: parent.type === undefined ? ()=>[
                store.context.beforeTriggerFocusGuardRef.current
            ] : undefined,
        externalTree: parent.type !== 'menubar' ? floatingTreeRoot : undefined,
        previousFocusableElement: activeTriggerElement,
        nextFocusableElement: parent.type === undefined ? store.context.triggerFocusTargetRef : undefined,
        beforeContentFocusGuardRef: store.context.beforeContentFocusGuardRef,
        children: element
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuPopupPlain.displayName = "MenuPopupPlain";
const NO_PARENT_HANDOFF = {
    parentVirtualFocusRef: undefined,
    handleFocus: undefined
};
function useNoParentHandoff() {
    return NO_PARENT_HANDOFF;
}
const MenuPopup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuPopup(props, forwardedRef) {
    const Popup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterImpl"])()?.Popup ?? MenuPopupPlain;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(Popup, {
        ...props,
        ref: forwardedRef
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuPopup.displayName = "MenuPopup";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/portal/MenuPortal.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuPortal",
    ()=>MenuPortal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingPortal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingPortal.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$portal$2f$MenuPortalContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/portal/MenuPortalContext.mjs [app-client] (ecmascript)");
/**
 * A portal element that moves the popup to a different part of the DOM.
 * By default, the portal element is appended to `<body>`.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const MenuPortal = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuPortal(props, forwardedRef) {
    const { keepMounted = false, ...portalProps } = props;
    const { store, parent } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const mounted = store.useState('mounted');
    const shouldRender = mounted || keepMounted;
    if (!shouldRender) {
        return null;
    }
    // The hidden `aria-owns` owner renders here, in the React tree, so the role must be decided by
    // where this portal sits, not by the active trigger. `parent` comes from context (the `Menu.Root`
    // position), unlike the store's `parent`, which a detached trigger overwrites with its own.
    const portalOwnerRole = parent.type === 'menu' || parent.type === 'menubar' ? 'group' : undefined;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$portal$2f$MenuPortalContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuPortalContext"].Provider, {
        value: keepMounted,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingPortal$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingPortal"], {
            ref: forwardedRef,
            ...portalProps,
            portalOwnerRole: portalOwnerRole
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuPortal.displayName = "MenuPortal";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/portal/MenuPortalContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuPortalContext",
    ()=>MenuPortalContext,
    "useMenuPortalContext",
    ()=>useMenuPortalContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuPortalContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuPortalContext.displayName = "MenuPortalContext";
function useMenuPortalContext() {
    const value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuPortalContext);
    if (value === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: <Menu.Portal> is missing.' : "TURBOPACK unreachable");
    }
    return value;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositioner.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuPositioner",
    ()=>MenuPositioner
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$inertValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/inertValue.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useTimeout.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingTree.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useAnchorPositioning$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useAnchorPositioning.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/CompositeList.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$InternalBackdrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/InternalBackdrop.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$portal$2f$MenuPortalContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/portal/MenuPortalContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTriggerSwitchTransition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useTriggerSwitchTransition.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$usePositioner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/usePositioner.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useAnchoredPopupScrollLock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/useAnchoredPopupScrollLock.mjs [app-client] (ecmascript)");
/**
 * Positions the menu popup against the trigger.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuPositioner = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuPositioner(componentProps, forwardedRef) {
    const { anchor: anchorProp, positionMethod: positionMethodProp = 'absolute', className, render, side, align: alignProp, sideOffset: sideOffsetProp = 0, alignOffset: alignOffsetProp = 0, collisionBoundary = 'clipping-ancestors', collisionPadding = 5, arrowPadding = 5, sticky = false, disableAnchorTracking = false, collisionAvoidance: collisionAvoidanceProp = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DROPDOWN_COLLISION_AVOIDANCE"], style, ...elementProps } = componentProps;
    const { store, virtualFocus, syncHighlightedItem } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const keepMounted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$portal$2f$MenuPortalContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuPortalContext"])();
    const contextMenuContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContextMenuRootContext"])(true);
    const parent = store.useState('parent');
    const floatingRootContext = store.useState('floatingRootContext');
    const floatingTreeRoot = store.useState('floatingTreeRoot');
    const mounted = store.useState('mounted');
    const open = store.useState('open');
    const modal = store.useState('modal');
    const openMethod = store.useState('openMethod');
    const triggerElement = store.useState('activeTriggerElement');
    const transitionStatus = store.useState('transitionStatus');
    const positionerElement = store.useState('positionerElement');
    const instantType = store.useState('instantType');
    const adaptiveOrigin = store.useState('adaptiveOrigin');
    const lastOpenChangeReason = store.useState('lastOpenChangeReason');
    const floatingNodeId = store.useState('floatingNodeId');
    const floatingParentNodeId = store.useState('floatingParentNodeId');
    const domReference = floatingRootContext.useState('domReferenceElement');
    let anchor = anchorProp;
    let sideOffset = sideOffsetProp;
    let alignOffset = alignOffsetProp;
    let align = alignProp;
    let collisionAvoidance = collisionAvoidanceProp;
    if (parent.type === 'context-menu') {
        anchor = anchorProp ?? parent.context?.anchor;
        align = align ?? 'start';
        if (!side && align !== 'center') {
            alignOffset = componentProps.alignOffset ?? 2;
            sideOffset = componentProps.sideOffset ?? -5;
        }
    }
    let computedSide = side;
    let computedAlign = align;
    if (parent.type === 'menu') {
        computedSide = computedSide ?? 'inline-end';
        computedAlign = computedAlign ?? 'start';
        collisionAvoidance = componentProps.collisionAvoidance ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["POPUP_COLLISION_AVOIDANCE"];
    } else if (parent.type === 'menubar') {
        computedSide = computedSide ?? (parent.context.orientation === 'vertical' ? 'inline-end' : 'bottom');
        computedAlign = computedAlign ?? 'start';
    }
    const contextMenu = parent.type === 'context-menu';
    const positioner = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useAnchorPositioning$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnchorPositioning"])({
        anchor,
        floatingRootContext,
        positionMethod: contextMenuContext ? 'fixed' : positionMethodProp,
        mounted,
        side: computedSide,
        sideOffset,
        align: computedAlign,
        alignOffset,
        arrowPadding: contextMenu ? 0 : arrowPadding,
        collisionBoundary,
        collisionPadding,
        sticky,
        nodeId: floatingNodeId,
        keepMounted,
        disableAnchorTracking,
        collisionAvoidance,
        shift: contextMenu ? {
            crossAxis: !('side' in collisionAvoidance && collisionAvoidance.side === 'flip'),
            rootBoundary: 'layoutViewport'
        } : undefined,
        externalTree: floatingTreeRoot,
        adaptiveOrigin,
        lazyFlip: virtualFocus ? 'placement' : false
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuPositioner.MenuPositioner.useEffect": ()=>{
            function onMenuOpenChange(details) {
                if (details.open) {
                    if (details.parentNodeId === floatingNodeId) {
                        store.set('hoverEnabled', false);
                    }
                    if (details.nodeId !== floatingNodeId && details.parentNodeId === store.select('floatingParentNodeId')) {
                        store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].siblingOpen));
                    }
                }
            }
            floatingTreeRoot.events.on('menuopenchange', onMenuOpenChange);
            return ({
                "MenuPositioner.MenuPositioner.useEffect": ()=>{
                    floatingTreeRoot.events.off('menuopenchange', onMenuOpenChange);
                }
            })["MenuPositioner.MenuPositioner.useEffect"];
        }
    }["MenuPositioner.MenuPositioner.useEffect"], [
        store,
        floatingTreeRoot.events,
        floatingNodeId
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuPositioner.MenuPositioner.useEffect": ()=>{
            if (store.select('floatingParentNodeId') == null) {
                return undefined;
            }
            function onParentClose(details) {
                if (details.open || details.nodeId !== store.select('floatingParentNodeId')) {
                    return;
                }
                const reason = details.reason ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].siblingOpen;
                store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(reason));
            }
            floatingTreeRoot.events.on('menuopenchange', onParentClose);
            return ({
                "MenuPositioner.MenuPositioner.useEffect": ()=>{
                    floatingTreeRoot.events.off('menuopenchange', onParentClose);
                }
            })["MenuPositioner.MenuPositioner.useEffect"];
        }
    }["MenuPositioner.MenuPositioner.useEffect"], [
        floatingTreeRoot.events,
        store
    ]);
    const closeTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    // Clear pending close timeout when the menu closes.
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuPositioner.MenuPositioner.useEffect": ()=>{
            if (!open) {
                closeTimeout.clear();
            }
        }
    }["MenuPositioner.MenuPositioner.useEffect"], [
        open,
        closeTimeout
    ]);
    // Close unrelated child submenus when hovering a different item in the parent menu.
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuPositioner.MenuPositioner.useEffect": ()=>{
            function onItemHover(event) {
                // If an item within our parent menu is hovered, and this menu's trigger is not that item,
                // close this submenu. This ensures hovering a different item in the parent closes other branches.
                if (!open || event.nodeId !== store.select('floatingParentNodeId')) {
                    return;
                }
                if (event.target && triggerElement && triggerElement !== event.target) {
                    const delay = store.select('closeDelay');
                    if (delay > 0) {
                        if (!closeTimeout.isStarted()) {
                            closeTimeout.start(delay, {
                                "MenuPositioner.MenuPositioner.useEffect.onItemHover": ()=>{
                                    store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].siblingOpen));
                                }
                            }["MenuPositioner.MenuPositioner.useEffect.onItemHover"]);
                        }
                    } else {
                        store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].siblingOpen));
                    }
                } else {
                    // User re-hovered the submenu trigger, cancel pending close.
                    closeTimeout.clear();
                }
            }
            floatingTreeRoot.events.on('itemhover', onItemHover);
            return ({
                "MenuPositioner.MenuPositioner.useEffect": ()=>{
                    floatingTreeRoot.events.off('itemhover', onItemHover);
                }
            })["MenuPositioner.MenuPositioner.useEffect"];
        }
    }["MenuPositioner.MenuPositioner.useEffect"], [
        floatingTreeRoot.events,
        open,
        triggerElement,
        store,
        closeTimeout
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuPositioner.MenuPositioner.useEffect": ()=>{
            const eventDetails = {
                open,
                nodeId: floatingNodeId,
                parentNodeId: floatingParentNodeId,
                reason: store.select('lastOpenChangeReason')
            };
            floatingTreeRoot.events.emit('menuopenchange', eventDetails);
        }
    }["MenuPositioner.MenuPositioner.useEffect"], [
        floatingTreeRoot.events,
        open,
        store,
        floatingNodeId,
        floatingParentNodeId
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTriggerSwitchTransition$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTriggerSwitchTransition"])({
        store,
        domReference,
        positionerElement,
        open
    });
    const state = {
        open,
        side: positioner.side,
        align: positioner.align,
        anchorHidden: positioner.anchorHidden,
        nested: parent.type === 'menu',
        instant: instantType
    };
    const menubarModal = parent.type === 'menubar' && parent.context.modal;
    const popupModal = modal && lastOpenChangeReason !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useAnchoredPopupScrollLock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnchoredPopupScrollLock"])(open && (menubarModal || popupModal), openMethod === 'touch', positionerElement, triggerElement);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$usePositioner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePositioner"])(componentProps, state, {
        styles: positioner.positionerStyles,
        transitionStatus,
        props: elementProps,
        refs: [
            forwardedRef,
            store.useStateSetter('positionerElement')
        ],
        hidden: !mounted,
        inert: !open
    });
    const shouldRenderBackdrop = mounted && parent.type !== 'menu' && (parent.type !== 'menubar' && modal && lastOpenChangeReason !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover || parent.type === 'menubar' && parent.context.modal);
    // cuts a hole in the backdrop to allow pointer interaction with the menubar or dropdown menu trigger element
    let backdropCutout = null;
    if (parent.type === 'menubar') {
        backdropCutout = parent.context.contentElement;
    } else if (parent.type === undefined) {
        backdropCutout = triggerElement;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuPositionerContext"].Provider, {
        value: positioner,
        children: [
            shouldRenderBackdrop && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$InternalBackdrop$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InternalBackdrop"], {
                ref: parent.type === 'context-menu' || parent.type === 'nested-context-menu' ? parent.context.internalBackdropRef : null,
                inert: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$inertValue$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["inertValue"])(!open),
                cutout: backdropCutout
            }),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingNode"], {
                id: floatingNodeId,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CompositeList"], {
                    elementsRef: store.context.itemDomElements,
                    labelsRef: store.context.itemLabels,
                    onMapChange: syncHighlightedItem,
                    children: element
                })
            })
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuPositioner.displayName = "MenuPositioner";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuPositionerContext",
    ()=>MenuPositionerContext,
    "useMenuPositionerContext",
    ()=>useMenuPositionerContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuPositionerContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuPositionerContext.displayName = "MenuPositionerContext";
function useMenuPositionerContext(optional) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuPositionerContext);
    if (context === undefined && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenuPositionerContext is missing. MenuPositioner parts must be placed within <Menu.Positioner>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRadioGroup",
    ()=>MenuRadioGroup,
    "MenuRadioGroupPlain",
    ()=>MenuRadioGroupPlain
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useControlled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/group/MenuGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const MenuRadioGroupPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuRadioGroupPlain(componentProps, forwardedRef) {
    const { render, className, value: valueProp, defaultValue, onValueChange: onValueChangeProp, disabled = false, style, 'aria-labelledby': ariaLabelledByProp, ...elementProps } = componentProps;
    const [labelId, setLabelId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](undefined);
    const [value, setValueUnwrapped] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: valueProp,
        default: defaultValue,
        name: 'MenuRadioGroup'
    });
    const setValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuRadioGroupPlain.MenuRadioGroupPlain.useStableCallback[setValue]": (newValue, eventDetails)=>{
            onValueChangeProp?.(newValue, eventDetails);
            if (eventDetails.isCanceled) {
                return;
            }
            setValueUnwrapped(newValue);
        }
    }["MenuRadioGroupPlain.MenuRadioGroupPlain.useStableCallback[setValue]"]);
    const state = {
        disabled
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: forwardedRef,
        props: {
            role: 'group',
            'aria-labelledby': ariaLabelledByProp ?? labelId,
            'aria-disabled': disabled || undefined,
            ...elementProps
        }
    });
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRadioGroupPlain.MenuRadioGroupPlain.useMemo[context]": ()=>({
                value,
                setValue,
                disabled
            })
    }["MenuRadioGroupPlain.MenuRadioGroupPlain.useMemo[context]"], [
        value,
        setValue,
        disabled
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$group$2f$MenuGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuGroupContext"].Provider, {
        value: setLabelId,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRadioGroupContext"].Provider, {
            value: context,
            children: element
        })
    });
});
/**
 * Groups related radio items.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuRadioGroupPlain.displayName = "MenuRadioGroupPlain";
const MenuRadioGroup = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["memo"](/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuRadioGroup(props, forwardedRef) {
    const RadioGroup = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterImpl"])()?.RadioGroup ?? MenuRadioGroupPlain;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(RadioGroup, {
        ...props,
        ref: forwardedRef
    });
}));
if ("TURBOPACK compile-time truthy", 1) MenuRadioGroup.displayName = "MenuRadioGroup";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroupContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRadioGroupContext",
    ()=>MenuRadioGroupContext,
    "useMenuRadioGroupContext",
    ()=>useMenuRadioGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuRadioGroupContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuRadioGroupContext.displayName = "MenuRadioGroupContext";
function useMenuRadioGroupContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuRadioGroupContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenuRadioGroupContext is missing. MenuRadioGroup parts must be placed within <Menu.RadioGroup>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item-indicator/MenuRadioItemIndicator.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRadioItemIndicator",
    ()=>MenuRadioItemIndicator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2f$MenuRadioItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item/MenuRadioItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTransitionStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useTransitionStatus.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useOpenChangeComplete.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const MenuRadioItemIndicator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuRadioItemIndicator(componentProps, forwardedRef) {
    const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
    const item = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2f$MenuRadioItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRadioItemContext"])();
    const indicatorRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const { transitionStatus, mounted, setMounted } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTransitionStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"])(item.checked);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeComplete"])({
        batch: true,
        enabled: !item.checked,
        open: item.checked,
        ref: indicatorRef,
        onComplete () {
            if (!item.checked) {
                setMounted(false);
            }
        }
    });
    const state = {
        checked: item.checked,
        disabled: item.disabled,
        highlighted: item.highlighted,
        transitionStatus
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('span', componentProps, {
        state,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["itemMapping"],
        ref: [
            forwardedRef,
            indicatorRef
        ],
        props: {
            'aria-hidden': true,
            ...elementProps
        },
        enabled: keepMounted || mounted
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) MenuRadioItemIndicator.displayName = "MenuRadioItemIndicator";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item/MenuRadioItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRadioItem",
    ()=>MenuRadioItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-group/MenuRadioGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2f$MenuRadioItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item/MenuRadioItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuRadioItemPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuRadioItemPlain(componentProps, forwardedRef) {
    const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = false, value, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const { value: selectedValue, setValue: setSelectedValue, disabled: groupDisabled } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$group$2f$MenuRadioGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRadioGroupContext"])();
    const listItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])({
        guess: true,
        label
    });
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const highlighted = store.useState('isActive', listItem.index);
    const nodeId = store.useState('floatingNodeId');
    const itemProps = store.useState('itemProps');
    const rootDisabled = store.useState('disabled');
    const disabled = disabledProp || groupDisabled || rootDisabled;
    const checked = selectedValue === value;
    const { getItemProps, itemRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuItem"])({
        closeOnClick,
        disabled,
        highlighted,
        id,
        store,
        nativeButton,
        nodeId,
        itemMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["REGULAR_ITEM"]
    });
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRadioItemPlain.MenuRadioItemPlain.useMemo[state]": ()=>({
                disabled,
                highlighted,
                checked
            })
    }["MenuRadioItemPlain.MenuRadioItemPlain.useMemo[state]"], [
        disabled,
        highlighted,
        checked
    ]);
    function handleClick(event) {
        const details = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].itemPress, event.nativeEvent, undefined, {
            preventUnmountOnClose: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"]
        });
        setSelectedValue(value, details);
    }
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["itemMapping"],
        props: [
            itemProps,
            {
                role: 'menuitemradio',
                'aria-checked': checked,
                onClick: handleClick
            },
            elementProps,
            getItemProps
        ],
        ref: [
            itemRef,
            forwardedRef,
            listItem.ref
        ]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$radio$2d$item$2f$MenuRadioItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRadioItemContext"].Provider, {
        value: state,
        children: element
    });
});
/**
 * A menu item that works like a radio button in a given group.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuRadioItemPlain.displayName = "MenuRadioItemPlain";
const MenuRadioItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuRadioItem(props, forwardedRef) {
    const filterItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterItem"])(props, forwardedRef);
    if (!filterItem.visible) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuRadioItemPlain, {
        ...props,
        ref: filterItem.ref
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuRadioItem.displayName = "MenuRadioItem";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/radio-item/MenuRadioItemContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRadioItemContext",
    ()=>MenuRadioItemContext,
    "useMenuRadioItemContext",
    ()=>useMenuRadioItemContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuRadioItemContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuRadioItemContext.displayName = "MenuRadioItemContext";
function useMenuRadioItemContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuRadioItemContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenuRadioItemContext is missing. MenuRadioItem parts must be placed within <Menu.RadioItem>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRoot",
    ()=>MenuRoot,
    "MenuRootInternal",
    ()=>MenuRootInternal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useTimeout.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useRefWithInit.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$fastHooks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/fastHooks.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingTree.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useDismiss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useDismiss.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useTypeahead$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useTypeahead.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useSyncedFloatingRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useSyncedFloatingRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menubar$2f$MenubarContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menubar/MenubarContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/direction-context/DirectionContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useOpenInteractionType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/useOpenInteractionType.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$getHighlightReason$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/getHighlightReason.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useAnimationsFinished$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useAnimationsFinished.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/store/MenuStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/popupStoreUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-provider/MenuFilterProviderContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$isKeyboardOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/isKeyboardOpen.mjs [app-client] (ecmascript)");
/**
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuRootInternal = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$fastHooks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fastComponent"])(function MenuRootInternal(props) {
    const { children, open: openProp, onOpenChange, onOpenChangeComplete, onItemHighlighted: onItemHighlightedProp, defaultOpen = false, disabled: disabledProp = false, modal: modalProp, loopFocus = true, orientation = 'vertical', actionsRef, closeParentOnEsc = false, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null, highlightItemOnHover = true, isSubmenu = false, virtualFocus = false, virtualFocusRef, allowEscape = true, resetOnPointerLeave = true } = props;
    const contextMenuContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$context$2d$menu$2f$root$2f$ContextMenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContextMenuRootContext"])(true);
    const parentMenuRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])(true);
    const menubarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menubar$2f$MenubarContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenubarContext"])(true);
    // Depend on the stable pieces rather than the parent context object, so a parent context
    // invalidation doesn't cascade into every descendant root's context.
    const enclosingMenuStore = parentMenuRootContext?.store;
    const parentVirtualFocus = parentMenuRootContext?.virtualFocus ?? false;
    const parentFromContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRootInternal.MenuRootInternal.useMemo[parentFromContext]": ()=>{
            if (isSubmenu && enclosingMenuStore) {
                return {
                    type: 'menu',
                    store: enclosingMenuStore
                };
            }
            if (menubarContext) {
                return {
                    type: 'menubar',
                    context: menubarContext
                };
            }
            // Ensure this is not a Menu nested inside ContextMenu.Trigger.
            // ContextMenu parentContext is always undefined as ContextMenu.Root is instantiated with
            // <MenuRootContext.Provider value={undefined}>
            if (contextMenuContext && !enclosingMenuStore) {
                return {
                    type: 'context-menu',
                    context: contextMenuContext
                };
            }
            return {
                type: undefined
            };
        }
    }["MenuRootInternal.MenuRootInternal.useMemo[parentFromContext]"], [
        contextMenuContext,
        enclosingMenuStore,
        menubarContext,
        isSubmenu
    ]);
    const rootId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    // React 17 resolves generated ids in an effect, so they must be read live rather than captured
    // in a state initializer.
    const defaultFloatingId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    const [renderedFloatingId, setRenderedFloatingId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](undefined);
    // A registered `''` means the popup rendered with an explicitly empty id, so nothing may point
    // at the generated fallback.
    const floatingId = (renderedFloatingId ?? defaultFloatingId) || undefined;
    const floatingParentNodeIdFromContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingParentNodeId"])();
    const parentMenuStore = parentFromContext.type === 'menu' ? parentFromContext.store : undefined;
    // An initially open submenu should animate in only when the user watches it appear, i.e. when
    // its subtree mounts because the parent popup is playing its own enter transition. A parent
    // that was `defaultOpen` at page load never passes through `'starting'`, and under a
    // `keepMounted` parent these initializers run at page load while the parent's status is still
    // `undefined` — in both cases the submenu is page-load content that must not animate. Gated on
    // being open at mount so a closed submenu doesn't seed `instantType` it would never clear. Read
    // during the first render only — consumed exclusively by first-render initializers below
    // (`useState` and the store's initial state).
    const animateInitialOpen = (openProp ?? defaultOpen) && parentMenuStore?.state.transitionStatus === 'starting';
    // Mirror an instantly-opened parent (e.g. keyboard click) so `[data-instant]` styling
    // suppresses the enter transition on both popups or neither. Captured once —
    // `animateInitialOpen` is only meaningful during the first render.
    const seededInstantType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "MenuRootInternal.MenuRootInternal.useRefWithInit": ()=>animateInitialOpen ? parentMenuStore?.state.instantType : undefined
    }["MenuRootInternal.MenuRootInternal.useRefWithInit"]).current;
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "MenuRootInternal.MenuRootInternal.useRefWithInit": ()=>{
            const menuStore = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuStore"]({
                open: defaultOpen,
                openProp,
                activeTriggerId: defaultTriggerIdProp,
                triggerIdProp,
                parent: parentFromContext,
                disabled: disabledProp,
                highlightItemOnHover,
                modal: parentFromContext.type === undefined ? modalProp : undefined,
                rootId,
                instantType: seededInstantType
            }, floatingId, floatingParentNodeIdFromContext != null);
            // A stable ref object, so descendants can read it during render from the first commit.
            menuStore.context.virtualFocusRef = virtualFocusRef;
            return menuStore;
        }
    }["MenuRootInternal.MenuRootInternal.useRefWithInit"]).current;
    store.useControlledProp('openProp', openProp);
    store.useControlledProp('triggerIdProp', triggerIdProp);
    store.useContextCallback('onOpenChangeComplete', onOpenChangeComplete);
    const floatingTreeRoot = store.useState('floatingTreeRoot');
    const floatingNodeIdFromContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingNodeId"])(floatingTreeRoot);
    const open = store.useState('open');
    const activeTriggerElement = store.useState('activeTriggerElement');
    const positionerElement = store.useState('positionerElement');
    const hoverEnabled = store.useState('hoverEnabled');
    const disabled = store.useState('disabled');
    const lastOpenChangeReason = store.useState('lastOpenChangeReason');
    const parent = store.useState('parent');
    const activeIndex = store.useState('activeIndex');
    const keyboardOpen = store.useState('keyboardOpen');
    const payload = store.useState('payload');
    const floatingParentNodeId = store.useState('floatingParentNodeId');
    const openEventRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const allowOutsidePressDismissalRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](parent.type !== 'context-menu');
    const allowOutsidePressDismissalTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const allowTouchToCloseRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](true);
    const allowTouchToCloseTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const nested = floatingParentNodeId != null;
    if ("TURBOPACK compile-time truthy", 1) {
        if (parent.type !== undefined && modalProp !== undefined) {
            console.warn('Base UI: The `modal` prop is not supported on nested menus. It will be ignored.');
        }
    }
    const { openMethod, triggerProps: interactionTypeProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useOpenInteractionType$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenInteractionType"])(open);
    store.useSyncedValues({
        disabled: disabledProp,
        highlightItemOnHover,
        modal: parent.type === undefined ? modalProp : undefined,
        openMethod,
        rootId
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImplicitActiveTrigger"])(store);
    const { forceUnmount, transitionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenStateTransitions"])(open, store, {
        "MenuRootInternal.MenuRootInternal.useOpenStateTransitions": ()=>{
            store.set('allowMouseEnter', false);
        }
    }["MenuRootInternal.MenuRootInternal.useOpenStateTransitions"], animateInitialOpen);
    const runOnceAnimationsFinish = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useAnimationsFinished$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnimationsFinished"])(store.context.popupRef);
    // An inherited `instantType` is only for the initial reveal. A later controlled `open` flip
    // bypasses `setOpen`, so nothing would reset it and `[data-instant]` would wrongly suppress
    // every subsequent transition. Clear it once the enter phase settles, unless an interactive
    // open change already replaced it.
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuRootInternal.MenuRootInternal.useEffect": ()=>{
            if (seededInstantType === undefined) {
                return undefined;
            }
            const clearSeededInstantType = {
                "MenuRootInternal.MenuRootInternal.useEffect.clearSeededInstantType": ()=>{
                    if (store.state.instantType === seededInstantType) {
                        store.set('instantType', undefined);
                    }
                }
            }["MenuRootInternal.MenuRootInternal.useEffect.clearSeededInstantType"];
            // A controlled close can interrupt the initial enter before the animations-finished cleanup
            // below fires (its abort cancels the pending callback, and a closed popup schedules no new
            // one). Nothing is left to protect once closing starts — the exit's suppression was already
            // decided at its trigger commit — so clear now or the next reopen renders a stale
            // `[data-instant]`.
            if (!open) {
                clearSeededInstantType();
                return undefined;
            }
            if (transitionStatus !== undefined) {
                return undefined;
            }
            // With no popup element (e.g. its subtree is suspended or waiting on data), there is no
            // enter transition to protect, and `useAnimationsFinished` would return without invoking the
            // callback — a ref assignment alone would never rerun this effect, leaving the seed stuck.
            // Clear immediately: a popup that appears after the reveal settles is page-load-like content.
            if (store.context.popupRef.current == null) {
                clearSeededInstantType();
                return undefined;
            }
            const abortController = new AbortController();
            runOnceAnimationsFinish(clearSeededInstantType, abortController.signal);
            return ({
                "MenuRootInternal.MenuRootInternal.useEffect": ()=>{
                    abortController.abort();
                }
            })["MenuRootInternal.MenuRootInternal.useEffect"];
        }
    }["MenuRootInternal.MenuRootInternal.useEffect"], [
        seededInstantType,
        open,
        transitionStatus,
        runOnceAnimationsFinish,
        store
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect": ()=>{
            if (contextMenuContext && !parentMenuRootContext) {
                // This is a context menu root.
                // It doesn't support detached triggers yet, so we have to sync the parent context manually.
                store.update({
                    parent: {
                        type: 'context-menu',
                        context: contextMenuContext
                    },
                    floatingNodeId: floatingNodeIdFromContext,
                    floatingParentNodeId: floatingParentNodeIdFromContext
                });
            } else if (parentMenuRootContext || !store.select('activeTriggerElement')) {
                // Without an active trigger, the root must supply its own tree IDs.
                // Read the store here: a trigger can register after render, before this effect.
                store.update({
                    floatingNodeId: floatingNodeIdFromContext,
                    floatingParentNodeId: floatingParentNodeIdFromContext
                });
            }
        }
    }["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect"], [
        contextMenuContext,
        parentMenuRootContext,
        floatingNodeIdFromContext,
        floatingParentNodeIdFromContext,
        activeTriggerElement,
        store
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuRootInternal.MenuRootInternal.useEffect": ()=>{
            if (!open) {
                openEventRef.current = null;
            }
            if (parent.type !== 'context-menu') {
                return;
            }
            if (!open) {
                allowOutsidePressDismissalTimeout.clear();
                allowOutsidePressDismissalRef.current = false;
                return;
            }
            // With `mousedown` outside press events and long press touch input, there
            // needs to be a grace period after opening to ensure the dismissal event
            // doesn't fire immediately after open.
            allowOutsidePressDismissalTimeout.start(500, {
                "MenuRootInternal.MenuRootInternal.useEffect": ()=>{
                    allowOutsidePressDismissalRef.current = true;
                }
            }["MenuRootInternal.MenuRootInternal.useEffect"]);
        }
    }["MenuRootInternal.MenuRootInternal.useEffect"], [
        allowOutsidePressDismissalTimeout,
        open,
        parent.type
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect": ()=>{
            if (!open && !hoverEnabled) {
                store.set('hoverEnabled', true);
            }
        }
    }["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect"], [
        open,
        hoverEnabled,
        store
    ]);
    const setOpen = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuRootInternal.MenuRootInternal.useStableCallback[setOpen]": (nextOpen, eventDetails)=>{
            const reason = eventDetails.reason;
            // Read the store directly, as relayed tree events and stale hover timers can request
            // a close after the state changed but before this component re-rendered.
            if (!nextOpen && !store.select('open')) {
                return;
            }
            if (open === nextOpen && eventDetails.trigger === activeTriggerElement && lastOpenChangeReason === reason) {
                return;
            }
            const shouldPreventUnmountOnClose = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["attachPreventUnmountOnClose"])(eventDetails);
            // Do not immediately reset the activeTriggerId to allow
            // exit animations to play and focus to be returned correctly.
            if (!nextOpen && eventDetails.trigger == null) {
                eventDetails.trigger = activeTriggerElement ?? undefined;
            }
            onOpenChange?.(nextOpen, eventDetails);
            if (eventDetails.isCanceled) {
                return;
            }
            store.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
            const nativeEvent = eventDetails.event;
            if (nextOpen === false && reason !== __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].itemPress && nativeEvent?.type === 'click' && nativeEvent.pointerType === 'touch' && !allowTouchToCloseRef.current) {
                return;
            }
            // Prevent the menu from closing on mobile devices that have a delayed click event.
            // In some cases the menu, when tapped, will fire the focus event first and then the click event.
            // Without this guard, the menu will close immediately after opening.
            if (nextOpen && reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerFocus) {
                allowTouchToCloseRef.current = false;
                allowTouchToCloseTimeout.start(300, {
                    "MenuRootInternal.MenuRootInternal.useStableCallback[setOpen]": ()=>{
                        allowTouchToCloseRef.current = true;
                    }
                }["MenuRootInternal.MenuRootInternal.useStableCallback[setOpen]"]);
            } else {
                allowTouchToCloseRef.current = true;
                allowTouchToCloseTimeout.clear();
            }
            const isDismissClose = !nextOpen && (reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].escapeKey || reason == null);
            openEventRef.current = eventDetails.event;
            const popupOpenState = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPopupOpenState"])(store.state, nextOpen, eventDetails.trigger, shouldPreventUnmountOnClose());
            popupOpenState.openChangeReason = reason;
            popupOpenState.keyboardOpen = nextOpen && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$isKeyboardOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isKeyboardOpen"])(reason, nativeEvent);
            if (parent.type === 'menubar' && (reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerFocus || reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].focusOut || reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover || reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation || reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].siblingOpen)) {
                popupOpenState.instantType = 'group';
            } else if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$isKeyboardOpen$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isKeyboardClick"])(reason, nativeEvent)) {
                popupOpenState.instantType = 'click';
            } else if (isDismissClose) {
                popupOpenState.instantType = 'dismiss';
            } else {
                popupOpenState.instantType = undefined;
            }
            // `instantType` must land in the same update that mounts the popup subtree: in React 17
            // legacy mode this `update` can flush synchronously, and a separate `instantType` write
            // after it would come too late for an initially open submenu seeding its own store from
            // this one during that flush.
            store.update(popupOpenState);
        }
    }["MenuRootInternal.MenuRootInternal.useStableCallback[setOpen]"]);
    const floatingRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useSyncedFloatingRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncedFloatingRootContext"])({
        popupStore: store,
        floatingRootContext: store.state.floatingRootContext,
        floatingId,
        nested: floatingParentNodeIdFromContext != null,
        onOpenChange: setOpen
    });
    const floatingEvents = floatingRootContext.context.events;
    // Registered in a layout effect (not a passive one) so `setOpen` emits from imperative
    // `MenuHandle.open()` calls made in the same commit this root mounts — e.g. from another layout
    // effect during a route-transition handoff — are received instead of being silently dropped.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect": ()=>{
            const handleSetOpenEvent = {
                "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect.handleSetOpenEvent": ({ open: nextOpen, eventDetails })=>setOpen(nextOpen, eventDetails)
            }["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect.handleSetOpenEvent"];
            floatingEvents.on('setOpen', handleSetOpenEvent);
            return ({
                "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect": ()=>{
                    floatingEvents?.off('setOpen', handleSetOpenEvent);
                }
            })["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect"];
        }
    }["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect"], [
        floatingEvents,
        setOpen
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect": ()=>store.subscribeToParentMenu()
    }["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect"], [
        store
    ]);
    const handleImperativeClose = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "MenuRootInternal.MenuRootInternal.useCallback[handleImperativeClose]": ()=>{
            store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].imperativeAction));
        }
    }["MenuRootInternal.MenuRootInternal.useCallback[handleImperativeClose]"], [
        store
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](actionsRef, {
        "MenuRootInternal.MenuRootInternal.useImperativeHandle": ()=>({
                unmount: forceUnmount,
                close: handleImperativeClose
            })
    }["MenuRootInternal.MenuRootInternal.useImperativeHandle"], [
        forceUnmount,
        handleImperativeClose
    ]);
    let ctx;
    if (parent.type === 'context-menu') {
        ctx = parent.context;
    }
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](ctx?.positionerRef, {
        "MenuRootInternal.MenuRootInternal.useImperativeHandle": ()=>positionerElement
    }["MenuRootInternal.MenuRootInternal.useImperativeHandle"], [
        positionerElement
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useImperativeHandle"](ctx?.actionsRef, {
        "MenuRootInternal.MenuRootInternal.useImperativeHandle": ()=>({
                setOpen
            })
    }["MenuRootInternal.MenuRootInternal.useImperativeHandle"], [
        setOpen
    ]);
    const dismiss = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useDismiss$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDismiss"])(floatingRootContext, {
        enabled: !disabled,
        bubbles: {
            escapeKey: closeParentOnEsc && parent.type === 'menu'
        },
        outsidePress () {
            if (parent.type !== 'context-menu' || openEventRef.current?.type === 'contextmenu') {
                return true;
            }
            return allowOutsidePressDismissalRef.current;
        },
        externalTree: nested ? floatingTreeRoot : undefined
    });
    const direction = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$direction$2d$context$2f$DirectionContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDirection"])();
    const listNavigation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useListNavigation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useListNavigation"])(floatingRootContext, {
        enabled: !disabled,
        listRef: store.context.itemDomElements,
        activeIndex,
        virtual: virtualFocus,
        nested: parent.type === 'menubar' || !virtualFocus && parent.type !== undefined,
        parentOrientation: parent.type === 'menubar' ? parent.context.orientation : undefined,
        loopFocus,
        // Filtered menus keep DOM focus on the input, while keyboard and virtual opens initially
        // highlight an item as ordinary menus do. The input stays in the arrow-key loop unless the
        // filter highlights automatically.
        focusItemOnOpen: virtualFocus ? keyboardOpen : undefined,
        allowEscape: virtualFocus && loopFocus && allowEscape,
        orientation,
        // A virtual-focus list can navigate on either axis, but its trigger always opens on the
        // vertical one.
        triggerOrientation: virtualFocus ? 'vertical' : orientation,
        rtl: direction === 'rtl',
        disabledIndices: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"],
        onNavigate (nextActiveIndex, event) {
            store.setActiveIndex(nextActiveIndex, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$getHighlightReason$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHighlightReason"])(event), event?.nativeEvent);
        },
        // A virtual-focus submenu's keyboard opening is orchestrated by its navigation wrapper based
        // on both menus' orientations; the generic arrow-key opening would also react to the parent's
        // forwarded cross-axis keys while closed.
        openOnArrowKeyDown: parent.type !== 'context-menu' && !(virtualFocus && isSubmenu),
        externalTree: !virtualFocus && nested ? floatingTreeRoot : undefined,
        nestedReturnFocusRef: parentMenuStore?.context.virtualFocusRef,
        focusItemOnHover: highlightItemOnHover,
        resetOnPointerLeave
    });
    const onTyping = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "MenuRootInternal.MenuRootInternal.useCallback[onTyping]": (nextTyping)=>{
            store.context.typingRef.current = nextTyping;
        }
    }["MenuRootInternal.MenuRootInternal.useCallback[onTyping]"], [
        store
    ]);
    const typeahead = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useTypeahead$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTypeahead"])(floatingRootContext, {
        // Under virtual focus the input owns typing, so typeahead would race the filter query.
        enabled: !disabled && !virtualFocus,
        listRef: store.context.itemLabels,
        elementsRef: store.context.itemDomElements,
        activeIndex,
        resetMs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TYPEAHEAD_RESET_MS"],
        onMatch: {
            "MenuRootInternal.MenuRootInternal.useTypeahead[typeahead]": (index, event)=>{
                if (open && index !== activeIndex) {
                    store.setActiveIndex(index, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].keyboard, event.nativeEvent);
                }
            }
        }["MenuRootInternal.MenuRootInternal.useTypeahead[typeahead]"],
        onTyping
    });
    const onItemHighlighted = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])(onItemHighlightedProp);
    const lastHighlightIndexRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](-1);
    // Runs when `activeIndex` commits and again when the item registry settles, since an index
    // can come to point at a different element while its value stays the same.
    const syncHighlightedItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuRootInternal.MenuRootInternal.useStableCallback[syncHighlightedItem]": ()=>{
            const index = store.state.activeIndex;
            const item = index === null ? undefined : store.context.itemDomElements.current[index] ?? undefined;
            // An item removed in this commit stays registered until the list flushes, which calls back
            // here with the settled registry.
            if (item?.isConnected === false) {
                return;
            }
            const itemIndex = item === undefined ? -1 : index;
            if (lastHighlightIndexRef.current === itemIndex && store.context.reportedItem === item) {
                return;
            }
            lastHighlightIndexRef.current = itemIndex;
            store.context.reportedItem = item;
            // Only virtual focus renders from the highlighted element. Publishing it in every menu would
            // notify each item's subscription on every highlight change.
            if (virtualFocus) {
                store.set('highlightedItem', item);
            }
            // The tag left by the write that produced this committed value.
            const { highlightReason, highlightEvent } = store.context;
            store.context.highlightReason = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none;
            store.context.highlightEvent = undefined;
            if (!onItemHighlightedProp) {
                return;
            }
            onItemHighlighted(item, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGenericEventDetails"])(highlightReason, highlightEvent, {
                label: item === undefined ? undefined : store.context.itemLabels.current[itemIndex] ?? undefined
            }));
        }
    }["MenuRootInternal.MenuRootInternal.useStableCallback[syncHighlightedItem]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuRootInternal.MenuRootInternal.useIsoLayoutEffect": ()=>{
            syncHighlightedItem();
        }
    }["MenuRootInternal.MenuRootInternal.useIsoLayoutEffect"], [
        activeIndex,
        syncHighlightedItem
    ]);
    // Under virtual focus an element inside the popup holds real focus, so it takes the
    // navigation's reference props (`aria-activedescendant` and the key handling) and the trigger
    // keeps only the props that open the menu.
    const openTriggerProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRootInternal.MenuRootInternal.useMemo[openTriggerProps]": ()=>{
            if (!virtualFocus) {
                return listNavigation.reference;
            }
            if (!listNavigation.trigger) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
            }
            // Focusing the trigger while the menu is open must not seed the virtual highlight. This can
            // happen before a pointer press closes the menu in Safari.
            const { onFocus, ...rest } = listNavigation.trigger;
            return rest;
        }
    }["MenuRootInternal.MenuRootInternal.useMemo[openTriggerProps]"], [
        virtualFocus,
        listNavigation.reference,
        listNavigation.trigger
    ]);
    store.useSyncedValue('inputProps', virtualFocus ? listNavigation.reference ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"] : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"]);
    const activeTriggerProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRootInternal.MenuRootInternal.useMemo[activeTriggerProps]": ()=>{
            const mergedProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(typeahead.reference, openTriggerProps, dismiss.reference, {
                onMouseMove () {
                    store.set('allowMouseEnter', true);
                }
            }, interactionTypeProps);
            mergedProps['aria-haspopup'] = 'menu';
            mergedProps['aria-expanded'] = open;
            return mergedProps;
        }
    }["MenuRootInternal.MenuRootInternal.useMemo[activeTriggerProps]"], [
        store,
        typeahead.reference,
        openTriggerProps,
        dismiss.reference,
        interactionTypeProps,
        open
    ]);
    const inactiveTriggerProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRootInternal.MenuRootInternal.useMemo[inactiveTriggerProps]": ()=>{
            const mergedProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(listNavigation.trigger, dismiss.trigger, interactionTypeProps);
            mergedProps['aria-haspopup'] = 'menu';
            mergedProps['aria-expanded'] = false;
            return mergedProps;
        }
    }["MenuRootInternal.MenuRootInternal.useMemo[inactiveTriggerProps]"], [
        listNavigation.trigger,
        dismiss.trigger,
        interactionTypeProps
    ]);
    // The initial render has no store subscribers yet. Seed these props before triggers render so
    // the synchronization effect below doesn't make every trigger render twice in the first commit.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "MenuRootInternal.MenuRootInternal.useRefWithInit": ()=>{
            store.update({
                inactiveTriggerProps
            });
            return null;
        }
    }["MenuRootInternal.MenuRootInternal.useRefWithInit"]);
    const popupProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRootInternal.MenuRootInternal.useMemo[popupProps]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FOCUSABLE_POPUP_PROPS"], {
                onMouseMove () {
                    store.set('allowMouseEnter', true);
                    if (parent.type === 'menu') {
                        store.set('hoverEnabled', false);
                    }
                },
                onClick () {
                    if (store.select('hoverEnabled')) {
                        store.set('hoverEnabled', false);
                    }
                },
                onKeyDown (event) {
                    // The Menubar's CompositeRoot captures keyboard events via
                    // event delegation. This works well when Menu.Root is nested inside Menubar,
                    // but with detached triggers we need to manually forward the event to the CompositeRoot.
                    const relay = store.select('keyboardEventRelay');
                    if (relay && !event.isPropagationStopped()) {
                        relay(event);
                    }
                }
            }, typeahead.floating, listNavigation.floating, dismiss.floating)
    }["MenuRootInternal.MenuRootInternal.useMemo[popupProps]"], [
        parent.type,
        store,
        typeahead.floating,
        listNavigation.floating,
        dismiss.floating
    ]);
    const itemProps = listNavigation.item ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePopupInteractionProps"])(store, {
        floatingRootContext,
        activeTriggerProps,
        inactiveTriggerProps,
        popupProps,
        itemProps
    });
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuRootInternal.MenuRootInternal.useMemo[context]": ()=>({
                store,
                parent: parentFromContext,
                orientation,
                loopFocus,
                allowEscape,
                defaultFloatingId,
                setRenderedFloatingId,
                virtualFocus,
                parentVirtualFocus,
                syncHighlightedItem
            })
    }["MenuRootInternal.MenuRootInternal.useMemo[context]"], [
        store,
        parentFromContext,
        orientation,
        loopFocus,
        allowEscape,
        defaultFloatingId,
        virtualFocus,
        parentVirtualFocus,
        syncHighlightedItem
    ]);
    const renderedChildren = typeof children === 'function' ? children({
        payload
    }) : children;
    let content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRootContext"].Provider, {
        value: context,
        children: [
            handle && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopupHandleAttachment"], {
                handle: handle,
                store: store
            }),
            renderedChildren
        ]
    });
    if (parent.type === undefined || parent.type === 'context-menu') {
        // set up a FloatingTree to provide the context to nested menus
        content = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingTree"], {
            externalTree: floatingTreeRoot,
            children: content
        });
    }
    return content;
});
/**
 * Groups all parts of the menu.
 * Doesn't render its own HTML element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuRootInternal.displayName = "MenuRootInternal";
function MenuRoot(props) {
    const filterProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterProviderContext"]);
    if (filterProvider === null) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuRootInternal, {
            ...props
        });
    }
    const FilterRoot = filterProvider.Root;
    return(/*#__PURE__*/ // The root consumes its provider so a plain submenu inside doesn't inherit it.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterProviderContext"].Provider, {
        value: null,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FilterRoot, {
            ...filterProvider.options,
            ...props
        })
    }));
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuRootContext",
    ()=>MenuRootContext,
    "useMenuRootContext",
    ()=>useMenuRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenuRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuRootContext.displayName = "MenuRootContext";
function useMenuRootContext(optional) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuRootContext);
    if (context === undefined && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenuRootContext is missing. Menu parts must be placed within <Menu.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/store/MenuHandle.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuHandle",
    ()=>MenuHandle,
    "createMenuHandle",
    ()=>createMenuHandle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/store/MenuStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/popupHandle.mjs [app-client] (ecmascript)");
;
;
class MenuHandle extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupHandle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BasePopupHandle"] {
    constructor(){
        super((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$store$2f$MenuStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createNullMenuStore"])(), 'Menu');
    }
    /**
   * Opens the menu and associates it with the trigger with the given id.
   *
   * This method should only be called in an event handler or an effect (not during rendering).
   *
   * @param triggerId ID of the trigger to associate with the menu. The trigger must be a matching
   * `Menu.Trigger` with this handle passed as a prop.
   */ open(triggerId) {
        this.openByTrigger(triggerId);
    }
    /**
   * Closes the menu.
   *
   * This method should only be called in an event handler or an effect (not during rendering).
   */ close() {
        this.closePopup();
    }
    /**
   * Whether the menu is currently open. Returns `false` while no root is attached to the handle.
   */ get isOpen() {
        return this.attachedStore?.select('open') ?? false;
    }
}
function createMenuHandle() {
    return new MenuHandle();
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/store/MenuStore.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuStore",
    ()=>MenuStore,
    "createNullMenuStore",
    ()=>createNullMenuStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$ReactStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/store/ReactStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/platform/parts.mjs [app-client] (ecmascript) <export * as platform>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTreeStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingTreeStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$NullStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/NullStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupTriggerMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/popupTriggerMap.mjs [app-client] (ecmascript)");
;
;
;
;
;
;
;
const selectors = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["popupStoreSelectors"],
    disabled: (state)=>state.parent.type === 'menubar' ? state.parent.context.disabled || state.disabled : state.disabled,
    modal: (state)=>(state.parent.type === undefined || state.parent.type === 'context-menu') && (state.modal ?? true),
    openMethod: (state)=>state.openMethod,
    keyboardOpen: (state)=>state.keyboardOpen,
    allowMouseEnter: (state)=>state.allowMouseEnter,
    highlightItemOnHover: (state)=>state.highlightItemOnHover,
    parent: (state)=>state.parent,
    rootId: (state)=>{
        if (state.parent.type === 'menu') {
            return state.parent.store.select('rootId');
        }
        return state.parent.type !== undefined ? state.parent.context.rootId : state.rootId;
    },
    activeIndex: (state)=>state.activeIndex,
    listElement: (state)=>state.listElement,
    /** The trigger's `aria-controls`: the list when one holds the `menu` role, else the popup. */ triggerControlsId: (state, triggerId)=>{
        const popupId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["popupStoreSelectors"].triggerPopupId(state, triggerId);
        return popupId ? state.listElement?.id || popupId : undefined;
    },
    filterTriggerProps: (state)=>state.filterTriggerProps,
    inputProps: (state)=>state.inputProps,
    // `aria-selected` is invalid on `menuitem`, but Safari VoiceOver needs it for arrow-key
    // navigation. Limit it to WebKit while the input has focus so normal VoiceOver navigation
    // does not encounter the invalid attribute.
    webkitAriaSelected: (state, highlighted)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__["platform"].engine.webkit && state.inputFocused && highlighted ? true : undefined,
    highlightedItemId: (state)=>state.highlightedItem?.id || undefined,
    isActive: (state, itemIndex)=>state.activeIndex === itemIndex,
    hoverEnabled: (state)=>state.hoverEnabled,
    // `trigger-change` describes a popup moving between triggers, which only has
    // meaning while it is open. Dropping it once closed keeps a late or stale
    // restoration from marking a closing popup instant and skipping its exit
    // transition, including on close paths that never reach `setOpen` — a
    // controlled consumer committing `open={false}` goes straight through the prop.
    instantType: (state)=>state.instantType === 'trigger-change' && !__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["popupStoreSelectors"].open(state) ? undefined : state.instantType,
    lastOpenChangeReason: (state)=>state.openChangeReason,
    floatingTreeRoot: (state)=>{
        if (state.parent.type === 'menu') {
            return state.parent.store.select('floatingTreeRoot');
        }
        return state.floatingTreeRoot;
    },
    floatingNodeId: (state)=>state.floatingNodeId,
    floatingParentNodeId: (state)=>state.floatingParentNodeId,
    itemProps: (state)=>state.itemProps,
    closeDelay: (state)=>state.closeDelay,
    adaptiveOrigin: (state)=>state.adaptiveOrigin,
    keyboardEventRelay: (state)=>{
        if (state.keyboardEventRelay) {
            return state.keyboardEventRelay;
        }
        if (state.parent.type === 'menu') {
            return state.parent.store.select('keyboardEventRelay');
        }
        return undefined;
    }
};
class MenuStore extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$ReactStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReactStore"] {
    constructor(initialState, floatingId, nested = false){
        const triggerElements = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupTriggerMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopupTriggerMap"]();
        const state = createInitialState(triggerElements, floatingId, nested, initialState);
        super(state, createInitialContext(triggerElements), selectors);
        // Share the mouse-up trigger ref of the parent menu, if any. This observes the store's own
        // state, so the subscription lives exactly as long as the store and needs no cleanup.
        void this.observe('parent', (parent)=>{
            if (parent.type === 'menu') {
                this.context.allowMouseUpTriggerRef = parent.store.context.allowMouseUpTriggerRef;
            } else if (parent.type !== undefined) {
                this.context.allowMouseUpTriggerRef = parent.context.allowMouseUpTriggerRef;
            }
        });
    }
    /**
   * Propagates changes of the parent menu's shared tree state to this store's subscribers.
   * The owning `Menu.Root` calls it from an effect so the parent store subscription is released
   * when the submenu unmounts.
   * @returns A function that removes the parent store subscription.
   */ subscribeToParentMenu() {
        const parent = this.state.parent;
        if (parent.type !== 'menu') {
            return undefined;
        }
        let rootId = parent.store.select('rootId');
        let floatingTreeRoot = parent.store.select('floatingTreeRoot');
        let keyboardEventRelay = parent.store.select('keyboardEventRelay');
        return parent.store.subscribe(()=>{
            const nextRootId = parent.store.select('rootId');
            const nextFloatingTreeRoot = parent.store.select('floatingTreeRoot');
            const nextKeyboardEventRelay = parent.store.select('keyboardEventRelay');
            if (rootId === nextRootId && floatingTreeRoot === nextFloatingTreeRoot && keyboardEventRelay === nextKeyboardEventRelay) {
                return;
            }
            rootId = nextRootId;
            floatingTreeRoot = nextFloatingTreeRoot;
            keyboardEventRelay = nextKeyboardEventRelay;
            this.notifyAll();
        });
    }
    setOpen(open, eventDetails) {
        this.state.floatingRootContext.context.events.emit('setOpen', {
            open,
            eventDetails
        });
    }
    setActiveIndex(activeIndex, reason, event) {
        // Only a write that changes the index is reported. Tagging a no-op, or a write back to the
        // reported item before the change commits, would let a later registry-driven re-emit report
        // this reason instead of `none`.
        if (this.state.activeIndex !== activeIndex) {
            const item = activeIndex === null ? undefined : this.context.itemDomElements.current[activeIndex];
            const isWriteBack = item === this.context.reportedItem;
            this.context.highlightReason = isWriteBack ? 'none' : reason;
            this.context.highlightEvent = isWriteBack ? undefined : event;
        }
        this.set('activeIndex', activeIndex);
    }
    highlightItem(element, reason, event) {
        const index = this.context.itemDomElements.current.indexOf(element);
        if (index > -1) {
            this.setActiveIndex(index, reason, event);
        }
    }
}
function createNullMenuStore() {
    const triggerElements = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupTriggerMap$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PopupTriggerMap"]();
    const store = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$NullStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NullStore"](Object.freeze(createInitialState(triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors);
    return Object.assign(store, {
        setOpen: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"]
    });
}
function createInitialContext(triggerElements) {
    return {
        positionerRef: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"](),
        popupRef: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"](),
        typingRef: {
            current: false
        },
        itemDomElements: {
            current: []
        },
        itemLabels: {
            current: []
        },
        highlightReason: 'none',
        highlightEvent: undefined,
        reportedItem: undefined,
        allowMouseUpTriggerRef: {
            current: false
        },
        virtualFocusRef: undefined,
        triggerFocusTargetRef: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"](),
        beforeTriggerFocusGuardRef: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"](),
        beforeContentFocusGuardRef: /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createRef"](),
        onOpenChangeComplete: undefined,
        triggerElements
    };
}
function createInitialState(triggerElements, floatingId, nested = false, initialState) {
    return {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createInitialPopupStoreState"])(triggerElements, floatingId, nested),
        disabled: false,
        modal: true,
        openMethod: null,
        keyboardOpen: false,
        allowMouseEnter: false,
        highlightItemOnHover: true,
        parent: {
            type: undefined
        },
        rootId: undefined,
        activeIndex: null,
        listElement: null,
        filterTriggerProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"],
        inputProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"],
        inputFocused: false,
        highlightedItem: undefined,
        hoverEnabled: true,
        instantType: undefined,
        openChangeReason: null,
        floatingTreeRoot: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTreeStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingTreeStore"](),
        floatingNodeId: undefined,
        floatingParentNodeId: null,
        itemProps: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"],
        keyboardEventRelay: undefined,
        closeDelay: 0,
        adaptiveOrigin: undefined,
        ...initialState
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRoot.mjs [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuSubmenuRoot",
    ()=>MenuSubmenuRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-provider/MenuFilterProviderContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const EMPTY_SUBMENU_ROOT_CONTEXT = {};
function MenuSubmenuRoot(props) {
    // Throws when the submenu isn't inside a menu.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const filterProvider = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterProviderContext"]);
    if (filterProvider !== null) {
        const FilterSubmenuRoot = filterProvider.SubmenuRoot;
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$provider$2f$MenuFilterProviderContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuFilterProviderContext"].Provider, {
            value: null,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(FilterSubmenuRoot, {
                ...filterProvider.options,
                ...props
            })
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuSubmenuRootContext"].Provider, {
        value: EMPTY_SUBMENU_ROOT_CONTEXT,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MenuRootInternal"], {
            ...props,
            isSubmenu: true
        })
    });
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuSubmenuRootContext",
    ()=>MenuSubmenuRootContext,
    "useMenuSubmenuRootContext",
    ()=>useMenuSubmenuRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const MenuSubmenuRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) MenuSubmenuRootContext.displayName = "MenuSubmenuRootContext";
function useMenuSubmenuRootContext() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenuSubmenuRootContext);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-trigger/MenuSubmenuTrigger.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuSubmenuTrigger",
    ()=>MenuSubmenuTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$isElementDisabled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/isElementDisabled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/warn.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$safeReact$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/safeReact.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/platform/parts.mjs [app-client] (ecmascript) <export * as platform>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$safePolygon$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/safePolygon.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useClick$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useClick.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useHoverReferenceInteraction$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useHoverReferenceInteraction.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popupStateMapping.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/item/useMenuItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/popupStoreUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const VOICE_OVER_EXPANDED_PROPS = {
    'aria-expanded': undefined
};
const MenuSubmenuTriggerPlain = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuSubmenuTriggerPlain(componentProps, forwardedRef) {
    const { render, className, style, label, id: idProp, nativeButton = false, openOnHover = true, delay = 100, closeDelay = 0, disabled: disabledProp = false, ...elementProps } = componentProps;
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])(true);
    if (context?.parent.type !== 'menu') {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: <Menu.SubmenuTrigger> must be placed in <Menu.SubmenuRoot>.' : "TURBOPACK unreachable");
    }
    const menuPositionerContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuPositionerContext"])();
    const submenuRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$submenu$2d$root$2f$MenuSubmenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuSubmenuRootContext"])();
    const { store, parentVirtualFocus } = context;
    const parentMenuStore = context.parent.store;
    const listItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])({
        guess: true,
        label
    });
    const thisTriggerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const open = store.useState('open');
    const focusReturnedThroughGuardRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    const positionerElement = store.useState('positionerElement');
    const floatingRootContext = store.useState('floatingRootContext');
    const floatingTreeRoot = store.useState('floatingTreeRoot');
    const popupId = store.useState('triggerPopupId', thisTriggerId);
    const baseRegisterTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTriggerRegistration"])(thisTriggerId, store);
    // Stable, so the merged ref on the rendered element keeps its identity for the trigger's whole
    // lifetime; the latest `closeDelay` is read when it runs.
    const registerTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useStableCallback[registerTrigger]": (element)=>{
            baseRegisterTrigger(element);
            const activeTriggerElement = store.select('activeTriggerElement');
            if (element !== null && store.select('open') && (activeTriggerElement === element || store.select('activeTriggerId') == null)) {
                store.update({
                    activeTriggerId: thisTriggerId ?? null,
                    activeTriggerElement: element,
                    closeDelay
                });
            }
        }
    }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useStableCallback[registerTrigger]"]);
    const triggerElementRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const handleTriggerElementRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useCallback[handleTriggerElementRef]": (el)=>{
            triggerElementRef.current = el;
            store.set('activeTriggerElement', el);
        }
    }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useCallback[handleTriggerElementRef]"], [
        store
    ]);
    // A stable ref does not re-fire when the id changes, so register the rendered element here
    // instead. On React 17 the id also starts out `undefined`, so this is what registers the trigger
    // at all.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect": ()=>{
            registerTrigger(triggerElementRef.current);
            return ({
                "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect": ()=>registerTrigger(null)
            })["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect"];
        }
    }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect"], [
        registerTrigger,
        thisTriggerId,
        store
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect": ()=>{
            if (!open || !positionerElement) {
                return undefined;
            }
            function handleGuardFocusOut(event) {
                if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event) === store.context.beforeContentFocusGuardRef.current) {
                    focusReturnedThroughGuardRef.current = event.relatedTarget === triggerElementRef.current;
                }
            }
            // Observe focus leaving the guard inside its positioner. When the portal is in a shadow root,
            // the trigger's focus event can report the shadow host as `relatedTarget`, not the guard.
            positionerElement.addEventListener('focusout', handleGuardFocusOut, true);
            return ({
                "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect": ()=>{
                    focusReturnedThroughGuardRef.current = false;
                    positionerElement.removeEventListener('focusout', handleGuardFocusOut, true);
                }
            })["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect"];
        }
    }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useIsoLayoutEffect"], [
        open,
        positionerElement,
        store
    ]);
    store.useSyncedValue('closeDelay', closeDelay);
    const rootDisabled = store.useState('disabled');
    const parentDisabled = parentMenuStore.useState('disabled');
    const disabled = disabledProp || rootDisabled || parentDisabled;
    if ("TURBOPACK compile-time truthy", 1) {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useEffect": ()=>{
                const element = triggerElementRef.current;
                if (element && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$isElementDisabled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isElementDisabled"])(element) && !disabled) {
                    const ownerStackMessage = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$safeReact$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SafeReact"].captureOwnerStack?.() || '';
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["warn"])(`A disabled element was detected on <Menu.SubmenuTrigger>. To properly disable the trigger, use the \`disabled\` prop on the component instead of setting it on the rendered element.${ownerStackMessage}`);
                }
            }
        }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useEffect"]);
    }
    const itemProps = parentMenuStore.useState('itemProps');
    const highlighted = parentMenuStore.useState('isActive', listItem.index);
    const itemMetadata = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useMemo[itemMetadata]": ()=>({
                type: 'submenu-trigger',
                setActive (event) {
                    if (parentMenuStore.select('highlightItemOnHover')) {
                        parentMenuStore.setActiveIndex(listItem.index, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].pointer, event);
                    }
                }
            })
    }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useMemo[itemMetadata]"], [
        parentMenuStore,
        listItem.index
    ]);
    const { getItemProps, itemRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$item$2f$useMenuItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuItem"])({
        closeOnClick: false,
        disabled,
        highlighted,
        id: thisTriggerId,
        store,
        typingRef: parentMenuStore.context.typingRef,
        nativeButton,
        itemMetadata,
        nodeId: menuPositionerContext?.context.nodeId
    });
    const hoverEnabled = store.useState('hoverEnabled');
    const hoverProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useHoverReferenceInteraction$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHoverReferenceInteraction"])(floatingRootContext, {
        enabled: hoverEnabled && openOnHover && !disabled,
        handleClose: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$safePolygon$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safePolygon"])({
            blockPointerEvents: true
        }),
        mouseOnly: true,
        move: true,
        restMs: delay,
        delay: {
            open: delay,
            close: closeDelay
        },
        shouldOpen: delay > 0 ? ({
            "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useHoverReferenceInteraction[hoverProps]": ()=>parentMenuStore.select('allowMouseEnter')
        })["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useHoverReferenceInteraction[hoverProps]"] : undefined,
        triggerElementRef,
        externalTree: floatingTreeRoot,
        isClosing: {
            "MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useHoverReferenceInteraction[hoverProps]": ()=>store.select('transitionStatus') === 'ending'
        }["MenuSubmenuTriggerPlain.MenuSubmenuTriggerPlain.useHoverReferenceInteraction[hoverProps]"],
        // Chrome can drop the trigger's `mouseleave` during a fast pointer sweep,
        // leaving a stale submenu open (see #5152) — cancel from `mouseout` too.
        guardStaleOpen: true
    });
    const click = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useClick$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClick"])(floatingRootContext, {
        enabled: !disabled,
        event: 'mousedown',
        // Without toggling, TalkBack users cannot close the submenu to reach the next parent menu
        // item: moving the virtual cursor outside does not close it, and moving forward again
        // re-enters the still-open submenu. Keep toggling enabled so activating its trigger closes it.
        // Toggling applies to touch and keyboard activation. In hover mode, mouse presses are
        // ignored and the first activation after hover-opening keeps the submenu open.
        toggle: true,
        ignoreMouse: openOnHover,
        stickIfOpen: openOnHover
    });
    const localInteractionProps = click.reference ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"];
    const rootTriggerProps = store.useState('triggerProps', true);
    delete rootTriggerProps.id;
    const state = {
        disabled,
        highlighted,
        open
    };
    const openMethod = store.useState('openMethod');
    const lastOpenChangeReason = store.useState('lastOpenChangeReason');
    // Arrow keys open the submenu through list navigation without dispatching a click, so
    // `openMethod` stays null there; Enter and Space do dispatch one and report `keyboard`.
    const openedByKeyboard = lastOpenChangeReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation || openMethod === 'keyboard';
    const shouldOmitExpanded = open && openedByKeyboard && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__["platform"].screenReader.voiceOver;
    const submenuKeyDownProps = submenuRootContext?.onTriggerKeyDown ? {
        onKeyDown: submenuRootContext.onTriggerKeyDown
    } : undefined;
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["triggerOpenStateMapping"],
        props: [
            localInteractionProps,
            hoverProps,
            rootTriggerProps,
            // MenuFilterSubmenuRoot overrides the generic trigger handler because entry and exit
            // depend on both the parent and child menu orientations.
            submenuKeyDownProps,
            itemProps,
            // Opening a submenu changes the trigger's expanded state while the trigger still holds
            // focus, and VoiceOver announces that state change instead of the submenu item that focus
            // moves to a moment later, so the first item is never announced. Dropping the state while
            // the submenu is open avoids the announcement without claiming the submenu is collapsed;
            // `aria-haspopup` still conveys that the item opens a submenu.
            shouldOmitExpanded ? VOICE_OVER_EXPANDED_PROPS : undefined,
            {
                'aria-controls': popupId,
                // A virtually focused parent keeps real focus on its input, so the trigger must stay out
                // of the tab order.
                tabIndex: parentVirtualFocus || !(open || highlighted) ? -1 : 0,
                onFocus (event) {
                    // Close when focus returns through the submenu's guard to its trigger. This also lets
                    // screen reader users move past the trigger in the parent menu. Direct focus from a
                    // submenu item, such as on hover, leaves the submenu open.
                    if (store.select('open') && focusReturnedThroughGuardRef.current) {
                        focusReturnedThroughGuardRef.current = false;
                        store.setOpen(false, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].focusOut, event.nativeEvent));
                    }
                },
                onBlur () {
                    if (highlighted) {
                        parentMenuStore.setActiveIndex(null, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none);
                    }
                }
            },
            elementProps,
            // `getItemProps` stays last so `useButton` keeps gating consumer handlers while disabled.
            getItemProps
        ],
        ref: [
            forwardedRef,
            listItem.ref,
            itemRef,
            registerTrigger,
            handleTriggerElementRef
        ]
    });
    return element;
});
/**
 * A menu item that opens a submenu.
 * Renders a `<div>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ if ("TURBOPACK compile-time truthy", 1) MenuSubmenuTriggerPlain.displayName = "MenuSubmenuTriggerPlain";
const MenuSubmenuTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuSubmenuTrigger(props, forwardedRef) {
    const filterItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$filter$2d$root$2f$MenuFilterContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuFilterItem"])(props, forwardedRef, 'submenu-trigger');
    if (!filterItem.visible) {
        return null;
    }
    const mergedProps = filterItem.props ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(filterItem.props, props) : props;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(MenuSubmenuTriggerPlain, {
        ...mergedProps,
        ref: filterItem.ref
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuSubmenuTrigger.displayName = "MenuSubmenuTrigger";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/trigger/MenuTrigger.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuTrigger",
    ()=>MenuTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useTimeout.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/owner.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$fastHooks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/fastHooks.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$safePolygon$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/safePolygon.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useClick$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useClick.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingTree.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useFocus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useFocus.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useHoverReferenceInteraction$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/hooks/useHoverReferenceInteraction.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTreeStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/floating-ui-react/components/FloatingTreeStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popupStateMapping.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/use-button/useButton.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$getPseudoElementBounds$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/getPseudoElementBounds.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$item$2f$CompositeItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/item/CompositeItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$root$2f$CompositeRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/root/CompositeRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$findRootOwnerId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/findRootOwnerId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$usePopupHandleStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/usePopupHandleStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/popupStoreUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$useTriggerFocusGuards$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/popups/useTriggerFocusGuards.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useMixedToggleClickHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/useMixedToggleClickHandler.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menubar$2f$MenubarContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menubar/MenubarContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/constants.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$FocusGuard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/FocusGuard.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)");
/**
 * A button that opens the menu.
 * Renders a `<button>` element.
 *
 * Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const MenuTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$fastHooks$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fastComponentRef"])(function MenuTrigger(componentProps, forwardedRef) {
    const { render, className, style, disabled: disabledProp = false, nativeButton = true, id: idProp, openOnHover: openOnHoverProp, delay = 100, closeDelay = 0, handle, payload, ...elementProps } = componentProps;
    const rootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])(true);
    const handleStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$usePopupHandleStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePopupHandleStore"])(handle);
    const store = handleStore ?? rootContext?.store;
    if (!store) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: <Menu.Trigger> must be either used within a <Menu.Root> component or provided with a handle.' : "TURBOPACK unreachable");
    }
    const thisTriggerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const isTriggerActive = store.useState('isTriggerActive', thisTriggerId);
    const floatingRootContext = store.useState('floatingRootContext');
    const isOpenedByThisTrigger = store.useState('isOpenedByTrigger', thisTriggerId);
    const controlsId = store.useState('triggerControlsId', thisTriggerId);
    const triggerElementRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const parent = useMenuParent();
    const compositeRootContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$root$2f$CompositeRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeRootContext"])(true);
    const floatingTreeRootFromContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingTree"])();
    const floatingTreeRoot = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuTrigger.MenuTrigger.useMemo[floatingTreeRoot]": ()=>{
            return floatingTreeRootFromContext ?? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTreeStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FloatingTreeStore"]();
        }
    }["MenuTrigger.MenuTrigger.useMemo[floatingTreeRoot]"], [
        floatingTreeRootFromContext
    ]);
    const floatingNodeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingNodeId"])(floatingTreeRoot);
    const floatingParentNodeId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$components$2f$FloatingTree$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFloatingParentNodeId"])();
    const { registerTrigger, isMountedByThisTrigger } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$popupStoreUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTriggerDataForwarding"])(thisTriggerId, triggerElementRef, store, {
        payload,
        closeDelay,
        parent,
        floatingTreeRoot,
        floatingNodeId,
        floatingParentNodeId,
        keyboardEventRelay: compositeRootContext?.relayKeyboardEvent
    });
    const isInMenubar = parent.type === 'menubar';
    const rootDisabled = store.useState('disabled');
    const disabled = disabledProp || rootDisabled || isInMenubar && parent.context.disabled;
    const { getButtonProps, buttonRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        disabled,
        native: nativeButton
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuTrigger.MenuTrigger.useEffect": ()=>{
            if (!isOpenedByThisTrigger && parent.type === undefined) {
                store.context.allowMouseUpTriggerRef.current = false;
            }
        }
    }["MenuTrigger.MenuTrigger.useEffect"], [
        store,
        isOpenedByThisTrigger,
        parent.type
    ]);
    const triggerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const allowMouseUpTriggerTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const handleDocumentMouseUp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "MenuTrigger.MenuTrigger.useStableCallback[handleDocumentMouseUp]": (mouseEvent)=>{
            if (!triggerRef.current) {
                return;
            }
            allowMouseUpTriggerTimeout.clear();
            store.context.allowMouseUpTriggerRef.current = false;
            const mouseUpTarget = mouseEvent.target;
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(triggerRef.current, mouseUpTarget) || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["contains"])(store.select('positionerElement'), mouseUpTarget) || mouseUpTarget === triggerRef.current) {
                return;
            }
            if (mouseUpTarget != null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$utils$2f$findRootOwnerId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["findRootOwnerId"])(mouseUpTarget) === store.select('rootId')) {
                return;
            }
            if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$getPseudoElementBounds$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isMouseWithinBounds"])(mouseEvent, triggerRef.current)) {
                return;
            }
            floatingTreeRoot.events.emit('close', {
                domEvent: mouseEvent,
                reason: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].cancelOpen
            });
        }
    }["MenuTrigger.MenuTrigger.useStableCallback[handleDocumentMouseUp]"]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "MenuTrigger.MenuTrigger.useEffect": ()=>{
            const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(triggerRef.current);
            if (isOpenedByThisTrigger && store.select('lastOpenChangeReason') === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover) {
                doc.addEventListener('mouseup', handleDocumentMouseUp, {
                    once: true
                });
                return ({
                    "MenuTrigger.MenuTrigger.useEffect": ()=>{
                        doc.removeEventListener('mouseup', handleDocumentMouseUp);
                    }
                })["MenuTrigger.MenuTrigger.useEffect"];
            }
            return undefined;
        }
    }["MenuTrigger.MenuTrigger.useEffect"], [
        isOpenedByThisTrigger,
        handleDocumentMouseUp,
        store
    ]);
    const parentMenubarHasSubmenuOpen = isInMenubar && parent.context.hasSubmenuOpen;
    const openOnHover = openOnHoverProp ?? parentMenubarHasSubmenuOpen;
    const hoverProps = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useHoverReferenceInteraction$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useHoverReferenceInteraction"])(floatingRootContext, {
        enabled: openOnHover && !disabled && (!isInMenubar || parentMenubarHasSubmenuOpen && !isMountedByThisTrigger),
        handleClose: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$safePolygon$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["safePolygon"])({
            blockPointerEvents: !isInMenubar
        }),
        mouseOnly: true,
        move: false,
        restMs: parent.type === undefined ? delay : undefined,
        delay: {
            close: closeDelay
        },
        triggerElementRef,
        externalTree: floatingTreeRoot,
        isActiveTrigger: isTriggerActive,
        isClosing: {
            "MenuTrigger.MenuTrigger.useHoverReferenceInteraction[hoverProps]": ()=>store.select('transitionStatus') === 'ending'
        }["MenuTrigger.MenuTrigger.useHoverReferenceInteraction[hoverProps]"]
    });
    // Whether to ignore clicks to open the menu.
    // `lastOpenChangeReason` doesn't need to be reactive here, as we need to run this
    // only when `isOpenedByThisTrigger` changes.
    const stickIfOpen = useStickIfOpen(isOpenedByThisTrigger, store.select('lastOpenChangeReason'));
    const click = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useClick$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClick"])(floatingRootContext, {
        enabled: !disabled,
        event: isOpenedByThisTrigger && isInMenubar ? 'click' : 'mousedown',
        toggle: true,
        ignoreMouse: false,
        stickIfOpen: parent.type === undefined ? stickIfOpen : false
    });
    const focus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$floating$2d$ui$2d$react$2f$hooks$2f$useFocus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFocus"])(floatingRootContext, {
        enabled: !disabled && parentMenubarHasSubmenuOpen
    });
    const mixedToggleHandlers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$useMixedToggleClickHandler$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMixedToggleClickHandler"])({
        open: isOpenedByThisTrigger,
        enabled: isInMenubar,
        mouseDownAction: 'open'
    });
    const localInteractionProps = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "MenuTrigger.MenuTrigger.useMemo[localInteractionProps]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$merge$2d$props$2f$mergeProps$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeProps"])(focus.reference, click.reference)
    }["MenuTrigger.MenuTrigger.useMemo[localInteractionProps]"], [
        focus.reference,
        click.reference
    ]);
    const rootTriggerProps = store.useState('triggerProps', isMountedByThisTrigger);
    // A filterable menu keeps real focus inside its popup and publishes what its trigger needs.
    const filterTriggerProps = store.useState('filterTriggerProps');
    const { handlePreFocusGuardFocus, handleFocusTargetFocus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popups$2f$useTriggerFocusGuards$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTriggerFocusGuards"])(store, triggerElementRef);
    const state = {
        disabled,
        open: isOpenedByThisTrigger
    };
    const ref = [
        triggerRef,
        forwardedRef,
        buttonRef,
        registerTrigger,
        triggerElementRef
    ];
    const props = [
        localInteractionProps,
        hoverProps ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"],
        rootTriggerProps,
        {
            'aria-haspopup': 'menu',
            'aria-controls': controlsId,
            id: thisTriggerId,
            onMouseDown: (event)=>{
                if (store.select('open')) {
                    return;
                }
                // mousedown -> mouseup on menu item should not trigger it within 200ms.
                allowMouseUpTriggerTimeout.start(200, ()=>{
                    store.context.allowMouseUpTriggerRef.current = true;
                });
                const doc = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$owner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ownerDocument"])(event.currentTarget);
                doc.addEventListener('mouseup', handleDocumentMouseUp, {
                    once: true
                });
            }
        },
        filterTriggerProps,
        isInMenubar ? {
            role: 'menuitem'
        } : {},
        mixedToggleHandlers,
        elementProps,
        getButtonProps
    ];
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('button', componentProps, {
        enabled: !isInMenubar,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["pressableTriggerOpenStateMapping"],
        state,
        ref,
        props
    });
    if (isInMenubar) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$item$2f$CompositeItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CompositeItem"], {
            tag: "button",
            render: render,
            className: className,
            style: style,
            state: state,
            refs: ref,
            props: props,
            stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$popupStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["pressableTriggerOpenStateMapping"]
        });
    }
    // A fragment with key is required to ensure that the `element` is mounted to the same DOM node
    // regardless of whether the focus guards are rendered or not.
    if (isOpenedByThisTrigger) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxs"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$FocusGuard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusGuard"], {
                    ref: store.context.beforeTriggerFocusGuardRef,
                    onFocus: handlePreFocusGuardFocus
                }, `${thisTriggerId}-pre-focus-guard`),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: element
                }, thisTriggerId),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$FocusGuard$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FocusGuard"], {
                    ref: store.context.triggerFocusTargetRef,
                    onFocus: handleFocusTargetFocus
                }, `${thisTriggerId}-post-focus-guard`)
            ]
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: element
    }, thisTriggerId);
});
if ("TURBOPACK compile-time truthy", 1) MenuTrigger.displayName = "MenuTrigger";
/**
 * Determines whether to ignore clicks after a hover-open.
 */ function useStickIfOpen(open, openReason) {
    const stickIfOpenTimeout = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTimeout"])();
    const [stickIfOpen, setStickIfOpen] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useStickIfOpen.useIsoLayoutEffect": ()=>{
            if (open && openReason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerHover) {
                // Only allow "patient" clicks to close the menu if it's open.
                // If they clicked within 500ms of the menu opening, keep it open.
                setStickIfOpen(true);
                stickIfOpenTimeout.start(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$constants$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PATIENT_CLICK_THRESHOLD"], {
                    "useStickIfOpen.useIsoLayoutEffect": ()=>{
                        setStickIfOpen(false);
                    }
                }["useStickIfOpen.useIsoLayoutEffect"]);
            } else if (!open) {
                stickIfOpenTimeout.clear();
                setStickIfOpen(false);
            }
        }
    }["useStickIfOpen.useIsoLayoutEffect"], [
        open,
        openReason,
        stickIfOpenTimeout
    ]);
    return stickIfOpen;
}
function useMenuParent() {
    const menubarContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menubar$2f$MenubarContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenubarContext"])(true);
    const parent = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useMenuParent.useMemo[parent]": ()=>{
            if (menubarContext) {
                return {
                    type: 'menubar',
                    context: menubarContext
                };
            }
            return {
                type: undefined
            };
        }
    }["useMenuParent.useMemo[parent]"], [
        menubarContext
    ]);
    return parent;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/findRootOwnerId.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "findRootOwnerId",
    ()=>findRootOwnerId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript)");
;
function findRootOwnerId(node) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isHTMLElement"])(node) && node.hasAttribute('data-rootownerid')) {
        return node.getAttribute('data-rootownerid');
    }
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isLastTraversableNode"])(node)) {
        return undefined;
    }
    return findRootOwnerId((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getParentNode"])(node));
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/isKeyboardOpen.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isKeyboardClick",
    ()=>isKeyboardClick,
    "isKeyboardOpen",
    ()=>isKeyboardOpen
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
;
function isKeyboardClick(reason, event) {
    return (reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerPress || reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].itemPress) && event?.detail === 0;
}
function isKeyboardOpen(reason, event) {
    return reason === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].listNavigation || isKeyboardClick(reason, event);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "itemMapping",
    ()=>itemMapping
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/stateAttributesMapping.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemDataAttributes.mjs [app-client] (ecmascript)");
;
;
const itemMapping = {
    checked (value) {
        if (value) {
            return {
                [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checked"]]: ''
            };
        }
        return {
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$checkbox$2d$item$2f$MenuCheckboxItemDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unchecked"]]: ''
        };
    },
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["transitionStatusMapping"]
};
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/viewport/MenuViewport.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenuViewport",
    ()=>MenuViewport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/root/MenuRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$usePopupViewport$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/usePopupViewport.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
const MenuViewport = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function MenuViewport(componentProps, forwardedRef) {
    const { render, className, style, children, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$root$2f$MenuRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuRootContext"])();
    const { side } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$menu$2f$positioner$2f$MenuPositionerContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMenuPositionerContext"])();
    const instantType = store.useState('instantType');
    const { children: childrenToRender, state: viewportState } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$usePopupViewport$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePopupViewport"])({
        store,
        side,
        children
    });
    const state = {
        activationDirection: viewportState.activationDirection,
        transitioning: viewportState.transitioning,
        instant: instantType
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: forwardedRef,
        props: [
            elementProps,
            {
                children: childrenToRender
            }
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$usePopupViewport$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["popupViewportStateMapping"]
    });
});
if ("TURBOPACK compile-time truthy", 1) MenuViewport.displayName = "MenuViewport";
}),
]);

//# sourceMappingURL=0u8u_%40base-ui_react_menu_0slutv9._.js.map