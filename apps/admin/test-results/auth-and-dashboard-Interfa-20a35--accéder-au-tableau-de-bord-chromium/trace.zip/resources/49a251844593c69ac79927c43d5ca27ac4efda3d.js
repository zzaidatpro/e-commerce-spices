(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/header/AccordionHeader.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionHeader",
    ()=>AccordionHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/stateAttributesMapping.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
const AccordionHeader = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function AccordionHeader(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    const { state } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccordionItemContext"])();
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('h3', componentProps, {
        state,
        ref: forwardedRef,
        props: elementProps,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accordionStateAttributesMapping"]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) AccordionHeader.displayName = "AccordionHeader";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionItem",
    ()=>AccordionItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$useCollapsibleRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/root/useCollapsibleRoot.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$CollapsibleRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/root/CollapsibleRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/useCompositeListItem.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$root$2f$AccordionRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/root/AccordionRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
const AccordionItem = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function AccordionItem(componentProps, forwardedRef) {
    const { className, disabled: disabledProp = false, onOpenChange: onOpenChangeProp, render, value: valueProp, style, ...elementProps } = componentProps;
    const { ref: listItemRef, index } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$useCompositeListItem$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCompositeListItem"])();
    const { disabled: contextDisabled, handleValueChange, state: rootState, value: openValues } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$root$2f$AccordionRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccordionRootContext"])();
    const fallbackValue = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    const value = valueProp ?? fallbackValue;
    const disabled = disabledProp || contextDisabled;
    const isOpen = openValues.includes(value);
    const onOpenChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "AccordionItem.AccordionItem.useStableCallback[onOpenChange]": (nextOpen, eventDetails)=>{
            onOpenChangeProp?.(nextOpen, eventDetails);
            if (eventDetails.isCanceled) {
                return;
            }
            handleValueChange(value, nextOpen, eventDetails);
        }
    }["AccordionItem.AccordionItem.useStableCallback[onOpenChange]"]);
    const collapsible = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$useCollapsibleRoot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollapsibleRoot"])({
        open: isOpen,
        onOpenChange,
        disabled
    });
    const collapsibleContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "AccordionItem.AccordionItem.useMemo[collapsibleContext]": ()=>({
                ...collapsible,
                onOpenChange,
                state: {
                    open: collapsible.open,
                    disabled: collapsible.disabled,
                    transitionStatus: collapsible.transitionStatus
                }
            })
    }["AccordionItem.AccordionItem.useMemo[collapsibleContext]"], [
        collapsible,
        onOpenChange
    ]);
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "AccordionItem.AccordionItem.useMemo[state]": ()=>({
                ...rootState,
                hidden: !isOpen && !collapsible.mounted,
                index,
                disabled,
                open: isOpen
            })
    }["AccordionItem.AccordionItem.useMemo[state]"], [
        collapsible.mounted,
        disabled,
        index,
        isOpen,
        rootState
    ]);
    const defaultTriggerId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    // `undefined` uses the initial generated fallback; `null` means the trigger unmounted.
    const [registeredTriggerId, setTriggerId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const triggerId = registeredTriggerId === null ? undefined : registeredTriggerId ?? defaultTriggerId;
    const accordionItemContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "AccordionItem.AccordionItem.useMemo[accordionItemContext]": ()=>({
                defaultTriggerId,
                open: isOpen,
                state,
                setTriggerId,
                triggerId
            })
    }["AccordionItem.AccordionItem.useMemo[accordionItemContext]"], [
        defaultTriggerId,
        isOpen,
        state,
        setTriggerId,
        triggerId
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: [
            forwardedRef,
            listItemRef
        ],
        props: elementProps,
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accordionStateAttributesMapping"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$CollapsibleRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CollapsibleRootContext"].Provider, {
        value: collapsibleContext,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionItemContext"].Provider, {
            value: accordionItemContext,
            children: element
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) AccordionItem.displayName = "AccordionItem";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionItemContext",
    ()=>AccordionItemContext,
    "useAccordionItemContext",
    ()=>useAccordionItemContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const AccordionItemContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) AccordionItemContext.displayName = "AccordionItemContext";
function useAccordionItemContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](AccordionItemContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: AccordionItemContext is missing. Accordion parts must be placed within <Accordion.Item>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemDataAttributes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Indicates the index of the accordion item.
 * @type {number}
 */ __turbopack_context__.s([
    "disabled",
    ()=>disabled,
    "index",
    ()=>index,
    "open",
    ()=>open
]);
const index = 'data-index';
const disabled = 'data-disabled';
const open = 'data-open';
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/stateAttributesMapping.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "accordionStateAttributesMapping",
    ()=>accordionStateAttributesMapping
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$collapsibleOpenStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/collapsibleOpenStateMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/stateAttributesMapping.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemDataAttributes.mjs [app-client] (ecmascript)");
;
;
;
const accordionStateAttributesMapping = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$collapsibleOpenStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collapsibleOpenStateMapping"],
    index: (value)=>({
            [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["index"]]: String(value)
        }),
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["transitionStatusMapping"],
    value: ()=>null
};
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/panel/AccordionPanel.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionPanel",
    ()=>AccordionPanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/warn.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$resolveStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/resolveStyle.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$CollapsibleRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/root/CollapsibleRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$useCollapsiblePanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/panel/useCollapsiblePanel.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$root$2f$AccordionRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/root/AccordionRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$panel$2f$AccordionPanelCssVars$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/panel/AccordionPanelCssVars.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
const AccordionPanel = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function AccordionPanel(componentProps, forwardedRef) {
    const { className, hiddenUntilFound: hiddenUntilFoundProp, keepMounted: keepMountedProp, id: idProp, render, style, ...elementProps } = componentProps;
    const { hiddenUntilFound: contextHiddenUntilFound, keepMounted: contextKeepMounted } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$root$2f$AccordionRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccordionRootContext"])();
    const { defaultPanelId, mounted, onOpenChange, open, setMounted, setOpen, setPanelIdState, transitionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$CollapsibleRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollapsibleRootContext"])();
    const hiddenUntilFound = hiddenUntilFoundProp ?? contextHiddenUntilFound;
    const keepMounted = keepMountedProp ?? contextKeepMounted;
    const registeredId = idProp || undefined;
    const id = idProp ?? defaultPanelId;
    /* istanbul ignore else -- `process.env.NODE_ENV` is a build-time constant under test */ if ("TURBOPACK compile-time truthy", 1) {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "AccordionPanel.AccordionPanel.useEffect": ()=>{
                if (keepMountedProp === false && hiddenUntilFound) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["warn"])('The `keepMounted={false}` prop on an `Accordion.Panel` is ignored when `hiddenUntilFound` is enabled on the panel or root, since the panel must remain mounted while closed.');
                }
            }
        }["AccordionPanel.AccordionPanel.useEffect"], [
            hiddenUntilFound,
            keepMountedProp
        ]);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "AccordionPanel.AccordionPanel.useIsoLayoutEffect": ()=>{
            setPanelIdState({
                "AccordionPanel.AccordionPanel.useIsoLayoutEffect": (currentId)=>registeredId ?? (currentId === null ? undefined : currentId)
            }["AccordionPanel.AccordionPanel.useIsoLayoutEffect"]);
            return ({
                "AccordionPanel.AccordionPanel.useIsoLayoutEffect": ()=>{
                    setPanelIdState({
                        "AccordionPanel.AccordionPanel.useIsoLayoutEffect": (currentId)=>currentId === registeredId ? null : currentId
                    }["AccordionPanel.AccordionPanel.useIsoLayoutEffect"]);
                }
            })["AccordionPanel.AccordionPanel.useIsoLayoutEffect"];
        }
    }["AccordionPanel.AccordionPanel.useIsoLayoutEffect"], [
        registeredId,
        setPanelIdState
    ]);
    const { height, props, ref, shouldPreventOpenAnimation, shouldRender, transitionStatus: panelTransitionStatus, width } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$useCollapsiblePanel$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollapsiblePanel"])({
        externalRef: forwardedRef,
        hiddenUntilFound,
        id,
        keepMounted,
        mounted,
        onOpenChange,
        open,
        setMounted,
        setOpen,
        transitionStatus
    });
    const { state, triggerId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccordionItemContext"])();
    const panelState = {
        ...state,
        transitionStatus: panelTransitionStatus
    };
    const resolvedStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$resolveStyle$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resolveStyle"])(style, panelState);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', {
        ...componentProps,
        style: undefined
    }, {
        state: panelState,
        ref,
        props: [
            props,
            {
                'aria-labelledby': triggerId,
                role: 'region',
                style: {
                    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$panel$2f$AccordionPanelCssVars$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accordionPanelHeight"]]: height === undefined ? 'auto' : `${height}px`,
                    [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$panel$2f$AccordionPanelCssVars$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accordionPanelWidth"]]: width === undefined ? 'auto' : `${width}px`
                }
            },
            elementProps,
            resolvedStyle ? {
                style: resolvedStyle
            } : undefined,
            // Resolve the public `style` prop so temporary `animationName: 'none'`
            // can still win after user's inline styles have been merged.
            shouldPreventOpenAnimation ? {
                style: {
                    animationName: 'none'
                }
            } : undefined
        ],
        stateAttributesMapping: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accordionStateAttributesMapping"]
    });
    if (!shouldRender) {
        return null;
    }
    return element;
});
if ("TURBOPACK compile-time truthy", 1) AccordionPanel.displayName = "AccordionPanel";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/panel/AccordionPanelCssVars.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * The accordion panel's height.
 * @type {number}
 */ __turbopack_context__.s([
    "accordionPanelHeight",
    ()=>accordionPanelHeight,
    "accordionPanelWidth",
    ()=>accordionPanelWidth
]);
const accordionPanelHeight = '--accordion-panel-height';
const accordionPanelWidth = '--accordion-panel-width';
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/root/AccordionRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionRoot",
    ()=>AccordionRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useControlled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/warn.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/composite/list/CompositeList.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$root$2f$AccordionRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/root/AccordionRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
const rootStateAttributesMapping = {
    value: ()=>null
};
const AccordionRoot = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function AccordionRoot(componentProps, forwardedRef) {
    const { render, className, disabled = false, hiddenUntilFound: hiddenUntilFoundProp, keepMounted: keepMountedProp, loopFocus, onValueChange, multiple = false, orientation = 'vertical', value: valueProp, defaultValue: defaultValueProp, style, ...elementProps } = componentProps;
    const defaultValue = defaultValueProp ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_ARRAY"];
    /* istanbul ignore else -- `process.env.NODE_ENV` is a build-time constant under test */ if ("TURBOPACK compile-time truthy", 1) {
        // eslint-disable-next-line react-hooks/rules-of-hooks
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
            "AccordionRoot.AccordionRoot.useEffect": ()=>{
                if (hiddenUntilFoundProp && keepMountedProp === false) {
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["warn"])('The `keepMounted={false}` prop on `Accordion.Root` is ignored when `hiddenUntilFound` is enabled, since panels must remain mounted while closed.');
                }
            }
        }["AccordionRoot.AccordionRoot.useEffect"], [
            hiddenUntilFoundProp,
            keepMountedProp
        ]);
    }
    const accordionItemRefs = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"]([]);
    const [value, setValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: valueProp,
        default: defaultValue,
        name: 'Accordion',
        state: 'value'
    });
    const handleValueChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "AccordionRoot.AccordionRoot.useStableCallback[handleValueChange]": (newValue, nextOpen, details)=>{
            let nextValue;
            if (!multiple) {
                nextValue = value[0] === newValue ? [] : [
                    newValue
                ];
            } else if (nextOpen) {
                // Not `concat`: an item value can itself be an array, which `concat` would flatten.
                nextValue = [
                    ...value,
                    newValue
                ];
            } else {
                nextValue = value.filter({
                    "AccordionRoot.AccordionRoot.useStableCallback[handleValueChange]": (v)=>v !== newValue
                }["AccordionRoot.AccordionRoot.useStableCallback[handleValueChange]"]);
            }
            onValueChange?.(nextValue, details);
            if (details.isCanceled) {
                return;
            }
            setValue(nextValue);
        }
    }["AccordionRoot.AccordionRoot.useStableCallback[handleValueChange]"]);
    const state = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "AccordionRoot.AccordionRoot.useMemo[state]": ()=>({
                value,
                disabled,
                orientation
            })
    }["AccordionRoot.AccordionRoot.useMemo[state]"], [
        value,
        disabled,
        orientation
    ]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "AccordionRoot.AccordionRoot.useMemo[contextValue]": ()=>({
                disabled,
                handleValueChange,
                hiddenUntilFound: hiddenUntilFoundProp ?? false,
                keepMounted: keepMountedProp ?? false,
                state,
                value
            })
    }["AccordionRoot.AccordionRoot.useMemo[contextValue]"], [
        disabled,
        handleValueChange,
        hiddenUntilFoundProp,
        keepMountedProp,
        state,
        value
    ]);
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: forwardedRef,
        props: elementProps,
        stateAttributesMapping: rootStateAttributesMapping
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$root$2f$AccordionRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AccordionRootContext"].Provider, {
        value: contextValue,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$composite$2f$list$2f$CompositeList$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CompositeList"], {
            elementsRef: accordionItemRefs,
            children: element
        })
    });
});
if ("TURBOPACK compile-time truthy", 1) AccordionRoot.displayName = "AccordionRoot";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/root/AccordionRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionRootContext",
    ()=>AccordionRootContext,
    "useAccordionRootContext",
    ()=>useAccordionRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const AccordionRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) AccordionRootContext.displayName = "AccordionRootContext";
function useAccordionRootContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](AccordionRootContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: AccordionRootContext is missing. Accordion parts must be placed within <Accordion.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/trigger/AccordionTrigger.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AccordionTrigger",
    ()=>AccordionTrigger
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$collapsibleOpenStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/collapsibleOpenStateMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/use-button/useButton.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$CollapsibleRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/root/CollapsibleRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/AccordionItemContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/accordion/item/stateAttributesMapping.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const stateAttributesMapping = {
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$stateAttributesMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["accordionStateAttributesMapping"],
    ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$collapsibleOpenStateMapping$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["triggerOpenStateMapping"]
};
const AccordionTrigger = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function AccordionTrigger(componentProps, forwardedRef) {
    const { disabled: disabledProp, className, id: idProp, render, nativeButton = true, style, ...elementProps } = componentProps;
    const { panelId, open, handleTrigger, disabled: contextDisabled } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$root$2f$CollapsibleRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCollapsibleRootContext"])();
    const disabled = disabledProp || contextDisabled;
    const { getButtonProps, buttonRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        disabled,
        native: nativeButton
    });
    const { defaultTriggerId, state, setTriggerId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$accordion$2f$item$2f$AccordionItemContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccordionItemContext"])();
    const registeredId = idProp || undefined;
    const id = registeredId ?? defaultTriggerId;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "AccordionTrigger.AccordionTrigger.useIsoLayoutEffect": ()=>{
            setTriggerId({
                "AccordionTrigger.AccordionTrigger.useIsoLayoutEffect": (currentId)=>registeredId ?? (currentId === null ? undefined : currentId)
            }["AccordionTrigger.AccordionTrigger.useIsoLayoutEffect"]);
            return ({
                "AccordionTrigger.AccordionTrigger.useIsoLayoutEffect": ()=>{
                    setTriggerId({
                        "AccordionTrigger.AccordionTrigger.useIsoLayoutEffect": (currentId)=>currentId === registeredId ? null : currentId
                    }["AccordionTrigger.AccordionTrigger.useIsoLayoutEffect"]);
                }
            })["AccordionTrigger.AccordionTrigger.useIsoLayoutEffect"];
        }
    }["AccordionTrigger.AccordionTrigger.useIsoLayoutEffect"], [
        registeredId,
        setTriggerId
    ]);
    const props = {
        'aria-controls': open ? panelId : undefined,
        'aria-expanded': open,
        id,
        onClick: handleTrigger
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('button', componentProps, {
        state,
        ref: [
            forwardedRef,
            buttonRef
        ],
        props: [
            props,
            elementProps,
            getButtonProps
        ],
        stateAttributesMapping
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) AccordionTrigger.displayName = "AccordionTrigger";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/button/Button.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/use-button/useButton.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
'use client';
;
;
;
const Button = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Button(componentProps, forwardedRef) {
    const { render, className, disabled = false, focusableWhenDisabled = false, nativeButton = true, style, ...elementProps } = componentProps;
    const { getButtonProps, buttonRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        disabled,
        focusableWhenDisabled,
        native: nativeButton
    });
    const state = {
        disabled
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('button', componentProps, {
        state,
        ref: [
            forwardedRef,
            buttonRef
        ],
        props: [
            elementProps,
            getButtonProps
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) Button.displayName = "Button";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/panel/CollapsiblePanelDataAttributes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "closed",
    ()=>closed,
    "endingStyle",
    ()=>endingStyle,
    "open",
    ()=>open,
    "startingStyle",
    ()=>startingStyle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$TransitionStatusDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__TransitionStatusDataAttributes$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/TransitionStatusDataAttributes.mjs [app-client] (ecmascript) <export * as TransitionStatusDataAttributes>");
;
const open = 'data-open';
const closed = 'data-closed';
const startingStyle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$TransitionStatusDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__TransitionStatusDataAttributes$3e$__["TransitionStatusDataAttributes"].startingStyle;
const endingStyle = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$TransitionStatusDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__TransitionStatusDataAttributes$3e$__["TransitionStatusDataAttributes"].endingStyle;
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/panel/useCollapsiblePanel.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCollapsiblePanel",
    ()=>useCollapsiblePanel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$addEventListener$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/addEventListener.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useMergedRefs.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useAnimationFrame.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useTimeout.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useValueAsRef.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/warn.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@floating-ui+utils@0.2.12/node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs [app-client] (ecmascript) <export getWindow as ownerWindow>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useOpenChangeComplete.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useAnimationsFinished$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useAnimationsFinished.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$CollapsiblePanelDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/panel/CollapsiblePanelDataAttributes.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const EMPTY_DIMENSIONS = {
    height: undefined,
    width: undefined
};
function useCollapsiblePanel(parameters) {
    const { externalRef, hiddenUntilFound, id: idParam, keepMounted, mounted, onOpenChange, open, setMounted, setOpen, transitionStatus } = parameters;
    const panelRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const animationTypeRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const [dimensions, setDimensionsUnwrapped] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](EMPTY_DIMENSIONS);
    const lastMeasuredDimensionsRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](EMPTY_DIMENSIONS);
    // `beforematch` should reveal the matched content immediately, so the next
    // open cycle skips author-defined motion once and then returns to normal.
    const shouldSkipNextOpenRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    // Keyframe mount animations on initially open panels cause a visible layout
    // shift during the server-rendered first paint, so suppress that first open
    // lifecycle until the panel has been closed once.
    const shouldPreventMountAnimationRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](open);
    // React.Activity tears down Effects while preserving state, so revealing an
    // already-open panel would otherwise replay its CSS keyframe open animation.
    const shouldPreventActivityResumeAnimationRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    // Some open paths intentionally bypass motion, but the shared root transition
    // status still advances asynchronously. Override the panel to idle so its data
    // attributes and dimension cleanup reflect the immediate open state.
    const [forcePanelIdle, setForcePanelIdle] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    const pendingTemporaryStyleRestoreRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const mergedPanelRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useMergedRefs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMergedRefs"])(externalRef, panelRef);
    const latestOpenRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValueAsRef"])(open);
    // Only used to handle panel close
    const runOnceCloseAnimationsFinish = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useAnimationsFinished$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAnimationsFinished"])(panelRef);
    const hidden = !open && !mounted;
    const panelTransitionStatus = forcePanelIdle ? 'idle' : transitionStatus;
    const shouldPreventOpenAnimation = open && (// These 2 refs are safe to read in render, they are only written from committed
    // layout/effect paths and gate one-shot motion suppression for the next open
    // lifecycle. They intentionally expose the last committed motion snapshot.
    shouldPreventMountAnimationRef.current || shouldPreventActivityResumeAnimationRef.current);
    const renderedDimensions = !open && mounted && // These 2 refs are also safe to read in render, both hold the last committed
    // animation mode and measurement. This fallback only restores a previously
    // measured pixel size after the live dimensions state has been reset back to `auto`.
    animationTypeRef.current === 'css-animation' && dimensions.height === undefined && dimensions.width === undefined ? lastMeasuredDimensionsRef.current : dimensions;
    const shouldPersistHiddenTransitionStyles = hiddenUntilFound && hidden && animationTypeRef.current !== 'css-animation';
    // Most measured dimensions are reused later when CSS keyframe closes need a
    // pixel size after the rendered dimensions have been reset back to `auto`.
    // Passing `false` is only for clearing the current dimensions state.
    const setDimensions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useCollapsiblePanel.useStableCallback[setDimensions]": (nextDimensions, shouldCacheMeasurement = true)=>{
            if (shouldCacheMeasurement) {
                lastMeasuredDimensionsRef.current = nextDimensions;
            }
            setDimensionsUnwrapped(nextDimensions);
        }
    }["useCollapsiblePanel.useStableCallback[setDimensions]"]);
    const restorePendingTemporaryStyle = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useCollapsiblePanel.useStableCallback[restorePendingTemporaryStyle]": ()=>{
            pendingTemporaryStyleRestoreRef.current?.();
            pendingTemporaryStyleRestoreRef.current = null;
        }
    }["useCollapsiblePanel.useStableCallback[restorePendingTemporaryStyle]"]);
    const setPendingTemporaryStyleRestore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useCollapsiblePanel.useStableCallback[setPendingTemporaryStyleRestore]": (restore)=>{
            restorePendingTemporaryStyle();
            pendingTemporaryStyleRestoreRef.current = ({
                "useCollapsiblePanel.useStableCallback[setPendingTemporaryStyleRestore]": ()=>{
                    pendingTemporaryStyleRestoreRef.current = null;
                    restore();
                }
            })["useCollapsiblePanel.useStableCallback[setPendingTemporaryStyleRestore]"];
        }
    }["useCollapsiblePanel.useStableCallback[setPendingTemporaryStyleRestore]"]);
    // React.Activity unmounts Effects while preserving component state. If that
    // teardown happens while an already-open keyframe panel is visible, remember
    // to suppress the replayed open animation on the next committed reveal.
    const markActivityResumeAnimationSuppressed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useCollapsiblePanel.useStableCallback[markActivityResumeAnimationSuppressed]": ()=>{
            if (open && mounted && animationTypeRef.current === 'css-animation') {
                shouldPreventActivityResumeAnimationRef.current = true;
            }
        }
    }["useCollapsiblePanel.useStableCallback[markActivityResumeAnimationSuppressed]"]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useCollapsiblePanel.useIsoLayoutEffect": ()=>{
            // `forcePanelIdle` is only a temporary override for open paths that skip
            // motion. Keep it active while the shared root still reports `starting`,
            // then drop it once the root transition state catches up.
            if (!forcePanelIdle || transitionStatus === 'starting') {
                return;
            }
            setForcePanelIdle(false);
        }
    }["useCollapsiblePanel.useIsoLayoutEffect"], [
        forcePanelIdle,
        transitionStatus
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useCollapsiblePanel.useEffect": ()=>{
            return ({
                "useCollapsiblePanel.useEffect": ()=>{
                    markActivityResumeAnimationSuppressed();
                    restorePendingTemporaryStyle();
                }
            })["useCollapsiblePanel.useEffect"];
        }
    }["useCollapsiblePanel.useEffect"], [
        markActivityResumeAnimationSuppressed,
        restorePendingTemporaryStyle
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useCollapsiblePanel.useIsoLayoutEffect": ()=>{
            // A render function can remove the panel on close. Clear one-shot open animation
            // suppression even without an element, so the next open animates normally.
            if (!open) {
                shouldPreventMountAnimationRef.current = false;
                shouldPreventActivityResumeAnimationRef.current = false;
            }
            const panel = panelRef.current;
            if (!panel) {
                return undefined;
            }
            // `beforematch` can temporarily force a `0s` motion duration so the matched
            // content reveals immediately. Restore the authored duration before detecting
            // the next close animation type, otherwise that first close is misread as
            // "no motion" and the close transition or keyframe gets skipped.
            if (!open && pendingTemporaryStyleRestoreRef.current) {
                restorePendingTemporaryStyle();
            }
            const animationType = getAnimationType(panel, shouldPreventOpenAnimation);
            animationTypeRef.current = animationType;
            // Initially open keyframe panels skip their first paint animation to avoid
            // layout shift, but we still need to cache the expanded size so the first
            // close animation can start from pixels instead of `auto`.
            if (open && transitionStatus === 'idle' && shouldPreventMountAnimationRef.current && animationType === 'css-animation') {
                lastMeasuredDimensionsRef.current = getDimensions(panel);
                return undefined;
            }
            // Handle the opening pass: measure the expanded size and, when necessary,
            // neutralize author-defined motion so the panel can open immediately.
            if (open && transitionStatus === 'starting') {
                // `beforematch` opens should reveal the panel immediately so find-in-page
                // does not wait for the author-defined transition or animation to finish.
                const skipNextOpen = shouldSkipNextOpenRef.current;
                shouldSkipNextOpenRef.current = false;
                if (animationType === 'none') {
                    setDimensions(getDimensions(panel));
                    setForcePanelIdle(true);
                    return undefined;
                }
                if (animationType === 'css-transition') {
                    const restoreLayoutStyles = resetLayoutStyles(panel);
                    setDimensions(getDimensions(panel));
                    if (!skipNextOpen) {
                        return restoreLayoutStyles;
                    }
                    const restoreTransitionDuration = setTemporaryStyle(panel, 'transition-duration', '0s');
                    setPendingTemporaryStyleRestore(restoreTransitionDuration);
                    setForcePanelIdle(true);
                    return restoreLayoutStyles;
                }
                setDimensions(getDimensions(panel));
                const restoreAnimationName = setTemporaryStyle(panel, 'animation-name', 'none');
                if (!skipNextOpen) {
                    restoreAnimationName();
                    return undefined;
                }
                const restoreAnimationDuration = setTemporaryStyle(panel, 'animation-duration', '0s');
                restoreAnimationName();
                setPendingTemporaryStyleRestore(restoreAnimationDuration);
                setForcePanelIdle(true);
                return undefined;
            }
            // Capture the current size as soon as close is requested, before the
            // deferred ending phase applies closed styles. This keeps close transitions
            // starting from a measured pixel value, including interrupted opens.
            if (!open && mounted && (transitionStatus === 'idle' || transitionStatus === 'starting')) {
                if (animationType === 'none') {
                    setDimensions(EMPTY_DIMENSIONS, false);
                    setMounted(false);
                    return undefined;
                }
                setDimensions(getDimensions(panel));
                return undefined;
            }
            if (transitionStatus !== 'ending') {
                return undefined;
            }
            // Reachable when `transitionStatus` already flipped to `ending` before this effect ran, so
            // the close branch above was skipped. Without motion there is nothing to wait for, so unmount
            // here instead of deferring to the animation-finished path below.
            if (animationType === 'none') {
                setMounted(false);
                return undefined;
            }
            const nextDimensions = getDimensions(panel);
            const hasMeasuredSize = nextDimensions.height > 0 || nextDimensions.width > 0;
            if (!hasMeasuredSize) {
                setMounted(false);
                return undefined;
            }
            setDimensions(nextDimensions);
            if (animationType === 'css-animation') {
                const restoreAnimationName = setTemporaryStyle(panel, 'animation-name', 'none');
                restoreAnimationName();
            }
            return undefined;
        }
    }["useCollapsiblePanel.useIsoLayoutEffect"], [
        mounted,
        open,
        restorePendingTemporaryStyle,
        setDimensions,
        setMounted,
        setPendingTemporaryStyleRestore,
        shouldPreventOpenAnimation,
        transitionStatus
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useOpenChangeComplete$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useOpenChangeComplete"])({
        enabled: open && mounted && panelTransitionStatus === 'idle',
        open: true,
        ref: panelRef,
        onComplete () {
            // `useOpenChangeComplete` only aborts from its effect cleanup, which React runs in the
            // post-paint passive flush. An animation's `finished` microtask can resolve after the render
            // that set `open` to `false` but before that cleanup, so re-check the latest value here.
            // Clearing the measured size in that window would make the close transition start from
            // `height: 0` instead of the expanded pixel height.
            if (!open) {
                return;
            }
            setDimensions(EMPTY_DIMENSIONS, false);
        }
    });
    // Closing panels need extra sequencing beyond `useOpenChangeComplete`.
    // This passive effect runs after the `ending` render has committed, so
    // `[data-ending-style]` is already present. Chrome can still register the
    // exit transition one frame later when an Accordion closes one item while
    // opening another, so wait one frame before watching animations.
    // See https://github.com/mui/base-ui/issues/3099
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"]({
        "useCollapsiblePanel.useEffect": ()=>{
            if (open || !mounted || panelTransitionStatus !== 'ending') {
                return undefined;
            }
            const panel = panelRef.current;
            if (!panel) {
                // A render function can drop the panel element while it closes. There is nothing left
                // to animate, so finish closing instead of staying in the ending phase.
                setMounted(false);
                setDimensions(EMPTY_DIMENSIONS, false);
                return undefined;
            }
            const abortController = new AbortController();
            let endingStyleFrame = -1;
            function handleComplete() {
                // Same post-paint race as the `useOpenChangeComplete` callback above, except `open` is
                // captured by this effect's closure and always `false` here, so read the latest value from
                // a ref. Unmounting a panel that has already reopened would drop it from the DOM.
                if (latestOpenRef.current) {
                    return;
                }
                setMounted(false);
                setDimensions(EMPTY_DIMENSIONS, false);
            }
            endingStyleFrame = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].request({
                "useCollapsiblePanel.useEffect": ()=>{
                    runOnceCloseAnimationsFinish(handleComplete, abortController.signal);
                }
            }["useCollapsiblePanel.useEffect"]);
            return ({
                "useCollapsiblePanel.useEffect": ()=>{
                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].cancel(endingStyleFrame);
                    abortController.abort();
                }
            })["useCollapsiblePanel.useEffect"];
        }
    }["useCollapsiblePanel.useEffect"], [
        latestOpenRef,
        mounted,
        open,
        panelTransitionStatus,
        runOnceCloseAnimationsFinish,
        setDimensions,
        setMounted
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useCollapsiblePanel.useIsoLayoutEffect": ()=>{
            const panel = panelRef.current;
            if (!panel || !hiddenUntilFound || !hidden) {
                return;
            }
            // React only supports a boolean for the `hidden` attribute and forces
            // legit string values to booleans so we have to force it back in the DOM
            // when necessary: https://github.com/react/react/issues/24740
            panel.setAttribute('hidden', 'until-found');
        }
    }["useCollapsiblePanel.useIsoLayoutEffect"], [
        hidden,
        hiddenUntilFound
    ]);
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"](function registerBeforeMatchListener() {
        const panel = panelRef.current;
        if (!panel) {
            return undefined;
        }
        const revealDecisionTimeout = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useTimeout$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timeout"].create();
        let revertRevealFrame = -1;
        // Reverting must wait until the browser has measured the match, and React
        // cannot do it: it keeps rendering the same `hidden` and `data-starting-style`
        // props while the panel stays closed, so it never rewrites attributes that were
        // changed behind its back (the browser removes `hidden` as part of the reveal).
        //
        // Whether the open arrived is decided in a task, not a frame: `setOpen` has
        // already scheduled React's own task by the time the timeout is queued, so the
        // decision drains after the commit even when a busy main thread delays both,
        // whereas a rendering update could preempt the still-queued commit and make an
        // animation frame read a stale value. When the consumer ignores the open, no
        // commit is ever scheduled and the decision holds. The DOM revert then runs
        // in a frame so it stays atomic with respect to paint.
        const scheduleRevealRevert = {
            "useCollapsiblePanel.useEffect.registerBeforeMatchListener.scheduleRevealRevert": (revertSkippedMotion, restoreStartingStyle)=>{
                revealDecisionTimeout.start(0, {
                    "useCollapsiblePanel.useEffect.registerBeforeMatchListener.scheduleRevealRevert": ()=>{
                        if (latestOpenRef.current) {
                            return;
                        }
                        revertRevealFrame = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].request({
                            "useCollapsiblePanel.useEffect.registerBeforeMatchListener.scheduleRevealRevert": ()=>{
                                if (latestOpenRef.current) {
                                    return;
                                }
                                if (revertSkippedMotion) {
                                    // The open never happened, so the next one is an ordinary open that
                                    // should keep its author-defined motion.
                                    shouldSkipNextOpenRef.current = false;
                                }
                                if (restoreStartingStyle) {
                                    panel.setAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$CollapsiblePanelDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startingStyle"], '');
                                }
                                panel.setAttribute('hidden', 'until-found');
                            }
                        }["useCollapsiblePanel.useEffect.registerBeforeMatchListener.scheduleRevealRevert"]);
                    }
                }["useCollapsiblePanel.useEffect.registerBeforeMatchListener.scheduleRevealRevert"]);
            }
        }["useCollapsiblePanel.useEffect.registerBeforeMatchListener.scheduleRevealRevert"];
        // Declared as a `const` after the null check so `panel` stays narrowed: the
        // handler must touch the same element the listener is attached to.
        const handleBeforeMatch = {
            "useCollapsiblePanel.useEffect.registerBeforeMatchListener.handleBeforeMatch": (event)=>{
                const eventDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].none, event);
                onOpenChange(true, eventDetails);
                if (eventDetails.isCanceled) {
                    // A canceled reveal means the panel must stay hidden, so undo the
                    // browser's removal of `hidden` and keep the content searchable.
                    scheduleRevealRevert(false, false);
                    return;
                }
                shouldSkipNextOpenRef.current = true;
                // The browser removes `hidden` and measures the match in the same task that
                // dispatches this event, while the React state update below only lands in a
                // later one. Panels kept collapsed by persisted starting styles would still
                // be zero-sized at that point and the match highlight is dropped, so drop
                // those styles synchronously here.
                const hadStartingStyle = panel.hasAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$CollapsiblePanelDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startingStyle"]);
                panel.removeAttribute(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$CollapsiblePanelDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startingStyle"]);
                setOpen(true);
                // A controlled panel whose `onOpenChange` is ignored never receives the open
                // state, so return it to the fully closed state once the browser has measured.
                scheduleRevealRevert(true, hadStartingStyle);
            }
        }["useCollapsiblePanel.useEffect.registerBeforeMatchListener.handleBeforeMatch"];
        const cleanupBeforeMatchListener = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$addEventListener$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addEventListener"])(panel, 'beforematch', handleBeforeMatch);
        return ({
            "useCollapsiblePanel.useEffect.registerBeforeMatchListener": ()=>{
                revealDecisionTimeout.clear();
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].cancel(revertRevealFrame);
                cleanupBeforeMatchListener();
            }
        })["useCollapsiblePanel.useEffect.registerBeforeMatchListener"];
    }, [
        latestOpenRef,
        onOpenChange,
        setOpen
    ]);
    const shouldRender = keepMounted || hiddenUntilFound || mounted || open;
    return {
        height: renderedDimensions.height,
        props: {
            ...shouldPersistHiddenTransitionStyles ? {
                [__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$collapsible$2f$panel$2f$CollapsiblePanelDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["startingStyle"]]: ''
            } : undefined,
            hidden,
            id: idParam
        },
        ref: mergedPanelRef,
        shouldPreventOpenAnimation,
        shouldRender,
        transitionStatus: panelTransitionStatus,
        width: renderedDimensions.width
    };
}
function getDimensions(element) {
    return {
        height: element.scrollHeight,
        width: element.scrollWidth
    };
}
function getAnimationType(element, hasSuppressedMountAnimation) {
    const panelStyles = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$floating$2d$ui$2b$utils$40$0$2e$2$2e$12$2f$node_modules$2f40$floating$2d$ui$2f$utils$2f$dist$2f$floating$2d$ui$2e$utils$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__getWindow__as__ownerWindow$3e$__["ownerWindow"])(element).getComputedStyle(element);
    const hasAnimation = (panelStyles.animationName.split(',').map((name)=>name.trim()).some((name)=>name !== '' && name !== 'none') || hasSuppressedMountAnimation) && hasNonZeroDuration(panelStyles.animationDuration);
    const hasTransition = hasNonZeroDuration(panelStyles.transitionDuration);
    if (hasAnimation && hasTransition) {
        /* istanbul ignore else -- `process.env.NODE_ENV` is a build-time constant under test */ if ("TURBOPACK compile-time truthy", 1) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$warn$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["warn"])('CSS transitions and CSS animations both detected on Collapsible or Accordion panel.', 'Only one of either animation type should be used.');
        }
        return 'css-transition';
    }
    if (hasTransition) {
        return 'css-transition';
    }
    if (hasAnimation) {
        return 'css-animation';
    }
    return 'none';
}
function hasNonZeroDuration(value) {
    return value.split(',').map((part)=>part.trim()).some((part)=>part !== '' && Number.parseFloat(part) > 0);
}
/**
 * Temporarily overrides an inline style property and returns a cleanup that
 * restores the previous inline value and priority.
 * @param element - The element whose inline style should be updated.
 * @param property - The CSS property name to override.
 * @param value - The temporary value to assign.
 * @returns A cleanup function that restores the original inline style state.
 */ function setTemporaryStyle(element, property, value) {
    const previousValue = element.style.getPropertyValue(property);
    const previousPriority = element.style.getPropertyPriority(property);
    element.style.setProperty(property, value);
    return ()=>{
        if (previousValue === '') {
            element.style.removeProperty(property);
            return;
        }
        element.style.setProperty(property, previousValue, previousPriority);
    };
}
/**
 * Temporarily resets inline alignment styles that can distort scroll-based
 * size measurements, then restores them on the next animation frame.
 * @param element - The panel element being measured.
 * @returns A cleanup function that cancels the scheduled restore and reapplies
 * the original inline layout styles immediately.
 */ function resetLayoutStyles(element) {
    const originalLayoutStyles = {
        'justify-content': element.style.justifyContent,
        'align-items': element.style.alignItems,
        'align-content': element.style.alignContent,
        'justify-items': element.style.justifyItems
    };
    Object.keys(originalLayoutStyles).forEach((key)=>{
        element.style.setProperty(key, 'initial', 'important');
    });
    function restoreLayoutStyles() {
        Object.entries(originalLayoutStyles).forEach(([key, value])=>{
            if (value === '') {
                element.style.removeProperty(key);
                return;
            }
            element.style.setProperty(key, value);
        });
    }
    const frame = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].request(restoreLayoutStyles);
    return ()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useAnimationFrame$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AnimationFrame"].cancel(frame);
        restoreLayoutStyles();
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/root/CollapsibleRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CollapsibleRootContext",
    ()=>CollapsibleRootContext,
    "useCollapsibleRootContext",
    ()=>useCollapsibleRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const CollapsibleRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) CollapsibleRootContext.displayName = "CollapsibleRootContext";
function useCollapsibleRootContext() {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](CollapsibleRootContext);
    if (context === undefined) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: CollapsibleRootContext is missing. Collapsible parts must be placed within <Collapsible.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/root/useCollapsibleRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCollapsibleRoot",
    ()=>useCollapsibleRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useControlled.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTransitionStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useTransitionStatus.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function useCollapsibleRoot(parameters) {
    const { open: openParam, defaultOpen = false, onOpenChange, disabled } = parameters;
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useControlled$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useControlled"])({
        controlled: openParam,
        default: defaultOpen,
        name: 'Collapsible',
        state: 'open'
    });
    const { mounted, setMounted, transitionStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useTransitionStatus$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransitionStatus"])(open, true, true);
    const defaultPanelId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    // `undefined` uses the initial generated fallback; `null` means the panel unmounted.
    const [registeredPanelId, setPanelIdState] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"]();
    const panelId = registeredPanelId === null ? undefined : registeredPanelId ?? defaultPanelId;
    const handleTrigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "useCollapsibleRoot.useStableCallback[handleTrigger]": (event)=>{
            const nextOpen = !open;
            const eventDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].triggerPress, event.nativeEvent);
            onOpenChange(nextOpen, eventDetails);
            if (eventDetails.isCanceled) {
                return;
            }
            setOpen(nextOpen);
        }
    }["useCollapsibleRoot.useStableCallback[handleTrigger]"]);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useCollapsibleRoot.useMemo": ()=>({
                defaultPanelId,
                disabled,
                handleTrigger,
                mounted,
                open,
                panelId,
                setMounted,
                setOpen,
                setPanelIdState,
                transitionStatus
            })
    }["useCollapsibleRoot.useMemo"], [
        defaultPanelId,
        disabled,
        handleTrigger,
        mounted,
        open,
        panelId,
        setMounted,
        setOpen,
        setPanelIdState,
        transitionStatus
    ]);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/collapsible/trigger/CollapsibleTriggerDataAttributes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Present when the collapsible panel is open.
 */ __turbopack_context__.s([
    "panelOpen",
    ()=>panelOpen
]);
const panelOpen = 'data-panel-open';
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContextMenuRootContext",
    ()=>ContextMenuRootContext,
    "useContextMenuRootContext",
    ()=>useContextMenuRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const ContextMenuRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) ContextMenuRootContext.displayName = "ContextMenuRootContext";
function useContextMenuRootContext(optional = true) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ContextMenuRootContext);
    if (context === undefined && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: ContextMenuRootContext is missing. ContextMenu parts must be placed within <ContextMenu.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/fieldset/root/FieldsetRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FieldsetRootContext",
    ()=>FieldsetRootContext,
    "useFieldsetRootContext",
    ()=>useFieldsetRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const FieldsetRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) FieldsetRootContext.displayName = "FieldsetRootContext";
function useFieldsetRootContext(optional = false) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FieldsetRootContext);
    if (!context && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: FieldsetRootContext is missing. Fieldset parts must be placed within <Fieldset.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/clear/FilterDropdownClear.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownClear",
    ()=>FilterDropdownClear
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/use-button/useButton.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
const FilterDropdownClear = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FilterDropdownClear(componentProps, forwardedRef) {
    const { render, className, style, disabled: disabledProp = false, nativeButton = true, ...elementProps } = componentProps;
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownRootContext"])();
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownValueContext"])();
    const disabled = context.disabled || disabledProp;
    const visible = value !== '';
    const { buttonRef, getButtonProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$use$2d$button$2f$useButton$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useButton"])({
        disabled,
        native: nativeButton
    });
    // `visible` is deliberately absent from the state: the component renders nothing when it is
    // false, so a `data-visible` attribute would be present on every rendered instance.
    const state = {
        disabled
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('button', componentProps, {
        enabled: visible,
        state,
        ref: [
            forwardedRef,
            buttonRef
        ],
        props: [
            {
                tabIndex: -1,
                'aria-hidden': true,
                onMouseDown (event) {
                    // Avoid stealing focus from the input on pointer interaction.
                    event.preventDefault();
                },
                onClick (event) {
                    const eventDetails = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].clearPress, event.nativeEvent);
                    context.onValueChange('', eventDetails);
                    context.focusOwnerRef.current?.focus({
                        preventScroll: true
                    });
                }
            },
            elementProps,
            getButtonProps
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) FilterDropdownClear.displayName = "FilterDropdownClear";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/empty/FilterDropdownEmpty.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownEmpty",
    ()=>FilterDropdownEmpty
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$useStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/store/useStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useInitialLiveRegionTextMutation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useInitialLiveRegionTextMutation.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const FilterDropdownEmpty = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FilterDropdownEmpty(componentProps, forwardedRef) {
    const { render, className, style, ...elementProps } = componentProps;
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItemContext"])();
    const isEmpty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$useStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(store, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectors"].isEmpty);
    // Items mounting in the same commit register in layout effects, after this first render, and
    // don't register on the server at all. Deciding once they have keeps the children from
    // mounting for a frame on every open, and the message out of server markup.
    const [ready, setReady] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "FilterDropdownEmpty.FilterDropdownEmpty.useIsoLayoutEffect": ()=>{
            setReady(true);
        }
    }["FilterDropdownEmpty.FilterDropdownEmpty.useIsoLayoutEffect"], []);
    const visible = ready && isEmpty;
    const emptyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useInitialLiveRegionTextMutation$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useInitialLiveRegionTextMutation"])(visible);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        enabled: visible,
        ref: [
            forwardedRef,
            emptyRef
        ],
        props: [
            {
                role: 'status',
                'aria-live': 'polite',
                'aria-atomic': true
            },
            elementProps
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) FilterDropdownEmpty.displayName = "FilterDropdownEmpty";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/FilterDropdownGroupContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownGroupContext",
    ()=>FilterDropdownGroupContext,
    "useFilterDropdownGroupContext",
    ()=>useFilterDropdownGroupContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const FilterDropdownGroupContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
if ("TURBOPACK compile-time truthy", 1) FilterDropdownGroupContext.displayName = "FilterDropdownGroupContext";
function useFilterDropdownGroupContext() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FilterDropdownGroupContext);
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/useFilterDropdownGroup.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFilterDropdownGroup",
    ()=>useFilterDropdownGroup
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$useStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/store/useStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useRefWithInit.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/FilterDropdownGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useItemRegistry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useItemRegistry.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
function isGroupHidden(state, items) {
    // A group with no members hasn't been filtered out, it hasn't registered yet.
    if (state.visibleItemIds === null || items.size === 0) {
        return false;
    }
    for (const [id, retained] of items){
        if (retained || state.visibleItemIds.has(id)) {
            return false;
        }
    }
    return true;
}
function useFilterDropdownGroup() {
    const { store } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItemContext"])();
    const parentContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownGroupContext"])();
    const { items, registerItem } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useItemRegistry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useItemRegistry"])();
    const hidden = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$useStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(store, isGroupHidden, items);
    // A nested container collects its own items, so the enclosing one only ever sees this
    // registration. Report visibility upward or a group of groups would look empty.
    const groupId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "useFilterDropdownGroup.useRefWithInit": ()=>Symbol('filter-dropdown-group')
    }["useFilterDropdownGroup.useRefWithInit"]).current;
    const registerInParent = parentContext?.registerItem;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useFilterDropdownGroup.useIsoLayoutEffect": ()=>registerInParent?.(groupId, !hidden)
    }["useFilterDropdownGroup.useIsoLayoutEffect"], [
        registerInParent,
        groupId,
        hidden
    ]);
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "useFilterDropdownGroup.useMemo[context]": ()=>({
                registerItem
            })
    }["useFilterDropdownGroup.useMemo[context]"], [
        registerItem
    ]);
    return {
        hidden,
        context
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/input/FilterDropdownInput.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownInput",
    ()=>FilterDropdownInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/platform/parts.mjs [app-client] (ecmascript) <export * as platform>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/utils/refocusOwner.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const FilterDropdownInput = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FilterDropdownInput(componentProps, forwardedRef) {
    const { render, className, style, id: idProp, disabled, activeItemId, navigationProps, ...elementProps } = componentProps;
    // Browsers flag a form field with neither an id nor a name.
    const id = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])(idProp);
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownRootContext"])();
    const { listRef } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItemContext"])();
    const value = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownValueContext"])();
    // IME text isn't committed until the composition ends, so filtering waits for it.
    const [composingValue, setComposingValue] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const isComposingRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](false);
    function commitValue(nextValue, nativeEvent) {
        // The input keeps focus until the popup unmounts. An edit made while it animates out would
        // land after the close reset the query and carry over into the next open.
        if (!context.open) {
            return;
        }
        const reason = nextValue === '' ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].inputClear : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].inputChange;
        context.onValueChange(nextValue, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(reason, nativeEvent));
    }
    const state = {
        highlighted: context.inputFocusVisible && (!context.keyboardModality || activeItemId == null)
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('input', componentProps, {
        state,
        ref: [
            forwardedRef,
            context.focusOwnerRef
        ],
        props: [
            navigationProps,
            {
                id,
                type: 'text',
                disabled: context.disabled || disabled,
                'aria-activedescendant': activeItemId,
                role: 'searchbox',
                inputMode: 'search',
                autoComplete: 'off',
                spellCheck: 'false',
                autoCorrect: 'off',
                autoCapitalize: 'none',
                // The aria-autocomplete 'list' value is only valid with `aria-haspopup` so we depend
                // on the searchbox role to communicate affordance, with an input label as fallback
                // https://w3c.github.io/aria/#aria-autocomplete
                'aria-autocomplete': undefined,
                'aria-controls': context.listId,
                value: composingValue ?? value,
                onCompositionStart (event) {
                    // Some Android keyboards treat all typing as one composition.
                    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$platform$2f$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__platform$3e$__["platform"].os.android) {
                        return;
                    }
                    isComposingRef.current = true;
                    setComposingValue(event.currentTarget.value);
                },
                onCompositionEnd (event) {
                    if (!isComposingRef.current) {
                        return;
                    }
                    isComposingRef.current = false;
                    setComposingValue(null);
                    commitValue(event.currentTarget.value, event.nativeEvent);
                },
                onChange (event) {
                    if (isComposingRef.current) {
                        setComposingValue(event.currentTarget.value);
                        return;
                    }
                    commitValue(event.currentTarget.value, event.nativeEvent);
                },
                onKeyDown () {
                    context.setKeyboardModality(true);
                },
                onPointerDown () {
                    context.setKeyboardModality(false);
                },
                onMouseEnter (event) {
                    context.setKeyboardModality(false);
                    // Take focus so typing filters immediately.
                    if (context.open) {
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["refocusOwner"])(event.currentTarget);
                    }
                },
                onFocus (event) {
                    context.setInputFocusVisible(true);
                    // A screen reader that followed `aria-activedescendant` put real focus on the item, so
                    // focus returning from an item means the user moved back to the input on purpose and
                    // the highlight no longer reflects where they are. The list's own key replay and
                    // pointer refocus also pass through here and keep it.
                    if (context.autoHighlight === 'always' || (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isRefocusingOwner"])()) {
                        return;
                    }
                    const from = event.relatedTarget;
                    if (from !== null && listRef.current.includes(from)) {
                        context.setActiveIndex(null);
                    }
                },
                onBlur () {
                    context.setInputFocusVisible(false);
                }
            },
            elementProps
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) FilterDropdownInput.displayName = "FilterDropdownInput";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/item/useFilterDropdownItem.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFilterDropdownItem",
    ()=>useFilterDropdownItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useRefWithInit.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useValueAsRef.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$useStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/store/useStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/FilterDropdownGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/store.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
/** Text of the rendered children, for when the element is filtered out and has no DOM node. */ function childrenText(children) {
    if (typeof children === 'string' || typeof children === 'number') {
        return String(children);
    }
    if (Array.isArray(children)) {
        return children.map(childrenText).join('');
    }
    if (/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidElement"](children)) {
        return childrenText(children.props.children);
    }
    return '';
}
function useFilterDropdownItem(params) {
    const { label, retainGroup = false, children, render, context } = params;
    const nearestContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownItemContext"])(context !== undefined);
    const groupContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownGroupContext"])();
    const owner = context === undefined ? nearestContext : context;
    const { registerItem, store } = owner ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DETACHED_OWNER"];
    const registerGroupItem = groupContext?.registerItem;
    const itemId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "useFilterDropdownItem.useRefWithInit": ()=>Symbol('filter-dropdown-item')
    }["useFilterDropdownItem.useRefWithInit"]).current;
    const ref = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const registeredTextRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](undefined);
    const matched = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$useStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStore"])(store, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["selectors"].isItemVisible, itemId);
    // An initial item is visible before registration (`visibleItemIds` is null), so start
    // registered and skip the mount re-render. A late item under an active filter starts
    // unregistered and renders once so its DOM text can be captured.
    const [registered, setRegistered] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](matched);
    // Read through refs so `register` stays stable while the children change identity.
    const childrenRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValueAsRef"])(children);
    const renderRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useValueAsRef$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useValueAsRef"])(render);
    // What the children last read as, to tell whether they changed while the item rendered no text.
    const childrenTextRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](undefined);
    const resolveText = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFilterDropdownItem.useCallback[resolveText]": ()=>{
            if (label != null) {
                return label;
            }
            // An item without children can carry its text in its `render` element instead.
            const fromChildren = childrenText(childrenRef.current ?? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["unwrapLazyRenderProp"])(renderRef.current));
            const previousChildrenText = childrenTextRef.current;
            childrenTextRef.current = fromChildren;
            if (ref.current !== null) {
                return ref.current.textContent ?? '';
            }
            // A filtered-out item has no DOM node left. Its children are only a stand-in for the text it
            // renders, which can differ (a translation component, for example), so the cached text wins
            // unless the children changed.
            if (registeredTextRef.current !== undefined && fromChildren === previousChildrenText) {
                return registeredTextRef.current;
            }
            return fromChildren;
        }
    }["useFilterDropdownItem.useCallback[resolveText]"], [
        label,
        childrenRef,
        renderRef
    ]);
    const register = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"]({
        "useFilterDropdownItem.useCallback[register]": (resolvedText)=>{
            const text = resolvedText ?? resolveText();
            if (text) {
                registeredTextRef.current = text;
            }
            return registerItem(itemId, {
                getText () {
                    // A mounted item reports what it renders now, even nothing, since a descendant can change
                    // its text without the item re-rendering. A filtered-out item falls back to the cached
                    // text.
                    if (label == null && ref.current) {
                        registeredTextRef.current = ref.current.textContent ?? '';
                    }
                    return registeredTextRef.current;
                }
            });
        }
    }["useFilterDropdownItem.useCallback[register]"], [
        itemId,
        label,
        registerItem,
        resolveText
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useFilterDropdownItem.useIsoLayoutEffect": ()=>{
            const unregister = register();
            setRegistered(true);
            return unregister;
        }
    }["useFilterDropdownItem.useIsoLayoutEffect"], [
        register
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useFilterDropdownItem.useIsoLayoutEffect": ()=>registerGroupItem?.(itemId, retainGroup)
    }["useFilterDropdownItem.useIsoLayoutEffect"], [
        registerGroupItem,
        itemId,
        retainGroup
    ]);
    // Re-register when the item's text changes, so the active query runs again.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useFilterDropdownItem.useIsoLayoutEffect": ()=>{
            const text = resolveText();
            if (text !== registeredTextRef.current) {
                registeredTextRef.current = text;
                void register(text);
            }
        }
    }["useFilterDropdownItem.useIsoLayoutEffect"], [
        register,
        resolveText,
        children,
        render,
        label
    ]);
    return {
        visible: !registered || matched,
        ref
    };
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/list/FilterDropdownList.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownList",
    ()=>FilterDropdownList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/group/FilterDropdownGroupContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolveRenderedId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/resolveRenderedId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/shadowDom.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/utils/refocusOwner.mjs [app-client] (ecmascript)");
/**
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
const FilterDropdownList = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function FilterDropdownList(componentProps, forwardedRef) {
    // `id` is resolved by `useRenderedId`, which also honors an id on the `render` element.
    const { render, className, style, id: idProp, ...elementProps } = componentProps;
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFilterDropdownRootContext"])();
    const [id, registerIdRef] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$resolveRenderedId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderedId"])(componentProps, context.defaultListId, context.setRenderedListId);
    const defaultProps = {
        // Chromium includes scrollable elements in sequential focus navigation by default.
        tabIndex: -1,
        id,
        onFocus (event) {
            // A press on the list's own content, such as its background, a group, or a group label,
            // focuses the list.
            const owner = context.focusOwnerRef.current;
            if (owner && event.relatedTarget === owner && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$shadowDom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTarget"])(event.nativeEvent) === event.currentTarget) {
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$utils$2f$refocusOwner$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["refocusOwner"])(owner);
            }
        },
        onPointerMove () {
            context.setKeyboardModality(false);
        },
        onPointerDown () {
            context.setKeyboardModality(false);
        }
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        ref: [
            forwardedRef,
            registerIdRef
        ],
        props: [
            defaultProps,
            elementProps,
            {
                // The list's groups and items belong to this root's query. A nested root's list renders
                // inside an enclosing group, which must not count them as its own members.
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$group$2f$FilterDropdownGroupContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownGroupContext"].Provider, {
                    value: null,
                    children: elementProps.children
                })
            }
        ]
    });
});
if ("TURBOPACK compile-time truthy", 1) FilterDropdownList.displayName = "FilterDropdownList";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRoot.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownRoot",
    ()=>FilterDropdownRoot
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useRefWithInit.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useStableCallback.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$filter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/filter.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useBaseUiId.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useItemRegistry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useItemRegistry.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/store.mjs [app-client] (ecmascript)");
/**
 * Holds the filter query, matches it against the registered items, and publishes the result. The
 * host owns list navigation; this root moves the highlight through `setActiveIndex`.
 *
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
;
;
function FilterDropdownRoot(props) {
    const { children, open, disabled = false, openedByKeyboard = false, locale, value, query, onValueChange, filter, autoHighlight = false, triggerId: triggerIdProp, listRef, getActiveIndex, setActiveIndex, focusOwnerRef: focusOwnerRefProp } = props;
    const parentItemContext = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownItemContext"]);
    const [renderedListId, setRenderedListId] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](undefined);
    const [inputFocusVisible, setInputFocusVisible] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](openedByKeyboard);
    const [keyboardModality, setKeyboardModality] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](openedByKeyboard);
    const [previousOpenedByKeyboard, setPreviousOpenedByKeyboard] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](openedByKeyboard);
    // Both reset when the host reports a new value; doing it during render skips an extra commit.
    if (openedByKeyboard !== previousOpenedByKeyboard) {
        setPreviousOpenedByKeyboard(openedByKeyboard);
        setInputFocusVisible(openedByKeyboard);
        setKeyboardModality(openedByKeyboard);
    }
    const { items: registeredItems, registerItem: registerInRegistry, liveItems } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useItemRegistry$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useItemRegistry"])();
    const defaultId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useBaseUiId$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseUiId"])();
    const store = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useRefWithInit$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRefWithInit"])({
        "FilterDropdownRoot.useRefWithInit": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$store$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownStore"]()
    }["FilterDropdownRoot.useRefWithInit"]).current;
    // The count is published as items register, not with the next registry snapshot, so a
    // `Menu.Empty` mounting alongside the items never reads a stale zero.
    const registerItem = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "FilterDropdownRoot.useStableCallback[registerItem]": (id, item)=>{
            const unregister = registerInRegistry(id, item);
            store.set('registeredItemCount', liveItems.size);
            return ({
                "FilterDropdownRoot.useStableCallback[registerItem]": ()=>{
                    unregister();
                    store.set('registeredItemCount', liveItems.size);
                }
            })["FilterDropdownRoot.useStableCallback[registerItem]"];
        }
    }["FilterDropdownRoot.useStableCallback[registerItem]"]);
    const fallbackFocusOwnerRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const lastFilterQueryRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](null);
    const defaultMatchItem = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FilterDropdownRoot.useMemo[defaultMatchItem]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$filter$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFilter"])({
                locale
            }).contains
    }["FilterDropdownRoot.useMemo[defaultMatchItem]"], [
        locale
    ]);
    const focusOwnerRef = focusOwnerRefProp ?? fallbackFocusOwnerRef;
    const filterQuery = (query ?? value).trim();
    // An unused inline filter must not re-run auto-highlighting when the consumer re-renders.
    const matchItem = filterQuery === '' || filter === null ? null : filter ?? defaultMatchItem;
    const autoHighlightEnabled = open && (autoHighlight === 'always' || autoHighlight && filterQuery !== '');
    // React 17 resolves generated ids in an effect, so they must be read live rather than captured
    // in a state initializer.
    const defaultListId = defaultId ? `${defaultId}-list` : undefined;
    const listId = (renderedListId ?? defaultListId) || undefined;
    // The host owns the trigger. `null` and `''` both mean no element carries an id to point at.
    const triggerId = triggerIdProp || undefined;
    const handleValueChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "FilterDropdownRoot.useStableCallback[handleValueChange]": (nextValue, eventDetails)=>{
            onValueChange?.(nextValue, eventDetails);
            // Indexes are positional, so a kept highlight would land on whatever fills its slot.
            // With `autoHighlight`, the filtering effect below places the highlight instead.
            if (!eventDetails.isCanceled && !autoHighlight) {
                setActiveIndex(null);
            }
        }
    }["FilterDropdownRoot.useStableCallback[handleValueChange]"]);
    const handleItemsChange = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useStableCallback$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStableCallback"])({
        "FilterDropdownRoot.useStableCallback[handleItemsChange]": (previousItems)=>{
            const items = listRef.current;
            const activeIndex = getActiveIndex();
            // A positional highlight must not silently move to another item. A change that leaves the
            // highlighted item in place keeps it, such as an item appended after it or one that renders
            // once before the query filters it out. A query change already reset the highlight.
            if (activeIndex != null && items[activeIndex] != null && items[activeIndex] === previousItems[activeIndex]) {
                return;
            }
            setActiveIndex(autoHighlightEnabled && items.length > 0 ? 0 : null);
        }
    }["FilterDropdownRoot.useStableCallback[handleItemsChange]"]);
    // Re-runs on the registry snapshot published once every item in the commit has registered,
    // and on the committed query, because a controlled consumer can reject a proposed change. It
    // reads the live registry so items registered in this commit count before their snapshot.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "FilterDropdownRoot.useIsoLayoutEffect": ()=>{
            if (!open && query === undefined) {
                return;
            }
            const queryChanged = lastFilterQueryRef.current !== null && lastFilterQueryRef.current !== filterQuery;
            lastFilterQueryRef.current = filterQuery;
            // With no query or external filtering, every registered item is visible. External filtering
            // still follows `autoHighlight`; otherwise the item set invalidates the highlight.
            if (matchItem === null) {
                store.set('visibleItemIds', null);
                // Registry updates, such as an item's text changing, keep the current highlight.
                if (autoHighlightEnabled && liveItems.size > 0) {
                    if (queryChanged || getActiveIndex() == null) {
                        setActiveIndex(0);
                    }
                } else if (filterQuery === '' && queryChanged) {
                    setActiveIndex(null);
                }
                return;
            }
            const currentIds = store.state.visibleItemIds;
            // The popup's content mounts a commit after the root opens. Publishing an empty result before
            // anything registered would hide every item as it arrives and remount the matches.
            if (currentIds === null && liveItems.size === 0) {
                return;
            }
            const nextIds = new Set();
            let hasNewMatch = currentIds === null;
            liveItems.forEach({
                "FilterDropdownRoot.useIsoLayoutEffect": ({ getText }, id)=>{
                    const text = getText();
                    if (text != null && matchItem(text, filterQuery)) {
                        nextIds.add(id);
                        hasNewMatch ||= !currentIds?.has(id);
                    }
                }
            }["FilterDropdownRoot.useIsoLayoutEffect"]);
            // New matches or a smaller result set invalidate the previous item identities.
            if (hasNewMatch || currentIds?.size !== nextIds.size) {
                // The first filtered snapshot can land after initial keyboard navigation in React 18. It
                // has no prior result identity to invalidate, unless the controlled query itself changed.
                if (autoHighlightEnabled && nextIds.size > 0) {
                    setActiveIndex(0);
                } else if (currentIds !== null || queryChanged) {
                    setActiveIndex(null);
                }
                store.set('visibleItemIds', nextIds);
            } else if (autoHighlightEnabled && queryChanged && nextIds.size > 0) {
                setActiveIndex(0);
            }
        }
    }["FilterDropdownRoot.useIsoLayoutEffect"], [
        open,
        query,
        filterQuery,
        registeredItems,
        liveItems,
        matchItem,
        autoHighlightEnabled,
        store,
        setActiveIndex,
        getActiveIndex
    ]);
    const contextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FilterDropdownRoot.useMemo[contextValue]": ()=>({
                open,
                disabled,
                inputFocusVisible,
                setInputFocusVisible,
                keyboardModality,
                setKeyboardModality,
                autoHighlight,
                triggerId,
                defaultListId,
                listId,
                setRenderedListId,
                focusOwnerRef,
                setActiveIndex,
                onItemsChange: handleItemsChange,
                onValueChange: handleValueChange
            })
    }["FilterDropdownRoot.useMemo[contextValue]"], [
        open,
        disabled,
        inputFocusVisible,
        keyboardModality,
        autoHighlight,
        triggerId,
        defaultListId,
        listId,
        focusOwnerRef,
        setActiveIndex,
        handleItemsChange,
        handleValueChange
    ]);
    const itemContextValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"]({
        "FilterDropdownRoot.useMemo[itemContextValue]": ()=>({
                parent: parentItemContext,
                store,
                registerItem,
                listRef
            })
    }["FilterDropdownRoot.useMemo[itemContextValue]"], [
        parentItemContext,
        store,
        registerItem,
        listRef
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownItemContext"].Provider, {
        value: itemContextValue,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownRootContext"].Provider, {
            value: contextValue,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$filter$2d$dropdown$2f$root$2f$FilterDropdownRootContext$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FilterDropdownValueContext"].Provider, {
                value: query ?? value,
                children: children
            })
        })
    });
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FilterDropdownItemContext",
    ()=>FilterDropdownItemContext,
    "FilterDropdownRoot",
    ()=>FilterDropdownRoot,
    "FilterDropdownRootContext",
    ()=>FilterDropdownRootContext,
    "FilterDropdownValueContext",
    ()=>FilterDropdownValueContext,
    "useFilterContextForList",
    ()=>useFilterContextForList,
    "useFilterDropdownItemContext",
    ()=>useFilterDropdownItemContext,
    "useFilterDropdownRootContext",
    ()=>useFilterDropdownRootContext,
    "useFilterDropdownValueContext",
    ()=>useFilterDropdownValueContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
function throwMissingFilterRoot() {
    throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: Filter parts are missing their filter context and cannot access the query or items. ' + 'Wrap the component root in its filter provider.' : "TURBOPACK unreachable");
}
const FilterDropdownItemContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
if ("TURBOPACK compile-time truthy", 1) FilterDropdownItemContext.displayName = "FilterDropdownItemContext";
function useFilterDropdownItemContext(optional = false) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FilterDropdownItemContext);
    if (context === null && !optional) {
        throwMissingFilterRoot();
    }
    return context;
}
const FilterDropdownRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
if ("TURBOPACK compile-time truthy", 1) FilterDropdownRootContext.displayName = "FilterDropdownRootContext";
function useFilterDropdownRootContext(optional = false) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FilterDropdownRootContext);
    if (context === null && !optional) {
        throwMissingFilterRoot();
    }
    return context;
}
function useFilterContextForList(listRef) {
    let context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FilterDropdownItemContext);
    if (listRef === null) {
        return null;
    }
    while(context !== null && context.listRef !== listRef){
        context = context.parent;
    }
    return context;
}
const FilterDropdownValueContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"]('');
if ("TURBOPACK compile-time truthy", 1) FilterDropdownValueContext.displayName = "FilterDropdownValueContext";
function useFilterDropdownValueContext() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](FilterDropdownValueContext);
}
let FilterDropdownRoot;
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/root/useFilterDropdownCloseQuery.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useFilterDropdownCloseQuery",
    ()=>useFilterDropdownCloseQuery
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/useIsoLayoutEffect.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/createBaseUIEventDetails.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/reason-parts.mjs [app-client] (ecmascript) <export * as REASONS>");
'use client';
;
;
;
;
function useFilterDropdownCloseQuery(parameters) {
    const { open, mounted, value, onValueChange } = parameters;
    const [closeQuery, setCloseQuery] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"](null);
    const previousOpenRef = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"](open);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$useIsoLayoutEffect$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsoLayoutEffect"])({
        "useFilterDropdownCloseQuery.useIsoLayoutEffect": ()=>{
            const wasOpen = previousOpenRef.current;
            previousOpenRef.current = open;
            if (wasOpen && !open && value !== '') {
                setCloseQuery(value);
                onValueChange('', (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$createBaseUIEventDetails$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createChangeEventDetails"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$reason$2d$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__REASONS$3e$__["REASONS"].popupClose));
            } else if ((open || !mounted) && closeQuery !== null) {
                setCloseQuery(null);
            }
        }
    }["useFilterDropdownCloseQuery.useIsoLayoutEffect"], [
        open,
        mounted,
        value,
        closeQuery,
        onValueChange
    ]);
    return !open && closeQuery !== null ? closeQuery : value;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/store.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DETACHED_OWNER",
    ()=>DETACHED_OWNER,
    "FilterDropdownStore",
    ()=>FilterDropdownStore,
    "selectors",
    ()=>selectors
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$ReactStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/store/ReactStore.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/empty.mjs [app-client] (ecmascript)");
;
;
const selectors = {
    // A null `visibleItemIds` means no query, so fall back to whether anything registered.
    isEmpty: (state)=>state.visibleItemIds === null ? state.registeredItemCount === 0 : state.visibleItemIds.size === 0,
    isItemVisible: (state, id)=>state.visibleItemIds === null || state.visibleItemIds.has(id)
};
class FilterDropdownStore extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$store$2f$ReactStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ReactStore"] {
    constructor(){
        super({
            visibleItemIds: null,
            registeredItemCount: 0
        }, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["EMPTY_OBJECT"], selectors);
    }
}
const DETACHED_OWNER = {
    registerItem: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$empty$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NOOP"],
    store: new FilterDropdownStore()
};
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/filter-dropdown/utils/refocusOwner.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isRefocusingOwner",
    ()=>isRefocusingOwner,
    "refocusOwner",
    ()=>refocusOwner
]);
let refocusing = false;
function refocusOwner(owner) {
    refocusing = true;
    try {
        owner.focus({
            preventScroll: true
        });
    } finally{
        refocusing = false;
    }
}
function isRefocusingOwner() {
    return refocusing;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/input/Input.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Input",
    ()=>Input
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$field$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Field$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/field/index.parts.mjs [app-client] (ecmascript) <export * as Field>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/jsx-runtime.js [app-client] (ecmascript)");
'use client';
;
;
;
const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function Input(props, forwardedRef) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsx"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$field$2f$index$2e$parts$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Field$3e$__["Field"].Control, {
        ref: forwardedRef,
        ...props
    });
});
if ("TURBOPACK compile-time truthy", 1) Input.displayName = "Input";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/menubar/MenubarContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MenubarContext",
    ()=>MenubarContext,
    "useMenubarContext",
    ()=>useMenubarContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const MenubarContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](null);
if ("TURBOPACK compile-time truthy", 1) MenubarContext.displayName = "MenubarContext";
function useMenubarContext(optional) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](MenubarContext);
    if (context === null && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: MenubarContext is missing. Menubar parts must be placed within <Menubar>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/merge-props/mergeProps.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "makeEventPreventable",
    ()=>makeEventPreventable,
    "mergeClassNames",
    ()=>mergeClassNames,
    "mergeProps",
    ()=>mergeProps,
    "mergePropsN",
    ()=>mergePropsN
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$mergeObjects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+utils@0.5.0_@types_6b1c5c30254f04ccfc8f12b63d1f3b80/node_modules/@base-ui/utils/mergeObjects.mjs [app-client] (ecmascript)");
;
const EMPTY_PROPS = {};
function mergeProps(a, b, c, d, e) {
    if (!c && !d && !e && !a) {
        return createInitialMergedProps(b);
    }
    // We need to mutably own `merged`.
    let merged = createInitialMergedProps(a);
    if (b) {
        merged = mergeInto(merged, b);
    }
    if (c) {
        merged = mergeInto(merged, c);
    }
    if (d) {
        merged = mergeInto(merged, d);
    }
    if (e) {
        merged = mergeInto(merged, e);
    }
    return merged;
}
function mergePropsN(props) {
    if (props.length === 0) {
        return EMPTY_PROPS;
    }
    if (props.length === 1) {
        return createInitialMergedProps(props[0]);
    }
    // We need to mutably own `merged`.
    let merged = createInitialMergedProps(props[0]);
    for(let i = 1; i < props.length; i += 1){
        merged = mergeInto(merged, props[i]);
    }
    return merged;
}
function createInitialMergedProps(inputProps) {
    if (isPropsGetter(inputProps)) {
        // Getter-returned handlers intentionally keep their existing semantics.
        return {
            ...inputProps(EMPTY_PROPS)
        };
    }
    return copyInitialProps(inputProps);
}
function mergeInto(merged, inputProps) {
    if (isPropsGetter(inputProps)) {
        return inputProps(merged);
    }
    return mutablyMergeInto(merged, inputProps);
}
function copyInitialProps(inputProps) {
    const copiedProps = {
        ...inputProps
    };
    // `copiedProps` is our fresh own-object copy, so iterating with `for...in` is safe here.
    // eslint-disable-next-line guard-for-in
    for(const propName in copiedProps){
        const propValue = copiedProps[propName];
        if (isEventHandler(propName, propValue)) {
            copiedProps[propName] = wrapEventHandler(propValue);
        }
    }
    return copiedProps;
}
/**
 * Merges two sets of props. In case of conflicts, the external props take precedence.
 */ function mutablyMergeInto(mergedProps, externalProps) {
    if (!externalProps) {
        return mergedProps;
    }
    // eslint-disable-next-line guard-for-in
    for(const propName in externalProps){
        const externalPropValue = externalProps[propName];
        switch(propName){
            case 'style':
                {
                    mergedProps[propName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$utils$40$0$2e$5$2e$0_$40$types_6b1c5c30254f04ccfc8f12b63d1f3b80$2f$node_modules$2f40$base$2d$ui$2f$utils$2f$mergeObjects$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["mergeObjects"])(mergedProps.style, externalPropValue);
                    break;
                }
            case 'className':
                {
                    mergedProps[propName] = mergeClassNames(mergedProps.className, externalPropValue);
                    break;
                }
            default:
                {
                    if (isEventHandler(propName, externalPropValue)) {
                        mergedProps[propName] = mergeEventHandlers(mergedProps[propName], externalPropValue);
                    } else {
                        mergedProps[propName] = externalPropValue;
                    }
                }
        }
    }
    return mergedProps;
}
function isEventHandler(key, value) {
    // This approach is more efficient than using a regex.
    const code0 = key.charCodeAt(0);
    const code1 = key.charCodeAt(1);
    const code2 = key.charCodeAt(2);
    return code0 === 111 /* o */  && code1 === 110 /* n */  && code2 >= 65 /* A */  && code2 <= 90 /* Z */  && (typeof value === 'function' || typeof value === 'undefined');
}
function isPropsGetter(inputProps) {
    return typeof inputProps === 'function';
}
function mergeEventHandlers(ourHandler, theirHandler) {
    if (!theirHandler) {
        return ourHandler;
    }
    if (!ourHandler) {
        return wrapEventHandler(theirHandler);
    }
    return (...args)=>{
        const event = args[0];
        if (isSyntheticEvent(event)) {
            const baseUIEvent = event;
            makeEventPreventable(baseUIEvent);
            const result = theirHandler(...args);
            if (!baseUIEvent.baseUIHandlerPrevented) {
                ourHandler?.(...args);
            }
            return result;
        }
        const result = theirHandler(...args);
        ourHandler?.(...args);
        return result;
    };
}
function wrapEventHandler(handler) {
    if (!handler) {
        return handler;
    }
    return (...args)=>{
        const event = args[0];
        if (isSyntheticEvent(event)) {
            makeEventPreventable(event);
        }
        return handler(...args);
    };
}
function makeEventPreventable(event) {
    event.preventBaseUIHandler = ()=>{
        event.baseUIHandlerPrevented = true;
    };
    return event;
}
function mergeClassNames(ourClassName, theirClassName) {
    if (theirClassName) {
        if (ourClassName) {
            // eslint-disable-next-line prefer-template
            return theirClassName + ' ' + ourClassName;
        }
        return theirClassName;
    }
    return ourClassName;
}
function isSyntheticEvent(event) {
    return event != null && typeof event === 'object' && 'nativeEvent' in event;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/separator/Separator.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Separator",
    ()=>Separator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/internals/useRenderElement.mjs [app-client] (ecmascript)");
'use client';
;
;
const Separator = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"](function SeparatorComponent(componentProps, forwardedRef) {
    const { className, render, orientation = 'horizontal', style, ...elementProps } = componentProps;
    const state = {
        orientation
    };
    const element = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$internals$2f$useRenderElement$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRenderElement"])('div', componentProps, {
        state,
        ref: forwardedRef,
        props: [
            {
                role: 'separator',
                'aria-orientation': orientation
            },
            elementProps
        ]
    });
    return element;
});
if ("TURBOPACK compile-time truthy", 1) Separator.displayName = "Separator";
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/toolbar/root/ToolbarRootContext.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ToolbarRootContext",
    ()=>ToolbarRootContext,
    "useToolbarRootContext",
    ()=>useToolbarRootContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/next@16.3.8_@babel+core@7.2_fb1009e1863fd2343ab903a87c696e41/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
;
const ToolbarRootContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"](undefined);
if ("TURBOPACK compile-time truthy", 1) ToolbarRootContext.displayName = "ToolbarRootContext";
function useToolbarRootContext(optional) {
    const context = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$3$2e$8_$40$babel$2b$core$40$7$2e$2_fb1009e1863fd2343ab903a87c696e41$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"](ToolbarRootContext);
    if (context === undefined && !optional) {
        throw new Error(("TURBOPACK compile-time truthy", 1) ? 'Base UI: ToolbarRootContext is missing. Toolbar parts must be placed within <Toolbar.Root>.' : "TURBOPACK unreachable");
    }
    return context;
}
}),
"[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/tooltip/trigger/TooltipTriggerDataAttributes.mjs [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "popupOpen",
    ()=>popupOpen,
    "triggerDisabled",
    ()=>triggerDisabled
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$CommonTriggerDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__CommonTriggerDataAttributes$3e$__ = __turbopack_context__.i("[project]/node_modules/.pnpm/@base-ui+react@1.9.0_@types_9de95ddea501fb73a908a36fe3e33ee8/node_modules/@base-ui/react/utils/CommonTriggerDataAttributes.mjs [app-client] (ecmascript) <export * as CommonTriggerDataAttributes>");
;
const popupOpen = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f2e$pnpm$2f40$base$2d$ui$2b$react$40$1$2e$9$2e$0_$40$types_9de95ddea501fb73a908a36fe3e33ee8$2f$node_modules$2f40$base$2d$ui$2f$react$2f$utils$2f$CommonTriggerDataAttributes$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__CommonTriggerDataAttributes$3e$__["CommonTriggerDataAttributes"].popupOpen;
const triggerDisabled = 'data-trigger-disabled';
}),
]);

//# sourceMappingURL=0u8u_%40base-ui_react_06dyq7b._.js.map